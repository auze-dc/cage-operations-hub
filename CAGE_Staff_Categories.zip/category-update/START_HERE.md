# Staff categories — Requests, CRM and Projects

This is a category-only update based on your latest uploaded repository. It works independently of the uninstalled location and Slack-style presence packages. It does not include those packages and does not change quote approval requirements.

## What changes

- Active individual staff accounts can add shared category names without administrator approval. Shared accounts and inactive accounts cannot.
- **New request:** use **+ Add category** underneath Purpose of request. Existing purposes stay available.
- **CRM opportunity:** a Category dropdown and **+ Add category** are added. The selected category is saved when creating/editing an opportunity and displayed on its pipeline card. Existing opportunities remain uncategorised until edited; nothing is backfilled.
- **New project:** use **+ Add category** under Category.
- A **Categories** button in the top bar lets staff, including view-only staff, add labels without creating or editing a business record.
- The three sections have separate lists. A new category becomes available to colleagues when they reopen the relevant form. Organisation boundaries are enforced.
- Names are 3–60 characters, whitespace is normalised, and matching names with different capitalisation reuse the same entry. Every new stored category records its creator and creates an audit entry.
- This grants category creation only. Module/record access, finance approvals, staff accounts and other settings are preserved. New categories have no staff rename/delete function, so existing records cannot be disrupted.
- Original admin-managed request purposes remain in their existing manager. New shared categories are in the separate catalogue.

## 1. Install the files in Codespaces

Keep a current backup of your real work. Upload **CAGE_Staff_Categories.zip** into the repository root using the Codespaces file Explorer.

```bash
cd /workspaces/cage-operations-hub
git status --short
```

If changes are listed, save/commit them first. Do not discard work. Starting from the branch with your latest working changes:

```bash
git switch -c staff-categories
unzip CAGE_Staff_Categories.zip
python3 category-update/install.py
npm run check
git diff --check
```

The installer checks expected code before changing anything. If it says STOP, share that message rather than bypassing it. A second installation deliberately stops. Original edited files are copied into a timestamped `cage-before-staff-categories-...` folder beside the repository; download this folder as a rollback copy.

Files changed: `dist/app.js`, `dist/production.js`, `dist/index.html`.
Files added: `dist/work-categories.js` and the single SQL migration below.
It does not replace runtime-config.js, secrets or the whole repository.

## 2. Run ONE new SQL file

In Codespaces open:

`supabase/migrations/20260924090000_staff_categories.sql`

Copy its complete contents. In Supabase select **CAGE Operations Hub** (`lrvcpiobxqtmcntwhaat`) → **SQL Editor → New query**, paste and run once as the database owner.

Expected result: **Success. No rows returned.** The single transaction creates the private category table and checked list/add functions. It does not delete or update existing business records. If it fails, stop and share the error; do not replay old migrations, use db reset or db push.

## 3. Deploy through GitHub

No Edge Function deployment, new secrets or schedules are required.

```bash
git add dist/app.js dist/production.js dist/index.html dist/work-categories.js supabase/migrations/20260924090000_staff_categories.sql
git commit -m "Allow staff to add shared request CRM and project categories"
git push -u origin staff-categories
```

Create a GitHub pull request from **staff-categories → main**. Review its files and merge when checks pass. Wait for the frontend deployment and refresh the Hub. If your working branch includes another unmerged feature, review those additional changes and complete that feature's separate installation requirements too.

## 4. Check it live

This package was tested locally; the assistant has not installed or verified it in the live Hub.

1. Sign in as an ordinary staff member. Open **Categories**, select the appropriate section and add a legitimate category you intend to keep.
2. On another staff account, open the relevant request/opportunity/project form and confirm the category appears.
3. Select the category on a legitimate new record and confirm it remains after refreshing. For CRM, reopen Edit opportunity and check that the same category stays selected.
4. Try adding the same label with different capitalisation; it should reuse the existing category.
5. Verify a view-only staff account can add a label through Categories but still cannot edit business records.
6. Confirm existing request purposes, Finance and ordinary workspace saves still work. Avoid creating fake live records solely for testing.

## Backup and rollback

The installer's external folder contains the original three edited frontend files. Revert the feature commit through a reviewed GitHub PR to restore the previous UI without deleting any business records or categories. Do not restore an old database backup over current work.

If immediate API shutdown is needed, the database owner can run:

```sql
begin;
revoke execute on function public.hub_category_list(text),public.hub_category_add(text,text) from authenticated;
notify pgrst,'reload schema';
commit;
```

Keep the private category table and any created categories intact while reviewing. Do not rerun the installation SQL to re-enable it; review and restore function grants separately.

## Local validation

- Migration tested against the previously supplied schema using isolated PGlite and synthetic users only: member/viewer creation; duplicate normalisation; validation; module/organisation isolation; shared/inactive/anonymous denial; no direct table access; audit exactly once per stored category.
- Chromium tests with mocked API: additions and selections in all three forms; duplicates; failure handling; safe text rendering; view-only category manager.
- Actual patched CRM create/edit function tested for category persistence.
- Installed on a clean copy of the latest uploaded ZIP, with JavaScript syntax and existing production checks passing. No real recipients contacted or business data modified.

For technical reproduction, tests require `@electric-sql/pglite` and `playwright`. Supply the prior schema dump with `CAGE_TEST_SCHEMA`, the installed app file with `CAGE_TEST_APP`, and a Chromium binary with `CAGE_TEST_BROWSER`. Tests never connect to Supabase.
