from pathlib import Path
from datetime import datetime,timezone
import re,shutil
root=Path.cwd();pkg=Path(__file__).resolve().parent;changes={}
def one(s,a,b):
 if s.count(a)!=1:raise SystemExit('STOP: code differs. No files changed. Expected: '+a[:100])
 return s.replace(a,b,1)
p='dist/index.html';s=(root/p).read_text()
if 'work-categories.js' in s:raise SystemExit('Category update already installed. No files changed.')
s=one(s,'Admins can add more purposes from Request centre.','Staff can add a shared category below. Administrators can manage the original purposes from Request centre.')
s=one(s,'<label class="field"><span>Organisation *</span><input name="company" required placeholder="Client or partner"></label>','<label class="field"><span>Organisation *</span><input name="company" required placeholder="Client or partner"></label>\n        <label class="field"><span>Category</span><select name="category"><option value="">Uncategorised</option><option>Mapping &amp; Data</option><option>Training</option><option>Agriculture</option><option>Equipment Hire</option><option>Disaster Risk</option><option>Internal</option></select></label>')
s=one(s,'</body>','<script src="./work-categories.js?v=20260924-1" defer></script>\n</body>')
for file in ['app','production']:
 s,n=re.subn(r'(src="\./'+file+r'\.js\?v=)[^"\s]+',r'\g<1>categories-20260924-1',s)
 if n!=1:raise SystemExit('STOP: script tag differs. No files changed.')
changes[p]=s
p='dist/production.js';s=(root/p).read_text();s=one(s,'    presenceHeartbeat,','    categoryList: async(category_module)=>{const r=await client.rpc("hub_category_list",{category_module});if(r.error)throw r.error;return r.data;},\n    categoryAdd: async(category_module,category_name)=>{const r=await client.rpc("hub_category_add",{category_module,category_name});if(r.error)throw r.error;return r.data;},\n    presenceHeartbeat,');changes[p]=s
p='dist/app.js';s=(root/p).read_text()
s=one(s,'  editingDealId = dealId;','  editingDealId = dealId;\n  window.CAGE_CATEGORIES?.select("deal-form",dealById(dealId)?.category||"");')
s=one(s,'    project: existing?.project || ""','    project: existing?.project || "",\n    category: String(data.get("category") || "").trim()')
s=one(s,'<input class="inline-deal-company"','${deal.category ? `<small class="project-client">${escapeHtml(deal.category)}</small>` : ""}\n              <input class="inline-deal-company"')
changes[p]=s
for p,src in [('dist/work-categories.js',pkg/'payload/work-categories.js'),('supabase/migrations/20260924090000_staff_categories.sql',pkg/'01_STAFF_CATEGORIES.sql')]:
 if (root/p).exists():raise SystemExit('STOP: destination exists: '+p)
 changes[p]=src.read_text()
backup=root.parent/('cage-before-staff-categories-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f'));backup.mkdir()
for p in changes:
 if (root/p).exists():
  b=backup/p;b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/p,b)
for p,s in changes.items():
 target=root/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(s)
print('Installed code; SQL has NOT run. Original files saved:',backup)
print('\n'.join(changes))
