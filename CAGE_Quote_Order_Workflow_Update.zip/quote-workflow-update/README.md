# CAGE quotation and purchasing workflow

Prepared 27 September 2026. This package changes local code only. No database migration, deployment or client email has been performed for you.

## What changes

Finance lists show one main action and a secondary actions menu. Open a quotation to follow acceptance, order document, invoice and payment history.

- Record a client's agreement made by phone, WhatsApp, email or in person, including contact, date, note and optional evidence. The history identifies the staff member who recorded it.
- Review and send an acceptance notification, including “As agreed…” details.
- Choose an uploaded client LPO, a CAGE-prepared PO for client approval, or an order confirmation when no LPO is required.
- CAGE-prepared POs remain clearly marked drafts until staff record the client's approval. This release records external approval; it does not introduce a public PO approval portal or fabricate a client-issued LPO.
- A “This client requires an LPO” setting prevents use of an order confirmation.
- Client LPO amount and currency must match the accepted quotation. Staff must check the uploaded document's scope; the app does not extract or interpret the PDF automatically.
- Create one linked invoice from the accepted quotation; repeated conversion opens the same invoice. Invoice PDFs include the client LPO/order reference.
- Preview and email stamped order PDFs. Email is sent only after staff review and click Send.
- Keep linked accepted quotations, invoice scope and supporting evidence protected. Use a quotation revision for a changed agreement. Existing unrelated records retain their existing editing/deletion controls.

## Install

Prerequisites: your working payment receipts, record management and chat-send fixes. The installer checks exact source versions before writing anything. If it stops because a file differs, share that output rather than forcing replacement.

Upload `CAGE_Quote_Order_Workflow_Update.zip` into the Codespaces repository folder, then run:

```bash
cd /workspaces/cage-operations-hub
git switch -c quote-order-workflow
unzip CAGE_Quote_Order_Workflow_Update.zip
python3 quote-workflow-update/install.py
npm run check
```

If you uploaded the ZIP through GitHub on `main`, fetch that file first on your current branch:

```bash
git fetch origin
git restore --source=origin/main -- CAGE_Quote_Order_Workflow_Update.zip
```

The installer backs up overwritten files outside the repository and can be run twice safely. It does not touch runtime-config.js or credentials.

## Apply the database update

In the Supabase SQL Editor for the project used by this app, run the full contents of:

`supabase/migrations/20260927100000_quote_order_workflow.sql`

Wait for success before publishing the frontend. Do not blindly run all older migrations: some migration files in the supplied source contained terminal commands instead of SQL. This package does not replace those historical files.

## Deploy the functions

From the same repository linked to your app's Supabase project:

```bash
npx supabase functions deploy send-order-document --use-api --no-verify-jwt
npx supabase functions deploy send-document-v2 --use-api
```

The new email function validates the signed-in user and finance permissions itself. It uses the existing RESEND_API_KEY and CAGE sender setup. Redeploying send-document-v2 is needed for LPO/order references in emailed invoice PDFs. The existing receipt function is unchanged.

## Publish the frontend

Review `git diff` and commit only the paths listed in MANIFEST.json (not the downloaded ZIP, installer directory or credentials). Push this branch and merge it through your normal frontend deployment process. Refresh the app after deployment.

## First check

Use a test quotation addressed to an email inbox you control:

1. Send the quotation, then record external client acceptance.
2. Expand Documents and notifications to preview the acceptance email; send only to your test inbox.
3. Choose an order confirmation, generate the invoice, and reopen the workflow to verify the same invoice is linked.
4. Separately test a CAGE-prepared PO: preview its draft, record approval, then create the invoice.
5. Upload a matching client LPO and verify its original file opens and its reference appears on the invoice PDF.

Do not create test payments against real invoices. Existing receipts remain available through the payment history.

## Rollback

Restore overwritten frontend/function source files from the backup path printed by the installer and redeploy those versions. The database update should be retained if staff have started recording agreements: removing it would discard or disconnect workflow history. Seek a reviewed database rollback before removing tables or functions.
