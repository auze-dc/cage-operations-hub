# Validation

Verified locally against the supplied repository plus the previously delivered chat-send patch. No production database or live email provider was accessed.

- Applied the workflow SQL in an isolated PGlite PostgreSQL environment with the existing repository migrations and recovered SQL from the supplied earlier update packages. Test-only mocks replace auth/storage setup and extensions.
- Passed staff acceptance, ordinary finance-editor acceptance, viewer denial and cross-organization denial.
- Passed required-LPO gating, draft-PO approval gating, LPO amount mismatch rejection, stale-version rejection, one linked invoice on repeated conversion and invoice scope protection.
- Confirmed linked attachment deletion is denied and the evidence-protection trigger rejects privileged deletion.
- Passed a browser test using the complete composed frontend, with mocked backend responses: compact quotation actions, external acceptance, order confirmation and invoice creation; no page script errors.
- Passed email tests with mocked transport: authorization, stale version, draft labels, escaped message text, PDF attachment, unchanged retry payload, duplicate-send prevention and expired-retry guard.
- Generated and visually reviewed four one-page stamped PDFs plus a long client-reference layout. Samples are in examples/.
- Installer, repeat installation, JavaScript syntax and repository production checks are run during packaging.

Limits: local mocks do not test your deployed Supabase policies, network, email delivery or frontend hosting configuration. Complete the test-inbox smoke check in README after deployment.
