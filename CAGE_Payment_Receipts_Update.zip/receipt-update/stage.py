from pathlib import Path
import json,subprocess
package=Path(__file__).resolve().parent
paths=[e['path'] for e in json.loads((package/'MANIFEST.json').read_text())]
subprocess.run(['git','add','--',*paths],check=True)
print('Staged only the update files. Review with git diff --cached --stat.')
