# CAGE Payment Receipts Update

Install after the Record Management and Popup / Month Filter updates. This package has been tested locally; nothing has been deployed to your live Hub by this package.

## What it adds

- Finance → Record payment / deposit → a numbered payment receipt opens after saving.
- Finance → Payment receipts → search existing payments, download a receipt or email it to a client.
- Full and partial payments show amount received, invoice total, total paid, remaining balance, payment date, method and reference.
- CAGE logo and dated stamp. Stamp placement varies by receipt and uses empty space; no stamp-only extra page.
- Exact payment retries return the existing payment. Email retries reuse the registered email and provider idempotency key; a confirmed receipt is not resent to the same address.
- Receipt content is captured when a payment is recorded, so later invoice edits do not rewrite it.
- Existing payments can receive a receipt. Their balance is captured when the receipt is first issued and the PDF labels that distinction.
- No automatic emails. Staff must choose Email receipt and check the destination address.

## 1. Install in Codespaces

Upload CAGE_Payment_Receipts_Update.zip to the repository folder in Codespaces. If you uploaded it through the GitHub website to main instead, first run:

```bash
cd /workspaces/cage-operations-hub
git fetch origin
git show origin/main:CAGE_Payment_Receipts_Update.zip > CAGE_Payment_Receipts_Update.zip
```

Then run:

```bash
git switch -c payment-receipts
unzip CAGE_Payment_Receipts_Update.zip
python3 receipt-update/install.py
npm run check
```

The installer checks all file versions before changing anything and backs up originals outside the repository. If it reports a mismatch, stop and share that output; do not force it. No runtime-config or secrets are included. If the branch already exists, use `git switch payment-receipts`.

## 2. Apply SQL in Supabase

Open the SQL Editor for project `lrvcpiobxqtmcntwhaat`. Paste and run the entire installed file:

`supabase/migrations/20260925170000_payment_receipts.sql`

It adds receipt fields and an email delivery audit table. It does not send emails, create payment transactions, or remove records.

## 3. Deploy the new email function

```bash
npx supabase functions deploy send-payment-receipt --project-ref lrvcpiobxqtmcntwhaat --use-api --no-verify-jwt
```

The function validates the signed-in user itself and checks invoice access. It uses the existing RESEND_API_KEY and EMAIL_FROM used by document sending. Do not paste secrets into chat. The existing send-document-v2 function does not need redeployment for this update.

## 4. Publish the frontend

```bash
python3 receipt-update/stage.py
git diff --cached --stat
git commit -m "Add stamped payment receipts with PDF and email delivery"
git push -u origin payment-receipts
```

Open a pull request to main, merge it, and wait for your Cloudflare Pages deployment. Refresh the Hub after deployment.

## 5. Use it

1. Open Finance and select Record payment / deposit after confirming receipt of the client's payment.
2. Choose the invoice, enter the received amount, date, method and unique payment reference. Payment proof upload remains optional.
3. Save. The receipt opens with Download receipt PDF and Email receipt.
4. Check the client email address and click Email receipt when ready.
5. Reopen receipts later from Finance → Payment receipts.

Marking an invoice Paid manually does not create a payment or receipt: use Record payment / deposit. Do not record the same money twice. If a save times out, retry with the same reference and details.

If email delivery is uncertain, retry the same recipient. After 23 hours an uncertain attempt requires checking provider history; the receipt is still downloadable. Changing the recipient is a separate delivery.

The stamp uses the receipt issue date in Malawi time; Date at the top is the date payment was received. Receipt numbers are unique and can have gaps. Deleting a mistaken payment uses the existing in-app confirmation and retains the audit snapshot; it cannot recall a PDF already sent to a client.

Sample PDFs in examples use fictional data.
