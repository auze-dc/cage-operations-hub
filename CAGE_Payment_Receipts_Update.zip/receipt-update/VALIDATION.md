# Local validation

Passed:
- Existing production check script and JavaScript syntax checks.
- SQL integration against the supplied database schema: partial/full payments, balance/status updates, exact retry deduplication, conflicting reference/method rejection, overpayment/negative amount rejection, receipt snapshots surviving invoice edits, cross-organization denial, viewer read/write boundary, stable legacy receipt issue, existing payment deletion compatibility.
- Browser tests: receipt lookup, PDF download control, email error/retry, auth-close cleanup, no automatic sending, full page script/control integration.
- Email handler tests: unauthenticated and inaccessible receipts denied, escaped client text, frozen email payload, same idempotency key after network/save failure, confirmed email deduplication, expired attempt guard.
- PDF tests and visual review: partial, full and long-reference receipts fit one page with the stamp in empty space; existing invoice generation still fits one page.
- Installer hash checks against the prior update baseline and repeat installation.

No live Supabase, Cloudflare or email-provider call was performed. Complete the installation steps and verify a real receipt before relying on live delivery. Tests use fixture data and mocked email transport.
