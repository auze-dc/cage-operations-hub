import fs from 'node:fs';import http from 'node:http';import path from 'node:path';import assert from 'node:assert/strict';
import {chromium} from 'playwright';
const root=path.resolve(process.env.CAGE_TEST_DIST||'dist');
const server=http.createServer((req,res)=>{try{let name=new URL(req.url,'http://local').pathname;let body=fs.readFileSync(path.join(root,name==='/'?'index.html':name));if(name==='/index.html')body=body.toString().replace(/<script[\s\S]*?<\/script>/g,'');if(name==='/runtime-config.js')body='window.CAGE_CONFIG={supabaseUrl:"https://test.invalid",supabaseAnonKey:"public-test"};';res.setHeader('Content-Type',name.endsWith('.js')?'text/javascript':name.endsWith('.css')?'text/css':name.endsWith('.png')?'image/png':'text/html');res.end(body);}catch{res.statusCode=404;res.end();}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port;
const browser=await chromium.launch({executablePath:process.env.CAGE_TEST_BROWSER,args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu','--no-zygote']});
const errors=[];let sent=0,complete=false;
const page=await browser.newPage({viewport:{width:1365,height:1000}});page.on('pageerror',e=>errors.push(e.message));
await page.route('**/*',route=>route.request().url().startsWith(base)?route.continue():route.abort());
await page.goto(base+'/index.html');
await page.evaluate(()=>{window.CAGE_BACKEND={documentHistory:async()=>[{createdAt:new Date().toISOString(),to:['client@example.invalid'],cc:[],bcc:[],emailStatus:'Provider accepted',invitationStatus:'Provider accepted',approver:'client@example.invalid',decision:'Accepted',name:'Client <script>',note:'Please proceed.',respondedAt:new Date().toISOString()}]};document.getElementById('auth-gate').style.display='none';document.body.classList.remove('auth-pending','session-checking');});
await page.addScriptTag({path:root+'/document-delivery.js'});
await page.evaluate(()=>{const f=document.getElementById('send-form');f.elements.documentType.value='quote';f.elements.documentId.value='q1';f.elements.recipient.value='client@example.invalid, other@example.invalid';CAGE_DELIVERY.open('quote',{status:'Approved'},f);document.getElementById('send-dialog').showModal();});
assert.equal(await page.locator('#send-form [name=clientApprover] option').count(),3);
await page.locator('#send-form [name=clientApprover]').selectOption('client@example.invalid');await page.locator('#send-form [name=deliveryCc]').fill('copy@example.invalid');await page.locator('#send-form [name=deliveryBcc]').fill('private@example.invalid');
const captured=await page.evaluate(()=>CAGE_DELIVERY.fields({type:'quote',record:{id:'q1',status:'Approved'},recipient:document.getElementById('send-form').elements.recipient.value}));assert.equal(captured.approver,'client@example.invalid');assert.equal(captured.bcc[0],'private@example.invalid');
assert.equal(await page.locator('#send-form [name=recipient]').evaluate(e=>e.checkValidity()),true);
await page.locator('#send-form [name=deliveryCc]').fill('invalid');assert.equal(await page.locator('#send-form [name=deliveryCc]').evaluate(e=>e.checkValidity()),false);await page.locator('#send-form [name=deliveryCc]').fill('copy@example.invalid');
await page.screenshot({path:new URL('./compose-desktop.png',import.meta.url).pathname});
await page.setViewportSize({width:390,height:844});assert(await page.locator('#send-dialog').evaluate(e=>e.getBoundingClientRect().width<=390));
await page.screenshot({path:new URL('./compose-mobile.png',import.meta.url).pathname});
await page.evaluate(()=>{document.getElementById('send-dialog').close();const b=document.createElement('button');b.dataset.sendDocument='quote';b.dataset.documentId='q1';document.body.append(b);});await page.locator('[data-delivery-history]').last().click();assert((await page.locator('#document-history-content').innerText()).includes('Client <script>'));assert.equal(await page.locator('#document-history-content script').count(),0);
await page.close();
const client=await browser.newPage({viewport:{width:390,height:844}});client.on('pageerror',e=>errors.push(e.message));
await client.route('**/*',route=>{
 if(route.request().url().startsWith(base))return route.continue();
 if(route.request().url()==='https://test.invalid/functions/v1/quote-response'){
  const p=route.request().postDataJSON();if(p.action){sent++;if(sent===1)return route.fulfill({status:502,json:{error:'Connection interrupted. Retry.'}});complete=true;}
  return route.fulfill({status:200,json:complete?{number:'Q-1',decision:'Accepted',name:'Test Client',respondedAt:new Date().toISOString()}:{number:'Q-1',client:'Example test client',description:'A safe preview <script>',currency:'MWK',amount:100,validUntil:'2099-12-31',approver:'client@example.invalid',pdf:{filename:'Q-1.pdf',content:'JVBERi0xLjQ='}}});
 }return route.abort();});
await client.goto(base+'/quote-response.html#'+'a'.repeat(64));await client.locator('#details').waitFor({state:'visible'});assert.equal(sent,0);assert.equal(await client.locator('#description').innerText(),'A safe preview <script>');
assert(await client.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
await client.screenshot({path:new URL('./response-mobile.png',import.meta.url).pathname});
await client.locator('[name=name]').fill('Test Client');await client.locator('[name=action]').selectOption('Changes requested');assert.equal(await client.locator('[name=note]').evaluate(e=>e.required),true);
await client.locator('[name=action]').selectOption('Accepted');await client.locator('[name=authorised]').check();await client.locator('button[type=submit]').click();await client.locator('#error').waitFor({state:'visible'});assert.equal(sent,1);assert(await client.locator('button[type=submit]').isEnabled());await client.locator('button[type=submit]').click();await client.locator('#success').waitFor({state:'visible'});assert.equal(sent,2);
await client.reload();await client.locator('#success').waitFor({state:'visible'});assert.equal(sent,2);assert.equal(await client.locator('#details').isVisible(),false);assert.deepEqual(errors,[]);
await browser.close();await new Promise(r=>server.close(r));console.log('PASS Chromium: To/CC/BCC and approver forms, email validity, private history escaping, mobile dialog, public mobile response, no acceptance on open, required confirmation/change note, network error retry and refresh. Mocked endpoints only.');
