import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';import {stripTypeScriptTypes} from 'node:module';
import {recipients,content,canonical,sha256,expiry} from '../payload/supabase/functions/_shared/document-recipients.js';
const people=recipients({type:'invoice',recipient:' A@example.org; b@example.org',cc:'a@example.org,C@example.org',bcc:'C@example.org,d@example.org'});
assert.deepEqual(people,{to:['a@example.org','b@example.org'],cc:['c@example.org'],bcc:['d@example.org'],approver:null});
assert.throws(()=>recipients({type:'invoice',recipient:'bad'}),/valid email/);
assert.throws(()=>recipients({type:'quote',recipient:'a@example.org',approver:'cc@example.org'}),/To recipient/);
assert.throws(()=>recipients({recipient:Array.from({length:51},(_,i)=>`x${i}@example.org`)}),/50/);
assert.throws(()=>expiry({validUntil:'2020-01-01'}),/expired/);
assert.equal(expiry({validUntil:'2026-09-23'},Date.parse('2026-09-23T00:00:00Z')),'2026-09-23T21:59:59.000Z');
let attempts=new Map(),calls=[],role='edit',active=true,visible=true,failInvite=true,dbSaveFail=false;
const record={id:'q1',number:'Q-1',status:'Approved',description:'<script>evil</script>',validUntil:'2099-12-31',amount:100};
const user={auth:{getUser:async()=>({data:{user:{id:'staff'}}})},rpc:async(name)=>({data:name==='module_level'?role:visible})};
const db={from(table){const filters={};let update;return {select(){return this},eq(k,v){filters[k]=v;return this},update(values){update=values;return this},single(){return this.run()},maybeSingle(){return this.run()},then(resolve,reject){return this.run().then(resolve,reject)},async run(){
 if(table==='profiles')return {data:{organization_id:'org',active,email:'staff@example.invalid'}};
 if(table==='workspace_states')return {data:{data:{quotes:[record],invoices:[record]}}};
 if(table==='document_sends_v2'){
  const row=attempts.get(filters.id);if(update){if(dbSaveFail){dbSaveFail=false;return {error:{message:'mock DB interruption'}};}Object.assign(row,update);}
  return {data:row?structuredClone(row):null};
 }throw Error('Unexpected table '+table);
 }}},rpc:async(name,{entry})=>{assert.equal(name,'register_document_send_v2');if(!attempts.has(entry.id))attempts.set(entry.id,{...entry,created_at:new Date().toISOString()});return {data:structuredClone(attempts.get(entry.id))};}};
let handler,pdfs=0;
const sandbox={Response,Request,Headers,AbortSignal,DOMException,TypeError,Error,TextEncoder,crypto,Uint8Array,Intl,Date,atob,btoa,recipients,content,canonical,sha256,expiry,PDFLib:{},logoBase64:'',createClient:(url,key)=>key==='anon'?user:db,Deno:{env:{get:k=>({SUPABASE_URL:'https://test.invalid',SUPABASE_ANON_KEY:'anon',SUPABASE_SERVICE_ROLE_KEY:'service',RESEND_API_KEY:'mock',EMAIL_FROM:'test@example.invalid'})[k]},serve:f=>handler=f},CagePDF:{stampDateAt:()=>'',createDocumentPDF:async()=>{pdfs++;return new Uint8Array([1,2,3]);}},fetch:async(url,opts)=>{assert.equal(url,'https://api.resend.com/emails');const key=opts.headers['Idempotency-Key'];calls.push({key,body:JSON.parse(opts.body)});if(key.endsWith('invitation')&&failInvite){failInvite=false;return new Response('{}',{status:503});}return new Response(JSON.stringify({id:'provider-'+key}));}};
let source=fs.readFileSync(new URL('../payload/supabase/functions/send-document-v2/index.ts',import.meta.url),'utf8').replace(/^import .*;\n/gm,'');
vm.runInNewContext(stripTypeScriptTypes(source),sandbox);
const payload={type:'quote',record,recipient:'client@example.invalid,second@example.invalid',cc:'copy@example.invalid',bcc:'private@example.invalid',approver:'client@example.invalid',subject:'Q-1',message:'Please review',deliveryAttempt:crypto.randomUUID()};
const run=async(p=payload)=>{const r=await handler(new Request('https://test.invalid',{method:'POST',headers:{Authorization:'Bearer test'},body:JSON.stringify(p)}));return {status:r.status,body:await r.json()};};
assert.equal((await run()).status,502);assert.equal(calls.length,2);
assert(!calls[0].body.html.includes('quote-response.html'));assert(!calls[0].body.html.includes('<script>'));assert.deepEqual(calls[0].body.to,['client@example.invalid','second@example.invalid']);assert.equal(calls[0].body.bcc[0],'private@example.invalid');
assert.deepEqual(calls[1].body.to,['client@example.invalid']);assert(!calls[1].body.bcc);assert(calls[1].body.html.includes('quote-response.html#'));
assert.equal((await run()).status,200);assert.equal(calls.length,3);assert.equal(calls[1].key,calls[2].key);assert.deepEqual(calls[1].body,calls[2].body);assert.equal(pdfs,1);
assert.equal((await run()).status,200);assert.equal(calls.length,3);
assert.equal((await run({...payload,subject:'Different'})).status,409);
active=false;assert.equal((await run()).status,403);active=true;role='view';assert.equal((await run()).status,403);role='edit';visible=false;assert.equal((await run()).status,403);visible=true;
const invoice={...payload,type:'invoice',deliveryAttempt:crypto.randomUUID()};dbSaveFail=true;
assert.equal((await run(invoice)).status,502);const first=calls.at(-1);assert.equal((await run(invoice)).status,200);assert.equal(first.key,calls.at(-1).key);assert.deepEqual(first.body,calls.at(-1).body);
// Public endpoint: explicit authorisation confirmation, malformed token, no GET mutations.
let publicHandler,rpcs=0;
const publicSource=fs.readFileSync(new URL('../payload/supabase/functions/quote-response/index.ts',import.meta.url),'utf8').replace(/^import .*;\n/gm,'');
vm.runInNewContext(stripTypeScriptTypes(publicSource),{Response,sha256,Deno:{env:{get:()=>''},serve:f=>publicHandler=f},createClient:()=>({rpc:async()=>{rpcs++;return {data:{decision:'Accepted'}};}})});
const publicCall=(data,method='POST')=>publicHandler(new Request('https://test.invalid',{method,body:method==='GET'?undefined:JSON.stringify(data)}));
assert.equal((await publicCall({},'GET')).status,405);assert.equal((await publicCall({token:'x'})).status,400);assert.equal((await publicCall({token:'a'.repeat(64),action:'Accepted',authorised:false})).status,400);assert.equal(rpcs,0);
assert.equal((await publicCall({token:'a'.repeat(64),action:'Accepted',authorised:true,name:'Client'})).status,200);assert.equal(rpcs,1);
console.log('PASS mocked Edge: recipient validation/deduplication, 50 limit, private approver invitation, HTML escaping, partial failure/retry, frozen provider idempotency, DB status failure recovery, unauthorised sends, public response confirmation. Zero live email/network calls.');
