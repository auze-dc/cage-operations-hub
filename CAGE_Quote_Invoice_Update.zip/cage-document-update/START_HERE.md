# CAGE quotes and invoices: multiple recipients and client responses

This is an implementation package, not a live deployment. Your records, staff accounts, runtime configuration, existing email secrets and PDF signature removal are preserved. The installer patches specific sections of your current files rather than replacing them with an older release.

## What changes

- Quotes and invoices support multiple **To**, **CC** and **BCC** recipients. Use comma-separated email addresses, up to 50 unique recipients in total. Duplicates are removed across To, then CC, then BCC. They receive the same document number and PDF.
- When sending a quote, choose one To recipient as the **authorised client approver**. A single To recipient is selected automatically. Other recipients get the PDF email; only the approver gets a second, private email with the response link.
- The client can download the exact PDF sent, enter their name, confirm they are authorised, then **Accept quote**, **Request changes**, or **Decline quote**.
- Acceptance sets the quote to **Accepted** and protects it against accidental editing/deletion. Use a new quote for later revisions. Requesting changes returns the quote to **Draft**, requiring review and approval before resending. Decline sets it to **Declined**. This does not automatically create an invoice, project or contract.
- The sender and relevant assigned owner receive an in-app notice, subject to record visibility. Staff email uses the existing queue, schedule and each person's email preferences. In-app-only preferences are respected.
- A **History** button beside quote/invoice Send buttons shows new delivery attempts and client responses. BCC history is visible only to the sender and administrators. Older sends remain in your existing email logs.
- Replies to the document email go to the staff sender's profile email address.
- A private link expires at the earlier of the quotation validity date's end in Malawi time and 30 days after preparation. Changed, withdrawn or superseded quotes cannot be accepted using an old link. Opening a link never accepts a quote.

CC/BCC and approver selection apply to the current send, not to a saved draft's persistent fields. To recipients are saved on the document. Response identity is based on possession of the designated recipient's private email link plus the name they enter; this is not independent identity verification or a digital signature. Recipients should not forward their private link.

## 1. Prepare in Codespaces

Use the repository version containing your working signature-removal and fresh-start fixes. Save and commit any current code work first; do not discard it. Take a current backup now that real work has started—your earlier demo-data backup is not a backup of today's work.

Download `CAGE_Quote_Invoice_Update.zip`. Upload that ZIP into the **top level of the cage-operations-hub folder** using the Codespaces Explorer. Open its terminal:

```bash
cd /workspaces/cage-operations-hub
git status --short
```

If this shows existing modified files, finish saving that work before proceeding. Then create a separate branch and unpack the update:

```bash
git switch -c quote-recipient-responses
unzip CAGE_Quote_Invoice_Update.zip
python3 cage-document-update/install_document_update.py
npm run check
```

The installer checks all expected code sections before writing. If it says **STOP**, leave the files as they are and share that message for a revised patch. It also prints a backup folder outside your repository containing the original files it edited.

**Do not upload the package's `payload` folder directly over the live website.** The installer combines these new files with targeted patches to your current repository. It leaves `runtime-config.js`, your PDF renderers, old `send-document` function and existing records untouched.

## 2. Install the one SQL update

In Supabase, select **CAGE Operations Hub** (`lrvcpiobxqtmcntwhaat`). Open **SQL Editor → New query**.

In Codespaces, open:

```text
supabase/migrations/20260923150000_document_responses_v2.sql
```

Copy its entire contents into the new SQL query and run it **once** as the database owner. It adds the private send/response table, restricted functions and protective triggers. There are no deletes, resets or changes to existing rows.

If SQL fails, stop and share the error. Do not run old migrations, `db reset`, or `db push`. The file uses one transaction: an error prevents a partial installation. A second execution deliberately fails on the existing table rather than replacing data.

## 3. Deploy the functions

Run these commands in the repository terminal, one at a time:

```bash
npx supabase login
```

```bash
npx supabase functions deploy send-document-v2 --project-ref lrvcpiobxqtmcntwhaat --use-api
```

```bash
npx supabase functions deploy quote-response --project-ref lrvcpiobxqtmcntwhaat --no-verify-jwt --use-api
```

```bash
npx supabase functions deploy staff-email-dispatch --project-ref lrvcpiobxqtmcntwhaat --no-verify-jwt --use-api
```

Wait for each command to report successful deployment. `--use-api` avoids the local Docker dependency-download failure you encountered previously.

`quote-response` is deliberately public so clients do not need staff accounts. It validates a private random token and uses a restricted server-side transaction. The staff dispatcher retains its existing `STAFF_EMAIL_CRON_SECRET` check; it is invoked by the existing scheduled job. `send-document-v2` requires staff authentication and existing Finance/record permissions.

**No new secrets or scheduled jobs are required.** Keep the working `RESEND_API_KEY`, `EMAIL_FROM`, `APP_URL`, `STAFF_EMAIL_CRON_SECRET` and existing Cron commands unchanged. Ensure the existing staff-email-dispatch job is active. If email preferences select digest delivery, the feedback email follows that existing schedule.

The client response link is for your production domain **https://hub.cagemw.com**. This package is not configured for a different domain.

## 4. Deploy the website through GitHub

Review the changes:

```bash
git diff --stat
git diff --check
```

Stage only the feature files:

```bash
git add dist/app.js dist/production.js dist/index.html dist/document-delivery.js dist/quote-response.html dist/quote-response.js dist/quote-response.css supabase/config.toml supabase/functions/send-document-v2/index.ts supabase/functions/quote-response/index.ts supabase/functions/_shared/document-recipients.js supabase/functions/_shared/staff-email-rules.ts supabase/migrations/20260923150000_document_responses_v2.sql
git commit -m "Support multiple document recipients and client quotation responses"
git push -u origin quote-recipient-responses
```

Do not commit the ZIP, backup directories, database exports or `node_modules`.

In GitHub, create a pull request from **quote-recipient-responses → main**, review it, and merge it after its checks pass. Wait for **Deploy CAGE Operations Hub** in Actions to succeed. Your existing Cloudflare workflow deploys the `dist` files. Refresh the Hub after deployment.

## 5. Verify with authorised test recipients

Use a clearly labelled test quote/invoice and email accounts you control, never a real client's quote as a test.

1. Confirm your real staff, courses, applications, projects and other records are still present.
2. Create an approved test quote with at least two To recipients, one CC and one BCC. Select the intended approver.
3. Confirm all receive the same PDF without the removed signature line. Only the designated approver should receive the separate response invitation. Other recipients must not see BCC addresses.
4. Open the invitation in a private browser window. Confirm the correct quote and exact PDF appear. Opening it must not change the quote status.
5. Submit acceptance with a name and the authorisation checkbox. Refresh Finance and inspect **History**: quote Accepted, name/email/time recorded. Confirm sender/owner notices and the staff email, if their preferences allow it.
6. Use separate test quotes for requesting changes, decline and an expired quote. Do not try to change an already-recorded acceptance into a different response.
7. Send a test invoice to multiple recipients; it should have no quote-acceptance invitation.
8. Confirm an ordinary member without Finance edit access cannot send, and someone outside the record's access cannot see its history.
9. Verify the client page on a phone and ensure the website opens normally after refresh.

**Delivery wording:** “Provider accepted” means the email provider accepted the request. It does not prove delivery to an inbox. Verify actual inboxes and the provider's delivery events during your live test.

**Retries:** if a send is interrupted, retry the same form without changing the document, recipients or message. The original attempt and PDF are reused. If the main PDF email succeeded but the invitation failed, retry sends only the missing invitation. Attempts older than 23 hours are blocked; review provider history before arranging a fresh attempt. Sending from a different browser/device starts a separate attempt.

## File map

Edited in your repository:

- `dist/app.js`: initialise approver selection; preserve Accepted status and stop follow-up on answered quotes.
- `dist/production.js`: use the new send endpoint, include recipient fields in retry identity, load restricted history.
- `dist/index.html`: load the new UI script and refresh changed-script cache tags.
- `supabase/config.toml`: add settings for the two new endpoints only.
- `supabase/functions/_shared/staff-email-rules.ts`: route quotation feedback through existing access and preference checks.

Added:

- `dist/document-delivery.js`
- `dist/quote-response.html`, `dist/quote-response.js`, `dist/quote-response.css`
- `supabase/functions/send-document-v2/index.ts`
- `supabase/functions/quote-response/index.ts`
- `supabase/functions/_shared/document-recipients.js`
- `supabase/migrations/20260923150000_document_responses_v2.sql`

Existing `supabase/functions/_shared/document-pdf.js` and `logo.ts` are reused during deployment. They are not replaced by this package.

## Safe rollback

If a problem appears, pause quote/invoice sending while investigating. Do not reset or restore the whole database over new real work.

The installer prints `cage-before-document-update-...` with your original edited files. Restore **only `dist/app.js`, `dist/production.js` and `dist/index.html`** from that folder to the same paths in the repository, review the diff, commit and deploy those restores through GitHub. Ask for help if unsure which backup folder is yours.

Keep the new client response page files, response function, SQL tables/triggers and staff-email rule deployed so outstanding client links and recorded responses remain available. Do not drop the new table or remove its safeguards. The old sender is retained, but leave sending paused until compatibility has been reviewed: an older interface may try to change an Accepted quote back to Sent, which the database now correctly refuses.

## Validation and limits

See `VALIDATION.md` for local test results. The production Supabase environment, Cloudflare deployment and real email provider were not accessed for this implementation. Live inbox delivery, actual schedules and your latest repository compatibility must be checked during the steps above. Safari and Brave were not tested locally.
