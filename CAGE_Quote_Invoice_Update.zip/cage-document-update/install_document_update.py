#!/usr/bin/env python3
"""Run from repository root. Patch known anchors; refuse unknown code. No SQL execution."""
from pathlib import Path
import shutil, datetime
root=Path.cwd(); package=Path(__file__).resolve().parent
if not (root/'dist/production.js').exists():
    raise SystemExit('Run this installer from the cage-operations-hub repository root.')
changes={}
def edit(path,old,new):
    p=root/path;s=changes.get(p,p.read_text())
    if new in s:return
    if s.count(old)!=1:raise SystemExit(f'STOP: expected one matching section in {path}, found {s.count(old)}. No files changed. Ask for a reviewed patch.')
    changes[p]=s.replace(old,new,1)
edit('dist/production.js','  async function sendDocument(payload) {','  async function sendDocument(payload) {\n    payload={...payload,...window.CAGE_DELIVERY.fields(payload)};')
edit('dist/production.js','`cage-send-attempt:${profile.id}:${payload.type}:${payload.record.id}`','`cage-send-v2:${profile.id}:${payload.type}:${payload.record.id}`')
edit('dist/production.js','const fingerprint=JSON.stringify([payload.type,payload.record,payload.recipient,payload.subject,payload.message]);',"const fingerprintRecord={...payload.record};for(const key of ['status','recipient','sentAt','automaticFollowUp','clientResponse'])delete fingerprintRecord[key];\n    const fingerprint=JSON.stringify([payload.type,fingerprintRecord,payload.recipient,payload.cc,payload.bcc,payload.approver,payload.subject,payload.message]);")
edit('dist/production.js','client.functions.invoke("send-document", { body: {...payload,deliveryAttempt:attempt.id} })','client.functions.invoke("send-document-v2", { body: {...payload,deliveryAttempt:attempt.id} })')
edit('dist/production.js','  window.CAGE_BACKEND = {','  window.CAGE_BACKEND = {\n    documentHistory: async(doc_type,doc_id)=>{const r=await client.rpc("document_history_v2",{doc_type,doc_id});if(r.error)throw r.error;return r.data||[];},')
edit('dist/app.js','  form.elements.recipient.value = documentRecord.recipient || "";','  form.elements.recipient.value = documentRecord.recipient || "";\n  window.CAGE_DELIVERY.open(type,documentRecord,form);')
edit('dist/app.js','  if (type === "quote") documentRecord.status = "Sent";','  if (type === "quote" && documentRecord.status !== "Accepted") documentRecord.status = "Sent";')
edit('supabase/functions/_shared/staff-email-rules.ts'," if(kind==='decision'){"," if(kind==='quote_response')return arr('quotes').some((r:any)=>r.id===item.target&&r.clientResponse?.attempt===item.attempt);\n if(kind==='decision'){")
edit('dist/app.js','  documentRecord.automaticFollowUp = Boolean(data.get("automaticFollowUp"));','  documentRecord.automaticFollowUp = type === "quote" && documentRecord.clientResponse ? false : Boolean(data.get("automaticFollowUp"));')
# Append only the new function settings; preserve all existing settings.
config=root/'supabase/config.toml'
config_text=config.read_text()
for function_name,jwt in [('send-document-v2','true'),('quote-response','false')]:
    section=f'[functions.{function_name}]'
    expected=f'{section}\nverify_jwt = {jwt}'
    if section in config_text and expected not in config_text:raise SystemExit(f'STOP: review existing {section} settings. No files changed.')
    if section not in config_text:config_text+='\n'+expected+'\n'
if config_text!=config.read_text():changes[config]=config_text
# Retain their current shared renderer (including the signature removal).
for path in ['dist/document-pdf.js','supabase/functions/_shared/document-pdf.js']:
    p=root/path
    if not p.exists() or 'Signature: __________________' in p.read_text():raise SystemExit('STOP: apply the previously supplied signature removal first. No files changed.')
# Only change cache query values for touched scripts; never replace runtime configuration.
p=root/'dist/index.html';s=p.read_text()
if 'document-delivery.js?v=20260923-v2' not in s:
    import re
    for name in ['production.js','app.js']:
        pattern=r'(src="\./'+re.escape(name)+r')(?:\?[^" ]*)?(" defer></script>)'
        s,n=re.subn(pattern,r'\1?v=document-response-20260923-v2\2',s)
        if n!=1:raise SystemExit('STOP: index.html script layout changed. No files changed.')
    marker='</body>'
    if s.count(marker)!=1:raise SystemExit('STOP: index.html body marker not found.')
    s=s.replace(marker,'<script src="./document-delivery.js?v=20260923-v2" defer></script>\n'+marker)
    changes[p]=s
for src in (package/'payload').rglob('*'):
    if src.is_file():
        dest=root/src.relative_to(package/'payload')
        if dest.exists() and dest.read_bytes()!=src.read_bytes():raise SystemExit(f'STOP: {dest} already exists with different contents. No files changed.')
migration=root/'supabase/migrations/20260923150000_document_responses_v2.sql'
if migration.exists() and migration.read_text()!=(package/'01_DOCUMENT_RESPONSES.sql').read_text():raise SystemExit('STOP: migration filename already contains different SQL. No files changed.')
backup=root.parent/('cage-before-document-update-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S'))
for p in changes:
    dest=backup/p.relative_to(root);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
for p,s in changes.items():p.write_text(s)
for src in (package/'payload').rglob('*'):
    if src.is_file():
        dest=root/src.relative_to(package/'payload');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
migration.parent.mkdir(parents=True,exist_ok=True)
migration.write_text((package/'01_DOCUMENT_RESPONSES.sql').read_text())
print('Installed frontend and function source. SQL and deployment still required.')
print('Original edited files saved outside the repository:',backup)
