# Local validation — 23 September 2026

No live database was changed and no email was sent to a real recipient.

| Check | Result / environment |
|---|---|
| Additive SQL, actual existing schema/triggers/policies | Passed in isolated PGlite (PostgreSQL WASM); Auth roles and extensions emulated |
| Preserve workspace reset marker and unrelated team data | Passed |
| Staff/anonymous access to private send table and response RPC | Passed: blocked; staff history checks Finance and record access |
| BCC privacy in staff history and public response data | Passed |
| Acceptance, changes requested, decline | Passed; quote status and response metadata recorded |
| Exact saved quote snapshot; PDF from original frozen email | Passed |
| Invalid, expired, changed and superseded links | Passed: rejected |
| Duplicate response | Passed: no duplicate notices/email queue events |
| Attempt to change an acceptance, remove its metadata or edit accepted contents | Passed: rejected |
| In-app sender/owner notifications and staff queue records | Passed locally; actual worker/email delivery still needs live verification |
| Recipient validation, case-insensitive deduplication, To/CC/BCC, 50 total limit | Passed |
| Approver must be a To recipient; private link absent from main email | Passed with mocked provider |
| Provider rejection, partial invitation failure, saved-status interruption and retries | Passed with mocked provider; frozen body and idempotency key reused |
| Active staff, Finance edit and record access for sending | Passed with mocked authentication/backend responses |
| Provider accepted vs inbox delivered | Distinguished in history; no claim of live delivery |
| Desktop compose and mobile 390px compose/client page | Passed in local Chromium with mocked endpoints; screenshots visually reviewed |
| HTML injection in message/description/history | Escaped in provider HTML and rendered as text in browser tests |
| Opening client link never submits a decision | Passed |
| Required client confirmation/change note; connection error and retry; completed response on refresh | Passed in browser |
| Existing production JavaScript/HTML checks | Passed on installer output |
| Guarded installer, rerun, untouched runtime config and PDF renderers | Passed locally |
| Deployed functions, production database, real inboxes and Cron | Not tested here — deployment and authorised live test required |
| Safari / Brave | Not tested |

## Included regression tests

The `tests` directory contains database, Edge-handler and browser tests. The package's `package.json` describes **test-only** dependencies; the Hub gains no new runtime dependencies. Use Node 24+ for the test harness's TypeScript stripping support.

From the extracted `cage-document-update` folder, developers may run:

```bash
npm install
npm run test:edge
```

For the database test, set `CAGE_TEST_SCHEMA` to an **absolute path to a schema-only export** of the current Hub (not its data export), then run `npm run test:database`. The test creates an isolated in-memory database and synthetic records; it does not connect to Supabase. Keep schema exports out of GitHub unless reviewed for secrets. The test applies the new migration itself, so use a pre-update schema for this regression fixture.

For the browser test, set `CAGE_TEST_DIST` to the absolute path of the installer-patched repository's `dist` folder, install a Playwright Chromium browser with `npx playwright install chromium`, then run `npm run test:browser`. An existing compatible browser can be selected with `CAGE_TEST_BROWSER`. All API/email requests in this test are mocked; nonlocal network requests are blocked. Screenshots are written next to the test.

These tests cannot establish that production secrets, inbox delivery or live job schedules are correct.
