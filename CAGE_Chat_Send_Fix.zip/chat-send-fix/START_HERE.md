# CAGE Chat Send Fix — 27 September 2026

This targeted frontend patch was prepared from your uploaded `cage-operations-hub-main (4).zip`. It does not change runtime-config.js, permissions, database data or Edge Functions.

## Finding

A deterministic local test reproduced a message-loss timing bug in the uploaded source:

1. A previous save finishes, and the sync system publishes its confirmed state to the UI.
2. The UI directly reuses that state's message array.
3. While the following cloud refresh is still in flight, a new message is appended to the UI.
4. That append also changes the supposedly confirmed baseline. Comparing local changes against it finds no new message, so the next refresh can remove the message while reporting no pending changes.

This explains a concrete way to get the symptoms reported. There are no live server logs for the specific first message, so this does not prove exactly what happened to that message or recover it.

## Changes

- Deep-copy cloud data at the UI boundary, keeping editable records separate from the confirmed baseline.
- Accept a save into the in-memory queue only after its local recovery copy is stored successfully.
- Keep chat text and show an error if the queue cannot accept the message; clear the composer only after acceptance.
- Keep a voice recording available if its message cannot be queued, and avoid claiming successful attachment queueing when it failed.
- Use the current Malawi calendar date for new messages, including after the Hub has been open overnight.
- Refresh asset versions for the changed scripts.

## Install

Upload `CAGE_Chat_Send_Fix.zip` into the repository folder in Codespaces.

If you uploaded it to GitHub main instead, fetch the ZIP into Codespaces first:

```bash
cd /workspaces/cage-operations-hub
git fetch origin
git show origin/main:CAGE_Chat_Send_Fix.zip > CAGE_Chat_Send_Fix.zip
```

Then:

```bash
cd /workspaces/cage-operations-hub
git switch -c chat-send-fix
unzip CAGE_Chat_Send_Fix.zip
python3 chat-send-fix/install.py
npm run check
git add dist/app.js dist/production.js dist/personal-work.js dist/index.html
git diff --cached --stat
git commit -m "Fix chat messages lost during cloud refresh"
git push -u origin chat-send-fix
```

If the branch already exists, use `git switch chat-send-fix`. If the installer reports a mismatch, stop and share the output; it checks all versions before changing anything. Originals are backed up outside the repository. Review the staged list before committing if you had other staged changes.

Open the pull request, merge to main, and wait for Cloudflare Pages to finish. No Supabase SQL or Edge Function deployment is needed. Refresh the Hub on staff devices after deployment. Do not clear browser storage or drafts.

## Verify live

Send one clearly identified test message to a colleague, check its message status, and refresh to confirm it remains. Ask the colleague to confirm receipt. The local tests do not replace this live check.

## Local validation completed

- Ran the actual original and patched sync functions with a deliberately delayed cloud refresh: original loses the new message; patched code keeps it pending and saves it in the next flush.
- Checked UI edits no longer mutate confirmed message/project arrays.
- Checked storage failure leaves the previous pending queue intact.
- Ran the actual patched chat send function: successful queueing clears the composer; queue refusal, storage errors and unavailable conversations retain the text.
- JavaScript syntax checks and repository production checks passed.

No live account was accessed and no real chat messages were sent during testing.
