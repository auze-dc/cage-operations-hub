from pathlib import Path
import re,shutil,datetime
repo=Path.cwd()
anchor="text('Add: Area 47 sector 1, ABC, Lilongwe',365,756,9);"
addition="if(type==='quote'||type==='invoice')text('TPIN:31733935',403,744,9,bold);"
changes={}
for name in ['dist/document-pdf.js','supabase/functions/_shared/document-pdf.js']:
 p=repo/name
 if not p.is_file():raise SystemExit('Stopped: missing '+name)
 s=p.read_text()
 if addition in s:continue
 if 'TPIN:' in s or s.count(anchor)!=1:raise SystemExit('Stopped: template differs in '+name+'. Send this message for review.')
 changes[p]=s.replace(anchor,anchor+addition)
p=repo/'dist/index.html'
s=p.read_text()
s,n=re.subn(r'(document-pdf\.js)(?:\?[^"\s]*)?(?=")',r'\1?v=tpin-20260930',s)
if n!=1:raise SystemExit('Stopped: PDF script reference differs. No files changed.')
if s!=p.read_text():changes[p]=s
if not changes:print('TPIN already installed.');raise SystemExit(0)
backup=repo.parent/('cage-before-tpin-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
for p,s in changes.items():
 dest=backup/p.relative_to(repo);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
for p,s in changes.items():p.write_text(s)
print('TPIN installed in quote and invoice headers. Nothing deployed. Backup: '+str(backup))
