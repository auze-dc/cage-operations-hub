CAGE TPIN update
Adds exactly TPIN:31733935 under the company contact details on every generated quotation and invoice PDF page.

Upload ZIP into the Codespaces repository folder, then run:
  unzip CAGE_TPIN_Update.zip
  python3 tpin-update/install.py
  npm run check

The installer patches only the header in dist/document-pdf.js and supabase/functions/_shared/document-pdf.js and updates the browser PDF cache version in dist/index.html. It preserves other edits, runtime config and secrets and backs up changed files outside the repo. It stops before changes if the expected header is missing.

Deploy both quotation/invoice send functions:
  npx supabase functions deploy send-document-v2 --use-api
  npx supabase functions deploy send-document --use-api

Publish frontend changes on a new branch, commit only the three changed files and merge a pull request into main:
  git add dist/document-pdf.js dist/index.html supabase/functions/_shared/document-pdf.js
  git commit -m "Add company TPIN to quotations and invoices"
  git push -u origin finance-tpin

No SQL migration is needed. Existing PDF files already downloaded, stored or emailed are not rewritten; regenerate them to include the TPIN. Quote/invoice previews and newly generated email attachments will include the TPIN after frontend/backend deployment. Receipts and order documents are unchanged.

Validation: generated and visually checked one-page quotation and invoice PDFs; confirmed exact TPIN text in both. Not deployed to production from this environment.
