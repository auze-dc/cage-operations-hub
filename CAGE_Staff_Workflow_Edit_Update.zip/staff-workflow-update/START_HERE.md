# CAGE staff workflow and easy editing

Install the database migration, then deploy the frontend. The performance patch from 8 October must already be installed.

Changes:
- Requests can move through qualification, readiness, submission and award without a manager's decision; checklists stay available for staff to track real completion.
- Normal active staff have business-module edit access. Existing record visibility and private chat restrictions remain.
- Edit details on a project or request opens a small form for names, descriptions, client details and dates.
- Quotes and invoices have a visible Edit button beside the workflow action.
- Editing an accepted quote automatically makes a new draft revision with a new number. No manager approval is required. The original accepted quote, related order, invoices and client acceptance remain historical records. Client acceptance is not carried over to changed terms.
- Linked invoices can be amended through Edit, with a private record of each version. Payment amounts and currency checks remain; the amount cannot be reduced below recorded payments.
- Generic recovery text no longer tells staff to seek administrator permission for every rejected draft. Conflicting drafts still require reviewing the current record.

## 1. Install in Codespaces
Download CAGE_Staff_Workflow_Edit_Update.zip from ChatGPT onto your computer.
Upload it into the repository folder in Codespaces (not just onto the GitHub main branch).
From /workspaces/cage-operations-hub run:

    git switch -c staff-workflow-edit
    unzip CAGE_Staff_Workflow_Edit_Update.zip
    python3 staff-workflow-update/install.py --check
    python3 staff-workflow-update/install.py
    npm run check

If the branch already exists, use `git switch staff-workflow-edit`.
If the installer reports a source mismatch, stop and share the message. It has not changed files. Do not bypass that check.
It backs up replaced files outside the repository and never replaces dist/runtime-config.js.

## 2. Apply database update
Open supabase/migrations/20261008210000_staff_workflow.sql in Codespaces. Copy its entire contents into a NEW Supabase SQL Editor query and Run as postgres.
Expected result: Staff workflow and editing installed.
No Edge Function deployment is needed. Keep cage-push-delivery paused during verification.

## 3. Publish the frontend

    python3 staff-workflow-update/stage.py
    git diff --cached --stat
    git commit -m "Allow staff workflow progression and simplify editing"
    git push -u origin staff-workflow-edit

Open https://github.com/auze-dc/cage-operations-hub/compare/main...staff-workflow-edit
Create pull request, review and merge to main. Wait for Cloudflare Pages production deployment to succeed.
Save/download recovery drafts before refreshing the Hub. Refresh after deployment.

## 4. Check using a normal staff account
- Project > Edit details: change a name, save, refresh and verify it remains.
- Request: tick the scope/commercial checkbox; move to Ready to send, then record the real submission or award without an approval inbox.
- Accepted quote > Edit: change a detail, Save changes. A new editable draft is created; verify the original accepted version is still present.
- Linked invoice > Edit: save a correction and check that payments remain unchanged. No email is sent automatically by editing.

The existing recovery drafts are not auto-overwritten or discarded. Review and re-enter wanted edits through the new editor. Do not repeatedly retry an old accepted-quote draft.

Tests: local PostgreSQL-compatible PGlite tests passed for repeatable migration, ordinary staff permissions, project rename, request progression, accepted quote revision, linked invoice amendment, stale-update rejection, original acceptance retention, private version records, inactive/anonymous rejection. JavaScript syntax and request transition tests passed. No live deployment or live account testing has been performed by this package's author.
