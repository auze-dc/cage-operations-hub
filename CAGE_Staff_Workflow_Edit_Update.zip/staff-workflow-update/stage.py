from pathlib import Path
import hashlib,json,subprocess
bundle=Path(__file__).resolve().parent;repo=Path.cwd()
manifest=json.loads((bundle/'MANIFEST.json').read_text())
for name,entry in manifest.items():
 p=repo/name
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=entry['after']:raise SystemExit('Not staging: '+name+' differs from the installed update. Review it first.')
subprocess.run(['git','add','--',*manifest],check=True)
print('Staged only this update. Review git diff --cached before committing.')
