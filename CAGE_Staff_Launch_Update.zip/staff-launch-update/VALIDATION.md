# Validation performed

All tests used local synthetic data or mocked network calls. No real document was sent and no live user location was accessed.

- Repository production checks and JavaScript syntax checks passed.
- Actual prior database schema plus document-response migration and both new migrations ran in PGlite.
- Invoice tests: Finance View can prepare an accessible invoice without approval; amount spoofing, cross-organisation access, inactive/shared/anonymous/no-access accounts remain blocked as applicable. Browser users cannot finalise an email send. Service completion requires provider confirmation and records status/audit once on retry. Workspace content and reset epoch remain intact.
- Mock Edge tests: quote approval/access unchanged, view-only invoice sends accepted, shared/no-access sends rejected, sender display CAGE with unchanged configured address, multiple recipients/BCC privacy, private approver invitation, partial delivery retries/idempotency, and database status failure recovery.
- Real form markup tests: invoice Send re-enabled for View role; capture-phase form permission allows only invoice sends; no client workspace mutation after sending an existing invoice. Quote edit restrictions remain. Client message is directly visible and escaped as text.
- Sender path test: Finance editors retain create-and-send preparation; view-only users use the read-only invoice preparation RPC; no-access is rejected before requests.
- Presence browser tests: online at 9:59; away at 10:00; interaction returns online; desktop background grace; phone background away; stop/offline.
- Location database tests: existing verified Alexander identity only; other admins/members/shared/anonymous blocked; raw tables denied; invalid/stale coordinates rejected; organisation isolation, multiple sessions, expiry and late upload after revocation covered.
- Location browser tests: starts automatically with a visible purpose notice; no in-app on/off controls; permission denial handled; away stops publication; late callbacks cannot publish after stop; account switch clears the map view; map names escaped and URLs use encoded coordinates.
- Installer tested on a fresh copy of the uploaded ZIP; payload hashes match; second installation makes no changes; modified local source causes a STOP before writes. Runtime configuration and secrets excluded.
- Desktop/mobile response layouts visually reviewed using mocked document data.

## Scope and limitations

Live Supabase delivery, actual staff browsers/OS permissions, Google Maps accuracy and actual email inbox delivery require the short post-deployment checks in START_HERE.md. Passing checks is not a claim of live deployment. Browser background suspension can affect both location sampling and presence.

## Optional reproduction for a developer

Run from the installed repository root with Node 24 (the Edge mock harness uses stripTypeScriptTypes). Install the test dependencies separately:

```bash
npm install --prefix staff-launch-update
npx --prefix staff-launch-update playwright install chromium
node staff-launch-update/tests/edge.mjs
node staff-launch-update/tests/invoice-browser-path.mjs
node staff-launch-update/tests/presence.mjs
node staff-launch-update/tests/location-browser.mjs
node staff-launch-update/tests/ui.mjs
```

Use CAGE_TEST_REPO to point at another repository root and CAGE_TEST_BROWSER for a preinstalled Chromium executable. The database test additionally needs CAGE_TEST_SCHEMA pointing to the same pre-update schema dump used for this project; no live database connection is used. Do not publish a database dump or add it to the repository.
