# CAGE staff invoice, presence and client-response update

Prepared against your uploaded `cage-operations-hub-main (3).zip`.

## What changes

- Every active internal staff member with access to an invoice can send it without manager approval. Finance View users gain send-only access; Finance No access and record-level restrictions still apply. Creating/editing invoices still requires existing Finance edit permission. Shared and inactive accounts cannot send. Quote approval rules remain unchanged.
- Desktop presence stays green until ten minutes without Hub interaction. Phones/tablets go Away when the Hub is backgrounded. Browser suspension or lost connectivity can mark a device offline earlier. Activity in unrelated apps is not observable from a browser.
- Device location starts automatically for online staff. A visible notice identifies Alexander as the sole reader. There is no in-app location off button. Browser site permission AND device location must be enabled; this update cannot override either. Denial does not block login. Coordinates are estimates, shown with accuracy and observation time. Google Maps opens the device pin. No GPS precision is promised, especially on laptops. Background browser limits may prevent fresh readings.
- Only the existing verified `alexander@cagemw.com` Auth identity can read locations, including over the API. Other administrators cannot read them. The latest coordinates are stored per browser session, not movement history. Pins expire after at most 90 seconds; expired coordinates are cleared on a later publish. Stop/logout clears coordinates when connectivity permits. Only fresh, online sessions are listed.
- Quote/invoice email sender display name and footer say CAGE, while preserving the configured sender email address. Existing PDFs and emails are unchanged. Client response emails still go only to the designated approver.
- Client decisions and their messages appear at the top of Finance. Quote rows have a Client response button; delivery history remains available. Existing in-app and staff-email response notifications remain.
- Your exact attached logo is used as the browser favicon on the Hub and other packaged public pages.

No reset, historical deletion, role change, runtime-config replacement or secret changes are included. The earlier login and Categories fixes are retained.

## 1. Install the code in Codespaces

Save/commit current work first. Keep a current database backup now that the Hub contains real records. Do not use the old demo reset backup as today's backup.

Upload `CAGE_Staff_Launch_Update.zip` to the top level of `cage-operations-hub` in Codespaces Explorer.

```bash
cd /workspaces/cage-operations-hub
git status --short
```

If you have uncommitted code edits, save and commit them first. Do not discard them. An untracked old extracted update folder can remain outside this commit.

Start from your latest main, then create the update branch:

```bash
git switch main
git pull --ff-only
git switch -c staff-invoice-presence-update
unzip CAGE_Staff_Launch_Update.zip
python3 staff-launch-update/install.py
npm run check
git diff --check
```

If the installer says STOP, share that message. It validates all files before changing any; do not bypass it. It creates a backup of edited files outside the repository. It does not execute SQL.

## 2. Run only these two new SQL files

In Supabase choose CAGE Operations Hub (`lrvcpiobxqtmcntwhaat`). Use SQL Editor → New query, database owner/postgres.

Open the first file in Codespaces:

```bash
code supabase/migrations/20260924130000_staff_invoice_send.sql
```

Copy the entire file into a new SQL query and Run once. Expected: Success. No rows returned.

Then open the second file:

```bash
code supabase/migrations/20260924131000_private_device_location.sql
```

Copy its entire contents into another new SQL query and Run once. It validates that exactly one active, verified Alexander account exists before binding access.

Stop and share any SQL error. Each file is one transaction. Do not run old migrations, db reset, db push or the earlier optional location SQL. A second execution deliberately fails rather than replacing these objects.

## 3. Deploy the changed Edge functions

In Codespaces terminal:

```bash
npx supabase login
npx supabase functions deploy send-document-v2 --project-ref lrvcpiobxqtmcntwhaat --use-api
npx supabase functions deploy send-document --project-ref lrvcpiobxqtmcntwhaat --use-api
npx supabase functions deploy enrollment-email-dispatch --project-ref lrvcpiobxqtmcntwhaat --no-verify-jwt --use-api
```

Wait for each command to report Deployed Functions before moving on. The first two keep JWT verification enabled and check the authenticated user. The enrollment dispatcher retains its existing secret-based worker checks; that deployment updates weekly-report wording for the new activity estimate. Preserve all existing secrets and schedules. Do not paste tokens into chat.

## 4. Commit and deploy the frontend

Stage only the update's listed files:

```bash
python3 staff-launch-update/stage.py
git diff --cached --stat
git commit -m "Allow staff invoice sends and improve presence and client responses"
git push -u origin staff-invoice-presence-update
```

On GitHub, create a pull request from `staff-invoice-presence-update` into `main`. Wait for checks, merge, then wait for the Deploy CAGE Operations Hub workflow to pass.

The helper stages only this package's changed files. It does not stage runtime config, secrets, ZIPs or old update folders.

## 5. Enable browser location and verify

Ask staff to save work, close old Hub tabs, then reopen one fresh tab after deployment. Do not clear site storage; it can contain unsent drafts.

On each work laptop, enable OS location services, allow the browser to use location, and allow Location for `https://hub.cagemw.com`. Location is requested automatically when the staff session is online. If permission was previously blocked, change the site's location permission to Allow and reopen the page. Browser/OS settings remain under device control.

As Alexander, open the online/team availability button → View device locations → Open Google Maps pin. Another admin/member must not have that viewing control or API access. Accuracy is printed next to each pin; a missing pin means no fresh reading, not a known absence from work.

Use only controlled recipient inboxes for an agreed test document. Check:

1. A normal active staff member sends an accessible invoice without an approval step. A View user can send but cannot change invoice values. A No access user remains blocked.
2. The email sender name and client-facing text say CAGE. Check both quote PDF email and response invitation; provider acceptance is not proof of inbox delivery.
3. A controlled client response is visible with its full message at the top of Finance after the usual workspace refresh. Quote approval workflow is unchanged.
4. Green becomes Away after ten minutes without Hub interaction; mobile becomes Away when backgrounded.
5. A permitted online device appears to Alexander with timestamp, accuracy and a working map pin. Denied location does not interrupt sign-in.
6. The attached CAGE logo appears in the browser tab. Tab favicons may take a fresh page load to update.

These live checks have not been run by the assistant; automated checks used synthetic users, documents and coordinates. No live email was sent.

## If something fails

Share the exact error and the step. Keep current records and drafts. Do not rerun reset scripts, uninstall tables, disable RLS, or broaden staff roles. A code rollback is possible using the backup/PR; leave the additive SQL objects in place pending review rather than deleting delivery history.
