import path from 'node:path';import {pathToFileURL} from 'node:url';
const repo=path.resolve(process.env.CAGE_TEST_REPO||'.')+'/';
import {chromium} from 'playwright';import fs from 'node:fs';import assert from 'node:assert/strict';
const browser=await chromium.launch({executablePath:process.env.CAGE_TEST_BROWSER||undefined,args:['--no-sandbox']});
try{
const p=await browser.newPage();await p.route('https://test.invalid/**',r=>r.fulfill({contentType:'text/html',body:'<div class="user-card"></div><div id="cage-online-dialog"><div class="cage-status-actions"></div></div>'}));await p.goto('https://test.invalid');
await p.evaluate(()=>{window.profile={id:'member',active:true,role:'member'};window.calls=[];window.geo=[];window.reader=false;window.online=true;Object.defineProperty(navigator,'permissions',{value:{query:async()=>({state:'granted'})}});Object.defineProperty(navigator,'geolocation',{value:{getCurrentPosition(ok,bad){geo.push({ok,bad});}}});window.CAGE_PRESENCE={status:()=>online?'online':'away'};window.CAGE_BACKEND={currentProfile:()=>profile,locationCanRead:async()=>reader,locationPublish:async v=>calls.push(['publish',v]),locationStop:async v=>calls.push(['stop',v]),locationList:async()=>[{name:'<img src=x>',session_id:'12345678-abcd',latitude:-13.9,longitude:33.7,accuracy_m:28,observed_at:new Date().toISOString(),expires_at:new Date(Date.now()+90000).toISOString()}]};});
await p.addScriptTag({path:repo+'dist/device-location.js'});await p.waitForFunction(()=>geo.length===1);
assert.equal(await p.locator('[data-location-stop]').count(),0);assert.equal(await p.locator('[data-location-share]').count(),0);assert.equal(await p.locator('[data-location-view]').isVisible(),false);
await p.evaluate(()=>geo[0].ok({coords:{latitude:-13.9,longitude:33.7,accuracy:28},timestamp:Date.now()}));await p.waitForFunction(()=>calls.some(x=>x[0]==='publish'));assert.match(await p.locator('#cage-location-notice').innerText(),/Alexander.*28 m/);
await p.evaluate(()=>{online=false;dispatchEvent(new Event('cage:presence-updated'));});await p.waitForFunction(()=>calls.some(x=>x[0]==='stop'));
await p.evaluate(()=>{online=true;dispatchEvent(new Event('cage:presence-updated'));});await p.waitForFunction(()=>geo.length===2);
await p.evaluate(async()=>{await CAGE_LOCATION.stop();geo[1].ok({coords:{latitude:1,longitude:2,accuracy:3},timestamp:Date.now()});});assert.equal(await p.evaluate(()=>calls.filter(x=>x[0]==='publish').length),1);
await p.evaluate(()=>dispatchEvent(new Event('cage:presence-updated')));await p.waitForFunction(()=>geo.length===3);await p.evaluate(()=>geo[2].bad({code:1}));await p.waitForFunction(()=>document.querySelector('[data-location-status]').textContent.includes('blocked'));
await p.evaluate(()=>{profile={id:'alexander',active:true,role:'admin'};reader=true;dispatchEvent(new Event('cage:session-ready'));});await p.waitForFunction(()=>!document.querySelector('[data-location-view]').hidden);await p.locator('[data-location-view]').click();await p.waitForFunction(()=>!!document.querySelector('[data-location-list] a'));
assert.equal(await p.locator('[data-location-list] img').count(),0);assert.match(await p.locator('[data-location-list] a').getAttribute('href'),/query=-13.9%2C33.7/);
await p.evaluate(()=>{profile={id:'other-admin',active:true,role:'admin'};reader=false;dispatchEvent(new Event('cage:session-ready'));});await p.waitForFunction(()=>document.querySelector('[data-location-view]').hidden);assert.equal(await p.locator('[data-location-list] a').count(),0);
console.log('PASS automatic location, visible notice, no in-app off switch, denial, away/late callbacks, account switch, escaped pins and reader control.');
}finally{await browser.close();}
