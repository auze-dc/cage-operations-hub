import path from 'node:path';import {pathToFileURL} from 'node:url';
const repo=path.resolve(process.env.CAGE_TEST_REPO||'.')+'/';
import {PGlite} from '@electric-sql/pglite';
import fs from 'node:fs';import assert from 'node:assert/strict';
const db=new PGlite();
await db.exec(`create publication supabase_realtime;create role anon;create role authenticated;create role service_role;create role supabase_admin;create schema auth;create table auth.users(id uuid primary key,email text,email_confirmed_at timestamptz);create function auth.uid() returns uuid language sql as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;create function auth.role() returns text language sql as $$select 'authenticated'::text$$;`);
let schema=fs.readFileSync(process.env.CAGE_TEST_SCHEMA||'upload/schema.sql','utf8').replace(/CREATE EXTENSION[^;]+;/g,'').replace(/^GRANT ALL ON FUNCTION[^;]+;/gm,'').replaceAll('"public"."citext"','text');
await db.exec(schema);await db.exec('set search_path=public;set row_security=on;');
const org='00000000-0000-4000-8000-000000000001',otherOrg='00000000-0000-4000-8000-000000000002';
const ids=Array.from({length:6},(_,i)=>'10000000-0000-4000-8000-00000000000'+(i+1));
await db.exec(`insert into organizations(id,name,slug) values('${org}','Test','test'),('${otherOrg}','Other','other');`);
for(let i=0;i<6;i++){
 const email=i===0?'alexander@cagemw.com':`test${i}@example.invalid`,o=i===4?otherOrg:org;
 await db.query('insert into auth.users values($1,$2,now())',[ids[i],email]);
 await db.query('insert into profiles(id,organization_id,email,full_name,initials,role) values($1,$2,$3,$4,$5,$6)',[ids[i],o,email,'Person '+i,'PP',i<2?'admin':i===5?'shared':'member']);
 await db.query("insert into hub_presence_sessions(user_id,session_id,organization_id,state) values($1,$2,$3,'online')",[ids[i],crypto.randomUUID(),o]);
}
await db.exec(fs.readFileSync(repo+'supabase/migrations/20260924131000_private_device_location.sql','utf8'));
const as=async(uid,role='authenticated')=>{await db.exec('reset role');await db.query("select set_config('request.jwt.claim.sub',$1,false)",[uid||'']);await db.exec('set role '+role);};
const sid=crypto.randomUUID();
const publish=async(id=sid,lat=-13.9)=>db.query('select hub_location_publish($1,$2,33.7,20,now())',[id,lat]);
const list=async()=> (await db.query('select hub_location_list() r')).rows[0].r;
await as(ids[2]);await publish();await assert.rejects(list,/Only Alexander/);
for(const id of [ids[1],ids[2],ids[3],ids[4],ids[5]]){await as(id);assert.equal((await db.query('select hub_location_can_read() r')).rows[0].r,false);await assert.rejects(list,/Only Alexander/);await assert.rejects(()=>db.query('select * from hub_device_locations'),/permission denied/);await assert.rejects(()=>db.query('select * from hub_location_reader'),/permission denied/);}
await as(ids[0]);assert.equal((await list()).length,1);await assert.rejects(()=>db.query('select * from hub_device_locations'),/permission denied/);
await as(ids[2]);await assert.rejects(()=>publish(crypto.randomUUID(),91),/fresh valid/);await assert.rejects(()=>publish(crypto.randomUUID(),NaN),/fresh valid/);
await assert.rejects(()=>db.query("select hub_location_publish($1,1,1,1,now()-interval '2 minutes')",[crypto.randomUUID()]),/fresh valid/);
await as(ids[4]);await publish(crypto.randomUUID());await as(ids[0]);assert.equal((await list()).length,1);
// Another member cannot revoke someone else's session.
await as(ids[3]);await db.query('select hub_location_stop($1)',[sid]);await as(ids[0]);assert.equal((await list()).length,1);
await as(ids[2]);await db.query('select hub_location_stop($1)',[sid]);await publish();await as(ids[0]);assert.equal((await list()).length,0);
// Stop-before-upload and multiple devices.
await as(ids[2]);const stopped=crypto.randomUUID();await db.query('select hub_location_stop($1)',[stopped]);await publish(stopped);const s2=crypto.randomUUID(),s3=crypto.randomUUID();await publish(s2);await publish(s3);await as(ids[0]);assert.equal((await list()).length,2);
await db.exec('reset role');await db.query("update hub_device_locations set expires_at=now()-interval '1 second' where session_id=$1",[s2]);await as(ids[0]);assert.equal((await list()).length,1);
// Expired nullable observations can receive a new fresh sample.
await as(ids[2]);await publish(s3);await publish(s2);await as(ids[0]);assert.equal((await list()).length,2);
await db.exec('reset role');await db.query("update profiles set active=false where id=$1",[ids[2]]);await as(ids[0]);assert.equal((await list()).length,0);
// Editable profile email cannot confer the privilege; identity or verified email changes revoke it.
await db.exec('reset role');await db.query("update profiles set email='alexander@cagemw.com' where id=$1",[ids[1]]).catch(()=>{});await as(ids[1]);await assert.rejects(list,/Only Alexander/);
await db.exec('reset role');await db.query("update auth.users set email='changed@example.invalid' where id=$1",[ids[0]]);await as(ids[0]);await assert.rejects(list,/Only Alexander/);
await as(ids[5]);await assert.rejects(publish,/Active staff/);
await as(null,'anon');await assert.rejects(list,/permission denied/);await assert.rejects(publish,/permission denied/);
await db.exec('reset role');
await db.query("update auth.users set email='alexander@cagemw.com' where id=$1",[ids[0]]);
await db.query("update profiles set active=true,role='viewer' where id=$1",[ids[2]]);
await db.exec(fs.readFileSync(repo+'supabase/migrations/20260923150000_document_responses_v2.sql','utf8'));
await db.exec(fs.readFileSync(repo+'supabase/migrations/20260924130000_staff_invoice_send.sql','utf8'));
await db.query("insert into record_access(user_id,module,scope) values($1,'finance','all')",[ids[2]]);
const invoice={id:'inv1',number:'INV-1',amount:100,currency:'MWK',description:'Real work',status:'Draft',owner:ids[2]};
await db.query('insert into workspace_states(organization_id,data,version) values($1,$2,1)',[org,JSON.stringify({invoices:[invoice],quotes:[],team:[],_resetEpoch:'preserved'})]);
await as(ids[2]);
assert.equal((await db.query("select module_level('finance') r")).rows[0].r,'view');
const prepared=(await db.query('select prepare_staff_invoice_send($1) r',[JSON.stringify(invoice)])).rows[0].r;
assert.equal(prepared.record.amount,100);assert.equal(prepared.version,1);
await assert.rejects(()=>db.query('select prepare_staff_invoice_send($1)',[JSON.stringify({...invoice,amount:1})]),/changed/);
await assert.rejects(()=>db.query('select complete_staff_invoice_send($1)',[crypto.randomUUID()]),/permission denied/);
await as(ids[4]);await assert.rejects(()=>db.query('select prepare_staff_invoice_send($1)',[JSON.stringify(invoice)]),/outside/);
await as(ids[5]);await assert.rejects(()=>db.query('select prepare_staff_invoice_send($1)',[JSON.stringify(invoice)]),/outside/);
await as(null,'anon');await assert.rejects(()=>db.query('select prepare_staff_invoice_send($1)',[JSON.stringify(invoice)]),/permission denied/);
await db.exec('reset role');await db.query("insert into module_access(user_id,module,access) values($1,'finance','none')",[ids[2]]);
await as(ids[2]);await assert.rejects(()=>db.query('select prepare_staff_invoice_send($1)',[JSON.stringify(invoice)]),/outside/);
await db.exec('reset role');await db.query("update module_access set access='view' where user_id=$1 and module='finance'",[ids[2]]);
const attempt=crypto.randomUUID();
await db.query('select register_document_send_v2($1)',[JSON.stringify({id:attempt,organization_id:org,sender_id:ids[2],document_type:'invoice',document_id:invoice.id,request_hash:'test',snapshot:invoice,recipients:{to:['client@example.invalid'],cc:[],bcc:[]},mail_payload:{subject:'Invoice'},invitation_payload:null})]);
await as(null,'service_role');await assert.rejects(()=>db.query('select complete_staff_invoice_send($1)',[attempt]),/not been confirmed/);
await db.exec('reset role');await db.query("update document_sends_v2 set provider_id='provider-test' where id=$1",[attempt]);
await as(null,'service_role');await db.query('select complete_staff_invoice_send($1)',[attempt]);await db.query('select complete_staff_invoice_send($1)',[attempt]);
await db.exec('reset role');const after=(await db.query('select data,version from workspace_states where organization_id=$1',[org])).rows[0];
assert.equal(after.data.invoices[0].amount,100);assert.equal(after.data.invoices[0].status,'Sent');assert.equal(after.data._resetEpoch,'preserved');assert.equal(after.version,2);
assert.equal((await db.query("select count(*) n from audit_log where action='invoice.sent'")).rows[0].n,1);
console.log('PASS invoice: viewer sends accessible invoice; amount spoof, cross-org, shared, anon, no-access blocked; only provider-accepted service completion; idempotent audit/status.');
await db.close();console.log('PASS: actual schema + migration; account-bound access, other admins/member/shared/anon denied, org isolation, inactive users, invalid/stale locations, expiry, multiple sessions, revoked sessions cannot revive, direct tables denied.');
