import path from 'node:path';import {pathToFileURL} from 'node:url';
const repo=path.resolve(process.env.CAGE_TEST_REPO||'.')+'/';
import {chromium} from 'playwright';import fs from 'node:fs';import assert from 'node:assert/strict';
const browser=await chromium.launch({executablePath:process.env.CAGE_TEST_BROWSER||undefined,args:['--no-sandbox']});
try{
for(const mobile of [false,true]){
const p=await browser.newPage();await p.setContent('<div class="topbar-actions"></div>');await p.evaluate(mobile=>{Object.defineProperty(navigator,'userAgent',{value:mobile?'Android':'Desktop'});Object.defineProperty(navigator,'userAgentData',{value:{mobile}});crypto.randomUUID=()=> '00000000-0000-4000-8000-000000000001';window.tick=Date.now();Date.now=()=>tick;window.calls=[];window.CAGE_BACKEND={currentProfile:()=>({id:'a',role:'member'}),presenceHeartbeat:async(s,state)=>{calls.push(state);return [{id:'a',name:'Member',status:state}];}};},mobile);
await p.addScriptTag({content:fs.readFileSync(repo+'dist/staff-presence.js','utf8')});await p.waitForFunction(()=>calls.length===1);
await p.evaluate(async()=>{tick+=599999;await CAGE_PRESENCE.refresh();});assert.equal(await p.evaluate(()=>calls.at(-1)),'online');
await p.evaluate(async()=>{tick++;await CAGE_PRESENCE.refresh();});assert.equal(await p.evaluate(()=>calls.at(-1)),'away');
await p.evaluate(async()=>{document.dispatchEvent(new Event('wheel'));await CAGE_PRESENCE.refresh();});assert.equal(await p.evaluate(()=>calls.at(-1)),'online');
await p.evaluate(async()=>{Object.defineProperty(document,'hidden',{configurable:true,value:true});document.dispatchEvent(new Event('visibilitychange'));await CAGE_PRESENCE.refresh();});assert.equal(await p.evaluate(()=>calls.at(-1)),mobile?'away':'online');
await p.evaluate(async()=>{tick+=600000;await CAGE_PRESENCE.refresh();});assert.equal(await p.evaluate(()=>calls.at(-1)),'away');
await p.evaluate(async()=>{Object.defineProperty(document,'hidden',{configurable:true,value:false});document.dispatchEvent(new Event('visibilitychange'));await CAGE_PRESENCE.refresh();});assert.equal(await p.evaluate(()=>calls.at(-1)),'online');
await p.evaluate(()=>CAGE_PRESENCE.stop());assert.equal(await p.evaluate(()=>calls.at(-1)),'offline');await p.close();
}
console.log('PASS desktop/mobile: 9:59 online; 10:00 away; interaction restores green; background desktop grace and mobile away; return and logout.');
}finally{await browser.close();}
