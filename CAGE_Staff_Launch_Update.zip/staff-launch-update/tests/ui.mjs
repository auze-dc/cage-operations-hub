import path from 'node:path';import {pathToFileURL} from 'node:url';
const repo=path.resolve(process.env.CAGE_TEST_REPO||'.')+'/';
import fs from 'node:fs';import assert from 'node:assert/strict';import {chromium} from 'playwright';
const root=repo+'dist/';
const b=await chromium.launch({executablePath:process.env.CAGE_TEST_BROWSER||undefined,args:['--no-sandbox']});
try{
const p=await b.newPage({viewport:{width:1440,height:1000}});const errors=[];p.on('pageerror',e=>errors.push(e.message));
await p.setContent(fs.readFileSync(root+'index.html','utf8').replace(/<script[\s\S]*?<\/script>/g,'').replace(/<link[^>]*>/g,''));
for(const css of ['styles.css','monday-theme.css','design-system.css'])await p.addStyleTag({content:fs.readFileSync(root+css,'utf8')});
await p.evaluate(()=>{
 document.querySelector('#auth-gate').hidden=true;document.body.className='';document.querySelectorAll('[data-view-panel]').forEach(e=>{e.hidden=e.dataset.viewPanel!=='finance';e.classList.toggle('active',!e.hidden)});
 window.state={quotes:[{id:'q1',number:'Q-001',client:'Sample client',clientResponse:{decision:'Changes requested',name:'Client <script>',note:'Please adjust the delivery date.\nCan you include processing?',at:new Date().toISOString()}}],invoices:[{id:'i1',number:'INV-001',amount:100,client:'Sample',description:'Mapping',status:'Draft'}]};window.sendingDocument=null;window.formatMoney=x=>String(x);window.escapeHtml=x=>String(x||'').replaceAll('<','&lt;');window.renderAll=()=>{};window.showToast=()=>{};window.backend=()=>window.CAGE_BACKEND;window.saved=0;window.sent=0;window.saveState=()=>saved++;
 window.CAGE_BACKEND={canSendInvoice:()=>true,moduleLevel:()=> 'view',isProduction:()=>true,sendDocument:async()=>{sent++;},documentHistory:async()=>[]};window.CAGE_APP={getState:()=>structuredClone(state)};
 const actions=document.createElement('div');actions.innerHTML='<button data-send-document="quote" data-document-id="q1">Send quote</button><button data-send-document="invoice" data-document-id="i1">Send invoice</button>';document.querySelector('[data-view-panel=finance]').append(actions);
});
await p.addScriptTag({path:root+'document-delivery.js'});
await p.waitForFunction(()=>!!document.getElementById('client-response-summary'));
assert.match(await p.locator('#client-response-summary').innerText(),/Please adjust the delivery date/);assert.equal(await p.locator('#client-response-summary script').count(),0);
assert.equal(await p.locator('[data-delivery-history=quote]').last().innerText(),'Client response');
await p.screenshot({path:'staff-launch-update/tests/client-responses-desktop.png',fullPage:false});
const app=fs.readFileSync(root+'app.js','utf8');await p.addScriptTag({content:app.slice(app.indexOf('function openSendDocument('),app.indexOf('function openExpenseDialog('))});
const personal=fs.readFileSync(root+'personal-work.js','utf8');const start=personal.indexOf("document.addEventListener('submit',e=>{\n const formModules=");await p.addScriptTag({content:personal.slice(start,personal.indexOf('},true);',start)+8)});
await p.evaluate(()=>{document.querySelector('#send-form').addEventListener('submit',sendDocument);document.querySelector('#send-form .primary-button').disabled=true;openSendDocument('invoice','i1');});
assert.equal(await p.locator('#send-form .primary-button').isDisabled(),false);
await p.locator('#send-form [name=recipient]').fill('client@example.invalid');await p.locator('#send-form .primary-button').click();await p.waitForFunction(()=>!document.querySelector('#send-dialog').open);assert.equal(await p.evaluate(()=>saved),0);assert.equal(await p.evaluate(()=>sent),1);
await p.evaluate(()=>openSendDocument('quote','q1'));assert.equal(await p.locator('#send-form .primary-button').isDisabled(),true);await p.evaluate(()=>document.querySelector('#send-dialog').close());
await p.setViewportSize({width:390,height:844});await p.addStyleTag({content:fs.readFileSync(root+'mobile.css','utf8')});await p.screenshot({path:'staff-launch-update/tests/client-responses-mobile.png',fullPage:false});
assert.equal(errors.length,0,errors.join('\n'));console.log('PASS real form markup: invoice view-only Send enabled, guarded submit allowed, no client workspace write; quote edit guard remains; client response text escaped/visible.');
}finally{await b.close();}
