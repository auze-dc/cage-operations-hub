from pathlib import Path
import hashlib,json,shutil,datetime
root=Path(__file__).resolve().parent
repo=Path.cwd()
manifest=json.loads((root/'manifest.json').read_text())
hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
for key,m in manifest.items():
 if hashfile(repo/key) not in [m['before'],m['after']]:
  raise SystemExit('Stopped before changes: unexpected version of '+key+'. Send this message for review.')
backup=repo.parent/('cage-before-scanner-fix-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
for key,m in manifest.items():
 if hashfile(repo/key)==m['after']:continue
 dst=backup/key;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/key,dst)
 shutil.copy2(root/'payload'/key,repo/key)
print('Scanner fix installed. Backup: '+str(backup))
print('Nothing deployed. No database migration required. Run npm run check, deploy opportunity-scan, then publish the frontend.')
