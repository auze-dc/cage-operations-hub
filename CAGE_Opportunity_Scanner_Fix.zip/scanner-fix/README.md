# CAGE Opportunity Scanner Correction

Apply only after the Opportunity Workspace update. The installer checks file versions before writing and backs up changed files outside the repository. Existing records, runtime-config.js, credentials and Cron configuration are untouched. No SQL migration is required.

## Install in Codespaces
Upload this ZIP to the repository folder, then:

```bash
unzip CAGE_Opportunity_Scanner_Fix.zip
python3 scanner-fix/install.py
npm run check
npx supabase functions deploy opportunity-scan --use-api --no-verify-jwt
git add dist/index.html dist/opportunities.js supabase/functions/opportunity-scan/index.ts supabase/functions/opportunity-scan/core.js
git commit -m "Correct opportunity discovery and scan diagnostics"
git push
```

Use your current branch; if already merged, create a new branch before committing and push with `git push -u origin opportunity-scanner-fix`. Merge the pull request to main and wait for frontend deployment. Hard refresh, Scan now, then inspect source health.

## Changes
- Simpler searches for every configured source domain, with rotating capability terms.
- Public UNDP notice listing added alongside UNGM.
- Broader candidate selection; final capability matching uses full page text.
- Unchecked/oldest checked pages prioritised, with a 24-page limit per run.
- Historical title years and explicit closure evidence prevent fresh-discovery presentation; existing records remain available under Past deadlines and All.
- Dates from listing excerpts survive detail pages without dates; UNDP two-digit date format handled.
- Funding-call titles correctly take precedence over incidental procurement wording.
- Per-source duplicate, excluded, historical, queued, deferred, checked, failed page, irrelevant and saved counts.

## Validation and limits
Regression and mocked Edge tests passed for authorization, tenant binding, deduplication, preserved evidence, broad candidates, date formats, historical calls and locking. Live UNDP HTML returned 546 parsed notice links; the agricultural LTA notice 50002 retained its 8 October 2026 deadline. That is a parser validation, not confirmation of CAGE eligibility. UNICEF closed-calls page independently confirms the 2019 drone call is historical. Direct UNICEF fetch from the test environment returned 403. Access failures remain visible; no access restrictions are bypassed.

The corrected scanner has NOT been tested inside your live Supabase deployment. Search feed quality varies. No guaranteed result count or exhaustive coverage. Unknown dates remain unverified. Candidate diagnostics apply to new scans; older logs are unchanged. Historical detection is conservative and requires staff review for renewed calls. Existing staff verification with a confirmed deadline is respected.
