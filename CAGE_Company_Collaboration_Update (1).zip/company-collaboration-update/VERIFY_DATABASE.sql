select 'Project creation' as feature,to_regprocedure('public.collaboration_create_project(jsonb,text)') is not null as installed
union all select 'Add group members',to_regprocedure('public.collaboration_add_members(text,text,jsonb)') is not null
union all select 'Preserved original access logic',to_regprocedure('public.collaboration_original_record_visible(text,jsonb,jsonb,uuid)') is not null
union all select 'Reply and member validation',exists(select 1 from pg_trigger where tgname='collaboration_validate_workspace' and not tgisinternal and tgenabled<>'D')
union all select 'Meeting room validation',exists(select 1 from pg_trigger where tgname='collaboration_meeting_link' and not tgisinternal and tgenabled<>'D')
union all select 'Opportunity members',exists(select 1 from information_schema.columns where table_schema='public' and table_name='opportunity_tracking' and column_name='members');
