# CAGE Company Collaboration Update

Prepared for the repository snapshot `cage-operations-hub-main (5).zip`.

## Included

1. **Reply to a specific chat message.** Click Reply; the sent message quotes its original and links back to it. Works with text, files and voice messages. Quotes survive refresh. Existing @mentions remain available.
2. **Emoji beside the composer.** The emoji picker is available directly, outside the three-dot menu.
3. **Add group members.** Open the chat → three dots → Add members. Group creators can add active company colleagues. Company administrators who already belong to a private group can also manage its members. A project owner/creator can add project members. New members can see earlier group messages; direct-message membership stays fixed.
4. **All company work / My work.** All active internal staff can browse projects, requests, CRM opportunities and tenders/contracts. Press Q, or use the visible toggle, to show work you own, created, or belong to. Q does nothing while typing, inside a dialog, or when used with Command/Ctrl/Alt. Existing search/status filters still apply. Browsing alone does not grant edit/delete access or private-chat access.
5. **Projects for all staff.** Every active internal staff account, including view-only accounts, can create a project. This does not grant them general edit rights over other projects.
6. **Members during creation.** Expand Add members in project, request, CRM opportunity and contract forms. Tenders/grants also have member selectors. The quick CRM creation form supports members too.
7. **Task collaborators.** Add colleagues while creating or editing a task, including quick task cards. They can see the task within their permitted task module and in My work. The accountable task owner remains separate from collaborators.
8. **Automatic email CC.** Every new quote/invoice send automatically copies alexander@cagemw.com, ndapile@cagemw.com and the authenticated sender. Duplicates across To/CC/BCC are removed. Client addresses remain editable. Copies are email recipients only and are not printed on the PDF. Private quotation response links go only to the selected client approver.
9. **Meeting room dropdown.** Calendar events and video interviews offer Link 1, Link 2 and Link 3. Existing calendar links are preserved when editing an older event.

| Choice | URL |
| --- | --- |
| Link 1 | https://meet.google.com/tai-aetz-gqe |
| Link 2 | https://meet.google.com/ise-jvne-hci |
| Link 3 | https://meet.google.com/twx-mknz-ntd |

## 1. Upload and install in Codespaces

Download this ZIP. In the Codespaces file explorer, upload it into `/workspaces/cage-operations-hub`. Uploading it to a different GitHub branch does not place it in the current Codespace folder.

Run in the Codespaces terminal:

```bash
cd /workspaces/cage-operations-hub
ls -l CAGE_Company_Collaboration_Update.zip
git switch -c company-collaboration-$(date +%Y%m%d-%H%M%S)
unzip CAGE_Company_Collaboration_Update.zip
python3 company-collaboration-update/install.py
npm run check
```

The installer checks every target before changing anything. It creates a backup outside the repository and preserves runtime configuration, keys, PDF templates, existing records and unrelated files. It does not run SQL, deploy functions or publish the website. If it reports a differing source file, stop and use the report to review the newer source; do not force an overwrite.

## 2. Apply the database update

Open this file in the Codespaces editor:

`supabase/migrations/20260930180000_company_collaboration.sql`

Copy its **entire contents**, beginning with `begin;` and ending with `commit;`. In the existing CAGE Supabase project, open **SQL Editor → New query**, paste the SQL and click **Run**. The filename itself is not a SQL query or a terminal command.

Run only this new migration on the existing configured project. It expects the installed staff chat, isolated sync, opportunities and calendar database updates. Some historical SQL files in the supplied snapshot contain terminal commands; this installer does not replay those files. An error inside this migration rolls back the transaction; report the error before proceeding.

The migration preserves existing function identities and permissions dependencies, adds company browsing separately from mutation permissions, validates group membership and replies, and adds opportunity member storage. It can safely be run again.

For a read-only installation check, copy `company-collaboration-update/VERIFY_DATABASE.sql` into SQL Editor and run it. All `installed` results should be true.

## 3. Deploy the email functions

In the Codespaces terminal, with your existing Supabase project link and login:

```bash
npx supabase functions deploy send-document-v2 --use-api
npx supabase functions deploy send-document --use-api
```

Both send paths must be deployed for automatic CC to apply consistently. No email keys or environment values need changing. Do not redeploy unrelated functions for this update.

## 4. Publish the frontend through GitHub

```bash
python3 company-collaboration-update/stage.py
git diff --cached --stat
git commit -m "Add company collaboration controls and automatic document copies"
git push -u origin HEAD
```

In GitHub, open this branch, choose **Compare & pull request**, target `main`, review and merge. Wait for the existing Cloudflare Pages production deployment to finish, then reload the Hub. A successful SQL run or Edge Function deploy does not publish the frontend.

The staging helper adds only this update's 15 implementation files. It does not stage old extracted update folders or unrelated work.

## 5. Verify in the deployed Hub

- With two staff accounts, confirm All shows company work and Q/Mine limits it correctly. Check that an unrelated private group remains unavailable.
- Create a project with a normal staff account; select another colleague. Confirm it survives refresh.
- Create a request, CRM opportunity and task with a colleague selected. Confirm membership survives refresh and appears for that colleague.
- Reply to an existing chat message, refresh, and click the quote to return to the original.
- As a group creator, add one colleague. Confirm that colleague can open the group.
- Open the calendar creation form and confirm the three room choices.
- On your next intended quote/invoice send, review Delivery history for the automatic CC recipients and confirm the PDF has not gained email CC fields.

No test emails were sent and no live company data was changed while preparing this package.

## Recovery

The installer prints its backup directory. Restoring those files reverses frontend/email source edits; republish/redeploy them if needed. Do not drop the new SQL functions or opportunity member column casually: the database update retains compatible existing interfaces, and dropping it may remove saved memberships. Review any database rollback against the actual deployed state.
