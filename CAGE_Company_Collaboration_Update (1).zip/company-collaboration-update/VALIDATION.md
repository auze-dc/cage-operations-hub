# Validation

Validated locally against the supplied latest repository snapshot, with no production writes or real email sends.

- **Production check:** existing `npm run check` logic passes; the new collaboration script is included in syntax and required-file checks.
- **Database:** existing database migrations loaded into PGlite, followed by the collaboration migration twice. Active member, viewer, administrator, shared account and other-organisation cases exercised. Tests covered all-company browsing, unchanged private chat boundaries, rejected unrelated edits, project creation by a viewer, member validation, group creator/admin additions, rejection of ordinary member administration, task/request membership persistence, same-thread and legacy project/request replies, opportunity creation/editing with members, and permitted meeting rooms. Direct table reads also exercised policies after the function updates.
- **Browser:** full supplied frontend loaded in Chromium with mocked backend responses. Checked Q/All/Mine, ignored Q while typing, request/CRM/task/contract creation with members, quote rendering/escaping and persistence after serialisation, direct emoji access, group member RPC, and calendar dropdown selection. Reviewed desktop and phone chat layouts. No JavaScript page errors.
- **Email:** both send-document and send-document-v2 handlers exercised for quotes and invoices with a mocked email provider. Checked fixed CCs plus authenticated sender, deduplication across recipient lists, validation and recipient limits, unchanged PDF input, and private approver links remaining client-only.
- **Installer:** validated against the uploaded snapshot; rerun is a no-op; mismatched source stops before any writes. Runtime configuration stays byte-for-byte unchanged.

Deployment and actual delivery through the live Supabase/Cloudflare/email services must be verified after following START_HERE.md. This package does not claim a live deployment.
