# CAGE — Hub deletion popup and month filters

Apply after CAGE_Record_Management_Update.zip has been installed.

Changes:
- Deletion uses a confirmation popup inside the Hub, not the browser's confirmation box.
- Clicking Delete starts the request immediately. The popup shows Deleting… and prevents repeated submissions while the server responds.
- On success it closes and refreshes the affected list. Permission/dependency errors appear inside the popup with Retry deletion and Cancel controls.
- Quotes and invoices have January–December and All months choices, combined with the existing year/client/status/search filters. Month refers to the document's issue date, not the invoice due date. With All years selected, a month matches across years.

## Install in Codespaces

Upload CAGE_Popup_Month_Filter_Update.zip into the Codespaces project folder.

If you uploaded the ZIP to GitHub main instead, retrieve it first:

```bash
cd /workspaces/cage-operations-hub
git fetch origin
git show origin/main:CAGE_Popup_Month_Filter_Update.zip > CAGE_Popup_Month_Filter_Update.zip
```

Then:

```bash
git switch -c popup-month-filters
unzip CAGE_Popup_Month_Filter_Update.zip
python3 popup-month-update/install.py
npm run check
node --check dist/record-management.js
python3 popup-month-update/stage.py
git diff --cached --stat
git commit -m "Use Hub deletion popup and add finance month filters"
git push -u origin popup-month-filters
```

Open a pull request to main and merge through your usual reviewed workflow. Wait for Cloudflare Pages to deploy, then reload the Hub.

No new SQL migration or Edge Function deployment is needed for this follow-up. The prior Record Management migration and delete-record function must already be installed. runtime-config.js and secrets are not touched.

The installer checks the three affected files and makes a backup outside the repository. If it says STOP, share that output; do not force replacement.

## Verification

Use a disposable record. Cancel once, then confirm Delete in the Hub popup. Check it remains deleted after refreshing. Test a record with dependencies to see the inline error. For finance, select a month and year in both Quotes and Invoices and confirm the list contains the expected issue dates.

Local browser checks passed for the popup, cancellation, confirmed deletion, inline errors/retry, month/year combinations, existing filters and pagination. Live deployment has not been performed here.
