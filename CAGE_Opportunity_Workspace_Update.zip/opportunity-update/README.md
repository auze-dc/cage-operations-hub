# CAGE opportunity workspace update

Prepared 27 September 2026. Requires the working quotation/order workflow and chat fixes already installed. This package is not deployed automatically.

## What you get

- A compact, responsive discovery workspace with New, Closing soon, Saved, Applying, Submitted, Archived and Past deadlines views.
- Search, type, geography and eligibility filters; relevance, deadline and newest sorting; results shown in batches of 25.
- Owners, bid/no-bid decisions, notes, checklists, submission dates/references, supporting file uploads and links to existing CRM opportunities/projects.
- Staff verification of issuer, value, deadline/timezone, eligibility and document requirements. The verifier and time are recorded in the database.
- Source health, scan history, changed-source flags, duplicate URL prevention and possible duplicate-title flags.
- Existing contract/delivery records remain accessible in the expandable section below discovery.
- Deadline reminders in this workspace for saved/applying notices due within seven days. No new automatic staff/client emails, external applications or requests are generated.

## Scanning: exact scope

Discovery checks selected official listings (PPDA, UNGM, AfDB corporate procurement, UNICEF Venture Fund and IUCN) plus search RSS queries restricted to configured source domains. Search rotates one domain per group each half-day and alternates Malawi/Africa terms. Supporting groups include GIZ/develoPPP, GSMA, Grand Challenges and secondary discovery websites. This is not complete internet or portal coverage.

PPDA notice rows are parsed directly, with relevance based on the procurement title rather than the issuing organisation's name. Other direct listing parsers and search feeds report failures instead of hiding them. Source pages are fetched only from the configured domain allowlist, with redirect checks, timeouts and response-size limits. PDF-only and login-protected notices require manual review; direct links remain available.

Each scan checks at most 24 candidate pages, including up to 12 saved/applying/submitted opportunities selected oldest-check-first. Large portfolios therefore rotate over multiple scans. Existing data and tracking are retained when a source fails. Source text changes prompt review; they are not automatically asserted to be a confirmed cancellation or requirement change.

This release uses source excerpts and deterministic keyword/geography ranking, not AI eligibility judgments. It makes no paid OpenAI calls. Missing deadlines stay “Not stated”; they are never changed to rolling dates. Notices closing in under 48 hours are retained. Date-only reminders use Malawi calendar dates; staff should verify the exact closing time/timezone.

Canonical URLs remove common tracking parameters and fragments. Matching URLs are not re-added during scans. Similar titles across different websites are flagged as possible duplicates, not automatically merged without proof they refer to the same notice. Staff can archive redundant entries.

The source catalog replaces the old broad feed list; legacy OPPORTUNITY_FEEDS/OPPORTUNITY_MIN_SCORE/AI_MODEL settings are not used by this scanner. Do not remove shared secrets that other functions use.

## 1. Install in Codespaces

Download this ZIP and upload it into `/workspaces/cage-operations-hub` in the Codespaces file explorer.

```bash
cd /workspaces/cage-operations-hub
git switch -c opportunity-workspace
unzip CAGE_Opportunity_Workspace_Update.zip
python3 opportunity-update/install.py
npm run check
```

If the ZIP was uploaded to GitHub's main branch instead, obtain that one file first:

```bash
git fetch origin
git restore --source=origin/main -- CAGE_Opportunity_Workspace_Update.zip
```

If you have already created the branch, skip git switch. The installer verifies all baseline hashes before changing any file and makes a backup outside the repository. If it stops on a different file, share the output rather than forcing it. Runtime configuration and credentials are untouched.

## 2. Apply database migration

In the SQL Editor for the Supabase project used by the Hub, run the full contents of:

`supabase/migrations/20260927170000_opportunity_workspace.sql`

This adds shared tracking and scan history, preserves existing matches, imports older JSON-only results, fixes the type constraint and enforces commercial-module permissions. It also disables the old automatic opportunity email trigger. Staff access to other modules and their email routing is unchanged.

## 3. Deploy the scanner

```bash
npx supabase functions deploy opportunity-scan --use-api --no-verify-jwt
```

The function checks signed-in users itself. Manual scans require an active Administrator/Manager with Commercial edit access. Scheduled calls require the existing CRON_SECRET. The scanner uses the standard Supabase environment variables. You do not need to generate a fresh personal access token for every deployment if your CLI login still works.

## 4. Configure the existing schedule

Run `supabase/setup/CONFIGURE_OPPORTUNITY_SCHEDULE.sql` in SQL Editor. It changes only the schedule of `cage-daily-opportunity-scan`, preserving the job command, URL, secret and Active state.

Review Supabase Integrations → Cron and ensure your intended job is Active. Twice-daily schedule: 07:00 and 19:00 CAT, every day. The workspace settings can reduce this to daily or manual-only. If your existing job has a different name, the SQL stops; inspect that job rather than adding a duplicate. Do not paste secrets into screenshots or chat.

## 5. Commit, push and merge

```bash
git add dist/app.js dist/production.js dist/index.html dist/opportunities.js dist/opportunities.css supabase/functions/opportunity-scan/index.ts supabase/functions/opportunity-scan/core.js supabase/migrations/20260927170000_opportunity_workspace.sql supabase/setup/CONFIGURE_OPPORTUNITY_SCHEDULE.sql
git diff --cached --stat
git commit -m "Improve opportunity discovery and application tracking"
git push -u origin opportunity-workspace
```

In GitHub, create a pull request with base `main` and compare `opportunity-workspace`. Review it, merge after checks pass, then wait for Cloudflare deployment. Refresh the Hub. Do not commit the ZIP, extracted package directory, runtime-config.js or secrets.

## 6. Verify after deployment

1. Open Tenders, grants & contracts. Existing discoveries and contract records should remain accessible.
2. Run Scan now and open Sources & scan health. Partial/failed sources must be visible. An empty search feed is not proof that its portal has no opportunities.
3. Save an opportunity, assign an owner, add a note, refresh and reopen it.
4. Upload a test supporting file and check another authorised colleague can open it.
5. Verify a deadline and applicant route from the notice. Check filters and reminder counts.
6. Record a test submission using a clearly marked test notice, not a real unsubmitted application.
7. Confirm commercial viewers can read but cannot save or upload, and users without commercial access cannot read the module.

## Rollback

Restore overwritten code from the backup directory printed by the installer and redeploy the prior scanner/frontend. Keep the new database tables once staff have recorded work; removing them would lose tracking history. Restoring the old scanner would reintroduce its filtering limitations. Request a reviewed migration rollback if needed.
