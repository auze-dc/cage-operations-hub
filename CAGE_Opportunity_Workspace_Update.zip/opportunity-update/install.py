#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,shutil
root=Path.cwd();package=Path(__file__).resolve().parent
manifest=json.loads((package/'MANIFEST.json').read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
pending=[]
for entry in manifest:
 target=root/entry['path'];payload=package/'payload'/entry['path']
 if digest(payload)!=entry['after']:raise SystemExit('STOP: damaged package file: '+entry['path'])
 current=digest(target)
 if current==entry['after']:continue
 if current!=entry['before']:raise SystemExit('STOP: your current file differs: '+entry['path']+'\nNo files changed. Share this output; do not force replacement.')
 pending.append(entry)
if not pending:print('Already installed. No files changed. This does not confirm deployment.');raise SystemExit(0)
backup=root.parent/('cage-before-opportunity-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f'));backup.mkdir()
for entry in pending:
 target=root/entry['path'];saved=backup/entry['path'];saved.parent.mkdir(parents=True,exist_ok=True)
 if target.is_file():shutil.copy2(target,saved)
for entry in pending:
 target=root/entry['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(package/'payload'/entry['path'],target)
print('Fix installed locally. Nothing deployed. Originals backed up to:',backup)
print('\n'.join(e['path'] for e in pending))
