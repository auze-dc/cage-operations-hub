# Validation and limits

Tested against the supplied Hub repository composed with the already delivered chat and quote/order updates. No production records, live credentials or emails were used. Preview screenshots contain fictional examples, not current opportunities.

Local tests:
- Applied existing migrations plus this migration in isolated PostgreSQL (PGlite), with test auth/storage/extension scaffolding.
- Passed cross-organisation isolation, commercial view/edit permissions, regular staff editing, duplicate manual add, optimistic concurrency, submission validation, link validation, attachment visibility helper and scan lease tests.
- Passed Edge Function tests with mocked transport/database: authentication, role/module checks, organization binding, canonical deduplication, near-deadline retention, preserved statuses/evidence after failed rechecks, and overlapping-scan prevention.
- Passed parser tests: RSS/Atom validation, date extraction, unknown/rolling dates, opportunity type preservation, unsafe URL rejection, redirect restrictions, PPDA table parsing and source text handling.
- Passed full-page browser integration: filters, save/refresh, retained results after failed scan, source-health dialog and mobile layout. No browser script errors in this flow.
- Installer, idempotent reinstall, repository production checks and changed-JavaScript syntax checks run when packaging.

Live source checks from this environment on 27 September 2026:
- PPDA: HTTP 200; parsed 50 notice rows from the current listing. None matched the tested capability-title filter; no false example matches were inserted.
- Selected-domain Bing RSS: responded successfully to the shorter queries but returned zero items in this check. Earlier longer queries timed out. Empty feed results do not establish complete source coverage.
- UNGM: HTTP 403 on the tested notice URL.
- MANePS: HTTP 502.
- AfDB corporate procurement and UNICEF Venture Fund: HTTP 403.
- IUCN tender listing: request timed out.

These external limitations are surfaced in the product and must be rechecked from the deployed Supabase runtime. Direct parsers for blocked sources are covered by fixtures, not a successful live end-to-end retrieval. No claim is made that all sources are currently accessible or that the scanner finds every opportunity. CAPTCHA/login restrictions are not bypassed.
