#!/usr/bin/env python3
"""Run from the repository root. Validates every file before writing; never runs SQL."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,shutil
root=Path.cwd();package=Path(__file__).resolve().parent
manifest=json.loads((package/'MANIFEST.json').read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
prerequisites={'dist/app.js': '693345d084f4db1172b54643db25cd8e9ba19a0f8511c92a4c309433b8b2ff16', 'supabase/functions/send-document-v2/index.ts': '549c74ca63026c50fb092eaaaf4a088cf1c6d2ff28a423fecefe27f7ec7d8eb9'}
for name,expected in prerequisites.items():
 if digest(root/name)!=expected:raise SystemExit('STOP: prerequisite file differs: '+name+'\nNo files changed. Share this message for review.')
pending=[]
for entry in manifest:
 path=entry['path'];target=root/path;payload=package/'payload'/path
 if digest(payload)!=entry['after']:raise SystemExit('STOP: damaged package file: '+path)
 current=digest(target)
 if current==entry['after']:continue
 if current!=entry['before']:raise SystemExit('STOP: your current file differs: '+path+'\nNo files changed. Share this message for review; do not force replacement.')
 pending.append(entry)
if not pending:
 print('This code update is already installed. No files changed. This does not confirm SQL or deployment.');raise SystemExit(0)
backup=root.parent/('cage-before-document-edit-stamp-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f'));backup.mkdir()
for entry in pending:
 target=root/entry['path']
 if target.exists():
  saved=backup/entry['path'];saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(target,saved)
for entry in pending:
 target=root/entry['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(package/'payload'/entry['path'],target)
print('Code installed. SQL has NOT run. Nothing has been deployed.')
print('Original edited files saved outside the repository:',backup)
print('\n'.join(e['path'] for e in pending))
