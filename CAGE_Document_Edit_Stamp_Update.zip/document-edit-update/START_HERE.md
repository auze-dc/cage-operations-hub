# Edit quotes and invoices; place stamps in blank space

Prepared against the Direct Quote Send + Sync Isolation updates from 24 September 2026. Not live until the steps below are completed. Existing category, presence, private location, login and isolated-sync code is preserved. Runtime configuration and secrets are not included or changed.

## What changes

- Finance tables and project financial lists gain an **Edit** button for users with Finance edit access. Existing record visibility continues to apply. Finance View users can still send accessible documents but cannot change financial content.
- Forms open with the existing client, dates, line items, currency, service and payment details. Save keeps the document ID and number, except for accepted quotes.
- A sent quote returns to Draft when edited. No manager approval is required. Save first, review the PDF, then use Send to deliver the revised version. Saving does not email anyone. Previous sends and client messages remain in history; an old response link cannot approve changed content.
- For an accepted quote, **Save as new quotation** creates a new numbered draft linked to the original. The original acceptance remains intact. The original request link is retained on the original quote.
- Invoice payments remain intact. The total cannot drop below recorded payments, and currency cannot change after payment. A legacy Paid invoice with no payment entries needs payment reconciliation before its total can change. Changes are recorded in the audit log.
- Concurrent edits are rejected with an explanatory message and the edited form stays open. An unresolved delivery attempt briefly blocks editing that document to avoid changing it mid-send.
- The shared browser/email PDF generator checks text, tables and totals before placing a stamp. Placement varies by document and revision, and is stable when regenerating the same saved revision. The stamp and curved date retain their existing appearance.
- A stamp uses an empty rectangle with a safety gap. It does not cover text, enter table cells or create a stamp-only page. If all pages are full, actual content is reflowed around a reserved area. Genuinely long documents may still need multiple pages; content is never removed to force one page.

`examples/FES_One_Page_Layout_Preview.pdf` reconstructs the supplied FES example to demonstrate the new one-page layout. It is a layout example, not a new send or a change to your saved quote. Previously emailed PDFs do not change.

## 1. Install the code

Use your Codespaces checkout containing the latest Direct Quote Send and Sync Isolation changes. Save/commit your current tracked code first, and keep your production backup. Do not clear staff browser data or discard their drafts.

Upload **CAGE_Document_Edit_Stamp_Update.zip** to `/workspaces/cage-operations-hub`. Run one command at a time:

```bash
cd /workspaces/cage-operations-hub
git status --short
git switch -c document-edit-stamp
unzip CAGE_Document_Edit_Stamp_Update.zip
python3 document-edit-update/install.py
npm run check
git diff --check
```

If you uploaded the ZIP to GitHub main instead, retrieve just the ZIP before unzipping:

```bash
git fetch origin
git restore --source=origin/main -- CAGE_Document_Edit_Stamp_Update.zip
```

The installer checks every target before making changes and saves original edited files outside the repository. If it says **STOP**, share that message; do not force replacement. It does not run SQL or deploy code.

## 2. Run this ONE new SQL migration

```bash
code supabase/migrations/20260924200000_edit_finance_documents.sql
```

Copy all contents into **Supabase → CAGE Operations Hub → SQL Editor → New query**, then Run once. Project reference: `lrvcpiobxqtmcntwhaat`.

Expect **Success. No rows returned.** The migration adds one authenticated editing function and uses the existing access, workflow and concurrency checks. It does not reset or delete business records. If it fails, stop and share the error. A repeat deliberately fails because the function already exists. Do not run old migrations, `db push` or `db reset`.

## 3. Deploy the email PDF generator

This step is required for the PDFs emailed to clients, separately from the website deployment:

```bash
npx supabase functions deploy send-document-v2 --project-ref lrvcpiobxqtmcntwhaat --use-api
```

If login is requested, run `npx supabase login`, finish login and repeat. Wait for **Deployed Functions**. Preserve JWT verification and existing secrets. The API build option avoids the local DNS/download failure encountered previously.

## 4. Publish the website

```bash
python3 document-edit-update/stage.py
git --no-pager diff --cached --stat
git commit -m "Edit financial documents and place stamps in empty PDF space"
git push -u origin document-edit-stamp
```

On GitHub, create a pull request from **document-edit-stamp** into **main**. Ensure the previous updates are included or already merged. Wait for checks, review, merge, and wait for the website deployment to succeed. Do not commit runtime-config.js, secrets, the ZIP or the unpacked update folder.

## 5. Verify in the Hub

1. Save any currently typed work before refreshing the Hub. Keep the same browser profiles so queued/recovery drafts remain available.
2. Open Finance with an account that has Finance Edit. Click **Edit** beside a draft quote. Change its description or line items, save, reopen, and verify the same number and updated details.
3. Preview the FES-style quote. It should fit on one page with the stamp beside the blank payment area, away from content. Use Send only when the document and recipients are correct. Check a received PDF too; browser Preview alone does not verify the Edge deployment.
4. Edit an accessible invoice. Confirm payments and its number remain unchanged.
5. An accepted quote should clearly offer **Save as new quotation**. Do not create a real revision just to test unless you need it.
6. If saving fails, keep the form and copy any important unsaved text before reloading. The server's exact rejection appears in the form; unrelated Hub work remains available.

No live messages were sent and no live records were changed during local testing.
