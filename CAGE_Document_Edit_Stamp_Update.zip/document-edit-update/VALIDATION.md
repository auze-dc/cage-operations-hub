# Local validation

- PostgreSQL-compatible PGlite tests ran against the available exported schema plus installed document migrations. Staff edited accessible sent/draft quotes and invoices; stale records, protected fields, invalid items, view-only, shared, anonymous and cross-organisation requests were rejected. Accepted client response and source quote remained intact while a new numbered revision was created. Invoice payment records, currency and minimum total protections passed.
- Real form markup was tested in Chromium at desktop and mobile sizes. Existing line items survive form reset, edits do not fall through to the creation handler, failed saves retain typed text, accepted-revision wording is explicit, and subsequent new-document forms reset correctly.
- FES and invoice layout examples render to one page. Long and dense samples render across content-bearing pages. Extracted image/text geometry confirms no stamp intersects body text and no page contains only a stamp. The FES page and form screenshots were visually inspected.
- Shared browser and Edge PDF generator bytes are identical. Existing production static checks pass.
- Local tests do not verify the live database, deployment, user accounts or inbox delivery. Deployment and the focused live checks in START_HERE.md remain necessary.
