# Einstein — CAGE’s in-platform assistant

This package adds an **Ask Einstein** button and side panel. It is built against the latest CAGE work-and-opportunity update supplied in this conversation. It has not been deployed to your live Hub.

## What members get

- Fifteen built-in navigation guides, with buttons to open the relevant module. These work without an API key.
- AI explanations and text drafting after activation, informed by the versioned guides and the member’s current module access.
- Optional work context: an unchecked option sends up to 20 authorized project, task, request or CRM summaries for the current module. My Work includes only the member’s assigned/collaborating tasks. It excludes finance records, private chats and file contents.
- A conversation held in this browser tab, isolated by account and cleared on logout; New conversation clears it immediately. The backend stores usage counters, not conversations.
- Clear retry errors and mobile layout. Answer text is rendered safely.

Einstein cannot send emails, create/edit/delete records, grant permissions, browse live opportunities or read this ChatGPT account’s conversation history. File analysis and voice are not included. Future screen changes should update both copies of the guide and its version.

## 1. Put the ZIP in Codespaces

Download **CAGE_Einstein_Assistant_Update.zip** from ChatGPT, then upload it in the VS Code Explorer to `/workspaces/cage-operations-hub`. Uploading it to GitHub or downloading it onto your laptop does not automatically put it in this Codespace.

In the Codespaces terminal:

```bash
cd /workspaces/cage-operations-hub
ls -l CAGE_Einstein_Assistant_Update.zip
git status --short
git switch -c einstein-assistant
unzip CAGE_Einstein_Assistant_Update.zip
python3 einstein-update/install.py --check
python3 einstein-update/install.py
npm run check
```

If the branch already exists, use `git switch einstein-assistant`. If the ZIP is missing, upload it first. If the installer reports a different source, stop and share that output; do not force it. It refuses to overwrite unexpected changes and makes a backup outside the repository. It never replaces runtime configuration or credentials.

## 2. Apply the database migration

Open this actual file in VS Code:

`supabase/migrations/20260930230000_einstein.sql`

Copy its **entire contents**, from `begin;` through `commit;`, into a new query in your existing Supabase project’s SQL Editor and run it. Do not paste the filename as SQL. The file is included in the ZIP and the installer checks its checksum.

This creates protected usage counters and an authenticated usage-reservation function. It can be run again safely. Limits are 6 requests per minute and 40 per day per member, and 400 per company per day (CAT). Attempts reaching the AI stage count even when the provider fails; built-in guides do not count. These are request caps, not a guaranteed monetary budget.

## 3. Activate AI answers

Use an OpenAI API project with billing enabled and create an API key. A ChatGPT subscription is not this integration’s API billing.

In **Supabase → Edge Functions → Secrets**, add:

| Name | Value |
| --- | --- |
| `OPENAI_API_KEY` | Your OpenAI API key |
| `EINSTEIN_MODEL` | `gpt-4.1-mini`, or another text model available to your API project that supports the Responses API |

Enter the key only in Supabase Secrets. Do not put it in GitHub, frontend code or this chat. No key is shipped in this package. Review usage in your OpenAI project after testing.

Official references: https://developers.openai.com/api/docs/models/gpt-4.1-mini and https://developers.openai.com/api/docs/guides/text

Then run in the Codespaces terminal:

```bash
npx supabase functions deploy einstein --use-api --no-verify-jwt
```

Use your existing linked CAGE Supabase project. The function validates the member’s bearer token with Supabase Auth, verifies an active nonshared profile and uses that user’s permissions. `--no-verify-jwt` avoids the legacy gateway verifier; it does not make the function anonymous. Requests without a valid signed-in user are rejected. The API key stays server-side.

The API request uses `store: false`. Questions, recent conversation and any explicitly included work summaries still leave the Hub for processing by OpenAI; your API organization’s applicable retention controls apply.

## 4. Publish the frontend

The SQL and Edge Function deployment do not publish the website. In the terminal:

```bash
python3 einstein-update/stage.py
git diff --cached --stat
git commit -m "Add Einstein assistant with navigation guides and secure AI answers"
git push -u origin einstein-assistant
```

The staging script adds only the eight update files. Review any other files already staged before committing.

On GitHub, open **Pull requests → New pull request**. Choose **base: main**, **compare: einstein-assistant**, create and merge the PR. You do not need to wait for a Compare & pull request banner. If there is no difference to compare, confirm the commit was pushed and is not already merged.

Wait for the **Cloudflare Pages production** deployment of that merge commit to succeed. Reload the production Hub. A branch preview is not the production deployment.

## 5. Confirm it is working

1. Sign in as a staff member and find **Ask Einstein** near the bottom right.
2. Open a built-in guide and use its Open button to navigate.
3. Ask “How do I record a payment and send a receipt?” with AI enabled.
4. On My Work, optionally tick Include work details and ask about your tasks.
5. Sign out and confirm the panel closes. Sign in as another member and confirm the first member’s conversation is absent.

“AI answers are not activated” means a secret/model is missing. A database-setup message means the migration needs applying. A provider/billing message means check the API project and model. A missing button usually means the frontend commit has not reached production. Built-in guides remain available when AI answers fail.

## Validation and limitations

See TEST_RESULTS.txt. Database behavior was tested locally, the browser was tested with a mocked signed-in backend, and AI transport was tested with mocked responses. No real OpenAI request, production Supabase mutation or Cloudflare deployment was performed for you. Your final live check requires your API key and deployment.

## Rollback

For the frontend, revert this PR and redeploy its parent commit through Cloudflare. The installer also records the pre-update files in its printed backup folder. The added database counters and function can remain unused; there is no need to delete operational Hub data. Disable the Einstein Edge Function if you want to stop API requests.
