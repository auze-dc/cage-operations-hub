# CAGE Work and Opportunity Update

This update builds on the installed Company Collaboration update. It has not been deployed to your production site.

## Included

- Quotes and invoices prefill Alexander, Ndapile and the signed-in sender in an editable CC field. Remove any address before sending if necessary. Recipients are deduplicated, and email copies do not appear on the PDF. Old frontend versions retain their automatic server copies until refreshed.
- My Work has Add task and a standalone task list. A project is optional. Active internal members can save and edit their own standalone tasks even without Work Board edit access. The owner is the signed-in member; collaborators can be selected. Tasks, subtasks and recurrence settings are persisted. Existing module controls still apply to the wider planner.
- Browser tabs use the supplied CAGE symbol; the full header logo stays in place.
- Opportunity discovery uses two searches per source group and direct secondary RSS feeds. It follows relative procurement links and checks page content before rejecting short titles. It checks up to 40 pages per run, including up to 12 tracked notices, and rotates remaining candidates. Historical undated notices are excluded from Discover after recheck, but remain under All. Source health shows candidate, exclusion and unavailable-page counts.

## 1. Download and install in Codespaces

Download CAGE_Work_And_Opportunity_Update.zip from this conversation. In the Codespaces Explorer, upload it into /workspaces/cage-operations-hub. Uploading to the GitHub website alone does not place it in Codespaces.

Run in the Codespaces terminal:

```bash
cd /workspaces/cage-operations-hub
git switch -c work-opportunity-update
unzip CAGE_Work_And_Opportunity_Update.zip
python3 work-opportunity-update/install.py --check
python3 work-opportunity-update/install.py
npm run check
```

If the branch already exists, use `git switch work-opportunity-update`. If the installer reports a source mismatch, stop and share its output. It stops before changing files and does not overwrite unexpected edits. Successful installs create a dated backup outside the repository. Re-running it is safe.

## 2. Apply the database migration

Open this file in Codespaces and copy its full contents:

`supabase/migrations/20260930200000_standalone_tasks.sql`

Paste it into your project's Supabase SQL Editor and run it. This requires the previous Company Collaboration migration to be installed. Run only this new migration for this update; do not rerun older migrations that replace the same workspace functions. This step enables the standalone task save endpoint. It does not publish the website.

## 3. Deploy the three Edge Functions

In the Codespaces terminal, using your existing linked Supabase project:

```bash
npx supabase functions deploy send-document-v2 --use-api
npx supabase functions deploy send-document --use-api
npx supabase functions deploy opportunity-scan --use-api --no-verify-jwt
```

The scanner validates the staff session or the existing Cron secret inside the function. This update preserves your scan schedule and secrets. No new API key is required.

## 4. Publish the frontend

```bash
python3 work-opportunity-update/stage.py
git diff --cached --stat
git commit -m "Add editable email copies, standalone tasks and broader opportunity discovery"
git push -u origin work-opportunity-update
```

Open the repository on GitHub, choose Pull requests → New pull request, set base `main` and compare `work-opportunity-update`, review and merge. If GitHub offers no automatic banner, use that manual New pull request route. Wait for the existing Cloudflare Pages production deployment to finish. Reload the Hub with Command+Shift+R (Mac) or Ctrl+Shift+R (Windows).

## 5. Verify after publishing

1. Open a quote and an invoice send form: CC contains Alexander, Ndapile and your email. Clear one address and confirm it stays cleared before sending. Check Delivery history after a real send you intend to make.
2. My Work → Add task: leave Project as No project, complete title, output and due date, save, then refresh. Open the task and edit it. Test as an ordinary member too.
3. Check the browser tab icon. A browser may retain the previous favicon until its tab is reopened.
4. Tenders, grants & contracts → Scan now. Wait for completion, then open View source health. The Discovery summary shows checked and skipped counts. Check All and Past deadlines as well as Discover.

## Validation and limits

Local production checks passed. Browser tests exercised the actual task form and CC fields. Database integration tests checked task persistence, migration reruns, view-only staff access, owner protection and company isolation. Mocked email tests checked both endpoints, both document types, removals, deduplication and unchanged PDF data. Scanner fixtures checked relative links, detail-page relevance, deadline extraction, historical flags, rotating selection and blocked redirects.

Live discovery was not verified against your deployed Supabase project. Search feeds can be incomplete or blocked; PDFs and login-only portals still require manual review. A fetched page or relevance score does not confirm a current open deadline or eligibility. Source errors remain visible rather than presenting a failed scan as complete. This update does not guarantee a fixed number of opportunities and does not insert invented notices.
