from pathlib import Path
import argparse,datetime,hashlib,json,shutil
parser=argparse.ArgumentParser(description='Install the reviewed CAGE work and opportunity update.')
parser.add_argument('--repo',default='.')
parser.add_argument('--check',action='store_true')
a=parser.parse_args();repo=Path(a.repo).resolve();bundle=Path(__file__).resolve().parent
if not (repo/'dist/app.js').is_file() or not (repo/'supabase/functions').is_dir():raise SystemExit('Run from the cage-operations-hub repository, or pass --repo PATH.')
manifest=json.loads((bundle/'MANIFEST.json').read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
changes=[];errors=[]
for name,entry in manifest.items():
 target=repo/name;payload=bundle/'payload'/name
 if not target.resolve().is_relative_to(repo) or target.is_symlink():errors.append(name+': unsafe target');continue
 if digest(payload)!=entry['after']:errors.append(name+': payload checksum mismatch');continue
 current=digest(target)
 if current==entry['after']:continue
 if current not in [entry['before'], *entry.get('before_alternates', [])]:errors.append(name+': source differs from the supplied repository snapshot');continue
 changes.append(name)
if errors:raise SystemExit('Stopped before changing any files:\n'+'\n'.join(errors))
if not changes:print('This update is already installed. Nothing changed.');raise SystemExit(0)
if a.check:print('Ready to install '+str(len(changes))+' files. Nothing changed.');raise SystemExit(0)
backup=repo.parent/('cage-before-work-opportunity-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
backup.mkdir(parents=True)
for name in changes:
 src=repo/name
 if src.exists():dest=backup/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
(backup/'NEW_FILES.json').write_text(json.dumps([n for n in changes if not (repo/n).exists()],indent=2))
try:
 for name in changes:
  target=repo/name;target.parent.mkdir(parents=True,exist_ok=True);temp=target.with_name(target.name+'.work-opportunity-install');shutil.copyfile(bundle/'payload'/name,temp);temp.replace(target)
except Exception:
 for name in changes:
  target=repo/name;original=backup/name
  if original.exists():shutil.copy2(original,target)
  elif target.exists():target.unlink()
 raise
print('Installed '+str(len(changes))+' files. SQL has NOT run. Nothing has been deployed.')
print('Backup: '+str(backup))
print('Follow work-opportunity-update/START_HERE.md for SQL, email functions and frontend publishing.')
