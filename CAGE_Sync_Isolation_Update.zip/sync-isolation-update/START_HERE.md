# Keep the Hub working when one change is rejected

This follow-up requires the installed Direct Quote Send update. It preserves invoice/quote sending, client responses, login fixes, categories, branding and location controls.

## Behaviour

- The server first tries the normal save. If a record-level check fails, it isolates the changes, retains all existing access/ownership/workflow checks, and saves independent valid records.
- Rejected records move to **Drafts needing attention**, showing the section, record name/number, record ID and server reason. Staff are told to contact an administrator for access or assignment issues.
- These drafts stay on the same device and account. They are not deleted. Staff can download recovery copies and retry an individual draft after review.
- New linked records dependent on a rejected new record also wait for review. Cyclic dependencies that cannot be saved as a batch are preserved for review rather than partially forced through.
- Incoming workspace updates continue around unfinished drafts. Newer local edits are preserved. Conflicts are retained for review and do not silently overwrite a colleague's changes.
- Existing queued drafts, including Mayamiko's, use the recovery process on their next sync after the new frontend loads. Denied drafts do not repeatedly retry in the background. Staff still need an administrator to correct the underlying access for those specific records.

This fixes the blocking behaviour; it does not grant wider access or pretend a rejected action succeeded. Network outages still prevent live updates until connectivity returns.

## 1. Install code

Use the checkout containing your completed direct-quote-send update. Save and commit any current code work first. Keep your current production backup. Upload **CAGE_Sync_Isolation_Update.zip** into `/workspaces/cage-operations-hub` in Codespaces.

If you upload the ZIP through the GitHub website to main instead, retrieve only that ZIP in Codespaces first:

```bash
cd /workspaces/cage-operations-hub
git fetch origin
git restore --source=origin/main -- CAGE_Sync_Isolation_Update.zip
```

Then run these one at a time:

```bash
cd /workspaces/cage-operations-hub
git status --short
git switch -c staff-sync-isolation
unzip CAGE_Sync_Isolation_Update.zip
python3 sync-isolation-update/install.py
npm run check
git diff --check
```

The installer checks every changed file before writing and keeps backups outside the repository. If it says STOP, share the message; do not overwrite your local differences. It does not run SQL, deploy the site, or change secrets/runtime configuration.

## 2. Run only the new SQL migration

Open the installed file in Codespaces:

```bash
code supabase/migrations/20260924180000_isolated_workspace_sync.sql
```

Copy the complete contents. In Supabase project CAGE Operations Hub (`lrvcpiobxqtmcntwhaat`), open SQL Editor → New query. Paste and run once as the database owner.

Expected: **Success. No rows returned.** If there is any error, stop and share it. The migration runs in one transaction, creates one new authenticated-only sync function, and does not reset/delete business records or alter the original access rules. A second run deliberately fails on the existing function.

Do not run old migrations, `db reset`, or `db push`.

**No Edge Function deployment is needed for this update.** Install the SQL before publishing the frontend.

## 3. Publish the frontend

```bash
python3 sync-isolation-update/stage.py
git --no-pager diff --cached --stat
git commit -m "Keep workspace syncing when individual records are rejected"
git push -u origin staff-sync-isolation
```

Create a GitHub pull request from `staff-sync-isolation` to `main`. Ensure the direct-quote-send update is already merged or included. Wait for checks, review, merge, and wait for the website deployment to finish.

## 4. Recover Mayamiko's and Ian's sessions

1. Keep their existing browser profile and device. Do not clear browser data, use another profile to recover drafts, or click Discard.
2. Copy any currently typed but unsaved form text somewhere safe before refreshing the tab.
3. Reload the Hub after deployment. Existing saved local drafts are restored and processed automatically. If still pending, open the sync indicator and click Retry pending changes once.
4. Valid changes should save. Rejected records appear in Drafts needing attention, with an exact record ID and reason.
5. Confirm a known recent chat message and workspace update appear. Normal work can continue while restricted drafts remain stored separately.
6. Download the recovery drafts if needed. Give the administrator the record ID and reason; full draft downloads can contain business information.
7. Once access/assignment is corrected, use Retry this draft after review. If the server record has changed meanwhile, the draft remains a conflict for review rather than overwriting it.

Existing client approvals, permissions and real work remain intact. No live staff data or messages were used during testing.
