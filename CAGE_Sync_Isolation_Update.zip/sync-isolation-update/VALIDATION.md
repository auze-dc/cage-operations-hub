# Validation

Passed locally on the supplied repository/schema plus the completed staff launch and direct-quote-send updates:

- Database (PGlite): mixed allowed/denied batches, workflow trigger failures, exact failure IDs, no forbidden writes, independent messages saved, idempotent mixed-batch retries, conflicts isolated, new-record dependency handling, retry after access restoration, reset epoch guard, anonymous/shared/cross-organisation rejection.
- Client sync tests: incoming changes merged around dirty records with original conflict baseline retained, blocked draft recovery, manual retry, storage-write failure preserves source draft, in-flight newer edits retained, legacy draft restoration, account-switch guards, reset quarantine, polling while dirty.
- Browser recovery UI: record label and ID/reason, administrator guidance, safe escaped text, download action, individual retry, resolved count and dialog close. Mobile layout visually inspected.
- Repository production checks and JavaScript syntax checks.
- Invoice/quote database regression checks from previous update passed with new migration.

Tests use synthetic data and mocked client/provider calls, not live accounts or production. Deployment and real-browser verification are still required.

Test files are included under tests/. Use Node 24 with @electric-sql/pglite and playwright. Set CAGE_TEST_REPO to the updated repository. Database test also uses CAGE_TEST_SCHEMA (schema dump). Browser test can use CAGE_TEST_BROWSER for Chromium. No test connects to production.
