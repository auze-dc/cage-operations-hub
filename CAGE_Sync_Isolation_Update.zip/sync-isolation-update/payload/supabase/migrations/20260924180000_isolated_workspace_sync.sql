begin;
-- Preserve the existing validator and access checks. Try the original atomic
-- operation first; on record-level rejection, use isolated subtransactions.
create function public.save_workspace_changes_isolated(changes jsonb, expected_epoch text default null) returns jsonb
language plpgsql security definer set search_path='' as $fn$
declare result jsonb; outcomes jsonb='[]'; waiting jsonb; remaining jsonb;
 c jsonb; dep jsonb; w public.workspace_states; reason text; error_code text;
 progress boolean; blocked boolean; deferred boolean;
begin
 if auth.uid() is null or not exists(select 1 from public.profiles where id=auth.uid() and active and role<>'shared')
 then raise exception 'An active staff account is required' using errcode='42501';end if;
 if jsonb_typeof(changes) is distinct from 'array' or jsonb_array_length(changes)>500 then raise exception 'Invalid sync batch';end if;
 select * into w from public.workspace_states where organization_id=public.current_organization_id() for update;
 if not found then raise exception 'Workspace unavailable';end if;
 if w.data->>'_resetEpoch' is distinct from expected_epoch then raise exception 'Workspace was reset. Reload and review your draft before saving.';end if;
 if exists(select 1 from jsonb_array_elements(changes) x where jsonb_typeof(x) is distinct from 'object' or x->>'key' is null or not(x?'before' and x?'after' and x?'id')) then raise exception 'Invalid sync change';end if;
 if exists(select 1 from jsonb_array_elements(changes) x group by x->>'key',x->>'id' having count(*)>1) then raise exception 'Duplicate sync change';end if;
 begin
  result=public.save_workspace_changes(changes,expected_epoch);
  if coalesce(jsonb_array_length(result->'conflicts'),0)=0 then
   return jsonb_build_object('results',coalesce((select jsonb_agg(jsonb_build_object('key',x->>'key','id',x->'id','status','saved')) from jsonb_array_elements(changes) x),'[]'::jsonb));
  end if;
 exception when others then
  if sqlstate not in ('P0001','42501') and left(sqlstate,2) not in ('22','23') then raise;end if;
 end;
 waiting=changes;
 while jsonb_array_length(waiting)>0 loop
  remaining='[]';progress=false;
  for c in select * from jsonb_array_elements(waiting) loop
   blocked=false;deferred=false;
   -- A child must not be saved when a newly-created referenced parent failed.
   -- Search exact JSON string values, including nested links, not substrings.
   for dep in select * from jsonb_array_elements(changes) x where x->'before'='null'::jsonb and x->'after'<>'null'::jsonb and x->>'id' is not null and (x->>'key',x->>'id') is distinct from (c->>'key',c->>'id') loop
    if jsonb_path_exists(c->'after','$.** ? (@ == $ref)',jsonb_build_object('ref',dep->>'id')) then
     if exists(select 1 from jsonb_array_elements(outcomes) o where o->>'key'=dep->>'key' and o->>'id'=dep->>'id' and o->>'status'<>'saved') then blocked=true;exit;
     elsif not exists(select 1 from jsonb_array_elements(outcomes) o where o->>'key'=dep->>'key' and o->>'id'=dep->>'id' and o->>'status'='saved') then deferred=true;
     end if;
    end if;
   end loop;
   if blocked then
    outcomes=outcomes||jsonb_build_array(jsonb_build_object('key',c->>'key','id',c->'id','status','blocked','code','dependency','reason','A linked new record could not be saved. Ask an administrator to review its access first.'));progress=true;
   elsif deferred then remaining=remaining||jsonb_build_array(c);
   else
    begin
     result=public.save_workspace_changes(jsonb_build_array(c),expected_epoch);
     if coalesce(jsonb_array_length(result->'conflicts'),0)>0 then
      outcomes=outcomes||jsonb_build_array(jsonb_build_object('key',c->>'key','id',c->'id','status','conflict','code','conflict','reason','The saved record changed. Review the current record before retrying your draft.'));
     else outcomes=outcomes||jsonb_build_array(jsonb_build_object('key',c->>'key','id',c->'id','status','saved'));
     end if;
    exception when others then
     get stacked diagnostics reason=message_text,error_code=returned_sqlstate;
     if error_code not in ('P0001','42501') and left(error_code,2) not in ('22','23') then raise;end if;
     outcomes=outcomes||jsonb_build_array(jsonb_build_object('key',c->>'key','id',c->'id','status','blocked','code',error_code,'reason',reason));
    end;
    progress=true;
   end if;
  end loop;
  if not progress then
   for c in select * from jsonb_array_elements(remaining) loop
    outcomes=outcomes||jsonb_build_array(jsonb_build_object('key',c->>'key','id',c->'id','status','blocked','code','dependency','reason','These new linked records depend on each other. Ask an administrator to review this group of drafts.'));
   end loop;
   exit;
  end if;
  waiting=remaining;
 end loop;
 return jsonb_build_object('results',outcomes);
end $fn$;
revoke all on function public.save_workspace_changes_isolated(jsonb,text) from public,anon;
grant execute on function public.save_workspace_changes_isolated(jsonb,text) to authenticated;
notify pgrst,'reload schema';
commit;
