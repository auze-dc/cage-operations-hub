import path from 'node:path';import {pathToFileURL} from 'node:url';
const repo=path.resolve(process.env.CAGE_TEST_REPO||'.')+'/';
import {PGlite} from '@electric-sql/pglite';
import fs from 'node:fs';import assert from 'node:assert/strict';
const db=new PGlite();
await db.exec(`create publication supabase_realtime;create role anon;create role authenticated;create role service_role;create role supabase_admin;create schema auth;create table auth.users(id uuid primary key,email text,email_confirmed_at timestamptz);create function auth.uid() returns uuid language sql as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;create function auth.role() returns text language sql as $$select 'authenticated'::text$$;`);
let schema=fs.readFileSync(process.env.CAGE_TEST_SCHEMA||'upload/schema.sql','utf8').replace(/CREATE EXTENSION[^;]+;/g,'').replace(/^GRANT ALL ON FUNCTION[^;]+;/gm,'').replaceAll('"public"."citext"','text');
await db.exec(schema);await db.exec('set search_path=public;set row_security=on;');
const org='00000000-0000-4000-8000-000000000001',otherOrg='00000000-0000-4000-8000-000000000002';
const ids=Array.from({length:6},(_,i)=>'10000000-0000-4000-8000-00000000000'+(i+1));
await db.exec(`insert into organizations(id,name,slug) values('${org}','Test','test'),('${otherOrg}','Other','other');`);
for(let i=0;i<6;i++){
 const email=i===0?'alexander@cagemw.com':`test${i}@example.invalid`,o=i===4?otherOrg:org;
 await db.query('insert into auth.users values($1,$2,now())',[ids[i],email]);
 await db.query('insert into profiles(id,organization_id,email,full_name,initials,role) values($1,$2,$3,$4,$5,$6)',[ids[i],o,email,'Person '+i,'PP',i<2?'admin':i===5?'shared':'member']);
 await db.query("insert into hub_presence_sessions(user_id,session_id,organization_id,state) values($1,$2,$3,'online')",[ids[i],crypto.randomUUID(),o]);
}
await db.exec(fs.readFileSync(repo+'supabase/migrations/20260924131000_private_device_location.sql','utf8'));
const as=async(uid,role='authenticated')=>{await db.exec('reset role');await db.query("select set_config('request.jwt.claim.sub',$1,false)",[uid||'']);await db.exec('set role '+role);};
const sid=crypto.randomUUID();
const publish=async(id=sid,lat=-13.9)=>db.query('select hub_location_publish($1,$2,33.7,20,now())',[id,lat]);
const list=async()=> (await db.query('select hub_location_list() r')).rows[0].r;
await as(ids[2]);await publish();await assert.rejects(list,/Only Alexander/);
for(const id of [ids[1],ids[2],ids[3],ids[4],ids[5]]){await as(id);assert.equal((await db.query('select hub_location_can_read() r')).rows[0].r,false);await assert.rejects(list,/Only Alexander/);await assert.rejects(()=>db.query('select * from hub_device_locations'),/permission denied/);await assert.rejects(()=>db.query('select * from hub_location_reader'),/permission denied/);}
await as(ids[0]);assert.equal((await list()).length,1);await assert.rejects(()=>db.query('select * from hub_device_locations'),/permission denied/);
await as(ids[2]);await assert.rejects(()=>publish(crypto.randomUUID(),91),/fresh valid/);await assert.rejects(()=>publish(crypto.randomUUID(),NaN),/fresh valid/);
await assert.rejects(()=>db.query("select hub_location_publish($1,1,1,1,now()-interval '2 minutes')",[crypto.randomUUID()]),/fresh valid/);
await as(ids[4]);await publish(crypto.randomUUID());await as(ids[0]);assert.equal((await list()).length,1);
// Another member cannot revoke someone else's session.
await as(ids[3]);await db.query('select hub_location_stop($1)',[sid]);await as(ids[0]);assert.equal((await list()).length,1);
await as(ids[2]);await db.query('select hub_location_stop($1)',[sid]);await publish();await as(ids[0]);assert.equal((await list()).length,0);
// Stop-before-upload and multiple devices.
await as(ids[2]);const stopped=crypto.randomUUID();await db.query('select hub_location_stop($1)',[stopped]);await publish(stopped);const s2=crypto.randomUUID(),s3=crypto.randomUUID();await publish(s2);await publish(s3);await as(ids[0]);assert.equal((await list()).length,2);
await db.exec('reset role');await db.query("update hub_device_locations set expires_at=now()-interval '1 second' where session_id=$1",[s2]);await as(ids[0]);assert.equal((await list()).length,1);
// Expired nullable observations can receive a new fresh sample.
await as(ids[2]);await publish(s3);await publish(s2);await as(ids[0]);assert.equal((await list()).length,2);
await db.exec('reset role');await db.query("update profiles set active=false where id=$1",[ids[2]]);await as(ids[0]);assert.equal((await list()).length,0);
// Editable profile email cannot confer the privilege; identity or verified email changes revoke it.
await db.exec('reset role');await db.query("update profiles set email='alexander@cagemw.com' where id=$1",[ids[1]]).catch(()=>{});await as(ids[1]);await assert.rejects(list,/Only Alexander/);
await db.exec('reset role');await db.query("update auth.users set email='changed@example.invalid' where id=$1",[ids[0]]);await as(ids[0]);await assert.rejects(list,/Only Alexander/);
await as(ids[5]);await assert.rejects(publish,/Active staff/);
await as(null,'anon');await assert.rejects(list,/permission denied/);await assert.rejects(publish,/permission denied/);
await db.exec('reset role');
await db.query("update auth.users set email='alexander@cagemw.com' where id=$1",[ids[0]]);
await db.query("update profiles set active=true,role='viewer' where id=$1",[ids[2]]);
await db.exec(fs.readFileSync(repo+'supabase/migrations/20260923150000_document_responses_v2.sql','utf8'));
await db.exec(fs.readFileSync(repo+'supabase/migrations/20260924130000_staff_invoice_send.sql','utf8'));
await db.query("insert into record_access(user_id,module,scope) values($1,'finance','all')",[ids[2]]);
const invoice={id:'inv1',number:'INV-1',amount:100,currency:'MWK',description:'Real work',status:'Draft',owner:ids[2]};
await db.query('insert into workspace_states(organization_id,data,version) values($1,$2,1)',[org,JSON.stringify({invoices:[invoice],quotes:[],team:[],_resetEpoch:'preserved'})]);
await as(ids[2]);
assert.equal((await db.query("select module_level('finance') r")).rows[0].r,'view');
const prepared=(await db.query('select prepare_staff_invoice_send($1) r',[JSON.stringify(invoice)])).rows[0].r;
assert.equal(prepared.record.amount,100);assert.equal(prepared.version,1);
await assert.rejects(()=>db.query('select prepare_staff_invoice_send($1)',[JSON.stringify({...invoice,amount:1})]),/changed/);
await assert.rejects(()=>db.query('select complete_staff_invoice_send($1)',[crypto.randomUUID()]),/permission denied/);
await as(ids[4]);await assert.rejects(()=>db.query('select prepare_staff_invoice_send($1)',[JSON.stringify(invoice)]),/outside/);
await as(ids[5]);await assert.rejects(()=>db.query('select prepare_staff_invoice_send($1)',[JSON.stringify(invoice)]),/outside/);
await as(null,'anon');await assert.rejects(()=>db.query('select prepare_staff_invoice_send($1)',[JSON.stringify(invoice)]),/permission denied/);
await db.exec('reset role');await db.query("insert into module_access(user_id,module,access) values($1,'finance','none')",[ids[2]]);
await as(ids[2]);await assert.rejects(()=>db.query('select prepare_staff_invoice_send($1)',[JSON.stringify(invoice)]),/outside/);
await db.exec('reset role');await db.query("update module_access set access='view' where user_id=$1 and module='finance'",[ids[2]]);
const attempt=crypto.randomUUID();
await db.query('select register_document_send_v2($1)',[JSON.stringify({id:attempt,organization_id:org,sender_id:ids[2],document_type:'invoice',document_id:invoice.id,request_hash:'test',snapshot:invoice,recipients:{to:['client@example.invalid'],cc:[],bcc:[]},mail_payload:{subject:'Invoice'},invitation_payload:null})]);
await as(null,'service_role');await assert.rejects(()=>db.query('select complete_staff_invoice_send($1)',[attempt]),/not been confirmed/);
await db.exec('reset role');await db.query("update document_sends_v2 set provider_id='provider-test' where id=$1",[attempt]);
await as(null,'service_role');await db.query('select complete_staff_invoice_send($1)',[attempt]);await db.query('select complete_staff_invoice_send($1)',[attempt]);
await db.exec('reset role');const after=(await db.query('select data,version from workspace_states where organization_id=$1',[org])).rows[0];
assert.equal(after.data.invoices[0].amount,100);assert.equal(after.data.invoices[0].status,'Sent');assert.equal(after.data._resetEpoch,'preserved');assert.equal(after.version,2);
assert.equal((await db.query("select count(*) n from audit_log where action='invoice.sent'")).rows[0].n,1);
console.log('PASS invoice: viewer sends accessible invoice; amount spoof, cross-org, shared, anon, no-access blocked; only provider-accepted service completion; idempotent audit/status.');

await db.exec(fs.readFileSync(repo+'supabase/migrations/20260924160000_staff_quote_send.sql','utf8'));
await db.exec('grant execute on function public.prepare_document_delivery(text,jsonb) to authenticated');
const quote={...invoice,id:'q1',number:'Q-1',validUntil:'2099-12-31',status:'Draft'};
await as(null);await db.exec('reset role');
await db.query("update workspace_states set data=jsonb_set(data,'{quotes}',$1),version=version+1 where organization_id=$2",[JSON.stringify([quote]),org]);
await as(ids[2]);assert.equal((await db.query('select prepare_staff_quote_send($1) r',[JSON.stringify(quote)])).rows[0].r.record.status,'Draft');
await assert.rejects(()=>db.query('select prepare_staff_quote_send($1)',[JSON.stringify({...quote,amount:1})]),/changed/);
await assert.rejects(()=>db.query('select complete_staff_quote_send($1)',[crypto.randomUUID()]),/permission denied/);
await as(ids[4]);await assert.rejects(()=>db.query('select prepare_staff_quote_send($1)',[JSON.stringify(quote)]),/outside/);
await as(ids[5]);await assert.rejects(()=>db.query('select prepare_staff_quote_send($1)',[JSON.stringify(quote)]),/outside/);
await as(null,'anon');await assert.rejects(()=>db.query('select prepare_staff_quote_send($1)',[JSON.stringify(quote)]),/permission denied/);
await as(null);await db.exec('reset role');
await db.query("update profiles set role='member' where id=$1",[ids[2]]);
await db.query("update module_access set access='edit' where user_id=$1 and module='finance'",[ids[2]]);
await as(ids[2]);await db.query("select prepare_document_delivery('quote',$1)",[JSON.stringify({...quote,id:'q2',number:'Q-2',request:'request1'})]);
await as(null);await db.exec('reset role');
const qa=crypto.randomUUID();
await db.query('select register_document_send_v2($1)',[JSON.stringify({id:qa,organization_id:org,sender_id:ids[2],document_type:'quote',document_id:quote.id,request_hash:'quote-test',snapshot:quote,recipients:{to:['client@example.invalid'],cc:[],bcc:[]},approver:'client@example.invalid',token_hash:'test-hash',expires_at:'2099-12-31',mail_payload:{subject:'Quote'},invitation_payload:null})]);
await as(null,'service_role');await assert.rejects(()=>db.query('select complete_staff_quote_send($1)',[qa]),/not been confirmed/);
await db.exec('reset role');await db.query("update document_sends_v2 set provider_id='test' where id=$1",[qa]);
await as(null,'service_role');await db.query('select complete_staff_quote_send($1)',[qa]);await db.query('select complete_staff_quote_send($1)',[qa]);
await db.exec('reset role');
assert.equal((await db.query("select data->'quotes'->0->>'status' s from workspace_states where organization_id=$1",[org])).rows[0].s,'Sent');
assert.equal((await db.query("select count(*) n from audit_log where action='quote.sent'")).rows[0].n,1);
await as(ids[2]);await assert.rejects(()=>db.query("select prepare_document_delivery('quote',$1)",[JSON.stringify({...quote,id:'q3',status:'Accepted'})]),/manager/);
console.log('PASS: draft quotes sent without approval; viewer sends canonical only; editor creates request-linked draft; shared/anon/cross-org denied; provider required; completion idempotent; fake acceptance blocked.');

await as(null);await db.exec('reset role');
await db.exec(fs.readFileSync(repo+'supabase/migrations/20260924180000_isolated_workspace_sync.sql','utf8'));
await db.query("update record_access set scope='own' where user_id=$1 and module='finance'",[ids[2]]);
await as(ids[2]);
const mid=(await db.query('select staff_member_id($1) m',[ids[2]])).rows[0].m;
const bad={key:'quotes',id:'q-denied',before:null,after:{id:'q-denied',number:'Q-DENIED',owner:ids[1],status:'Draft',amount:100}};
const good={key:'messages',id:'m-good',before:null,after:{id:'m-good',thread:'team:general-enquiries',sender:mid,text:'Hello'}};
const save=async(changes,epoch='preserved')=>(await db.query('select save_workspace_changes_isolated($1,$2) r',[JSON.stringify(changes),epoch])).rows[0].r;
let mixed=await save([bad,good]);
assert.equal(mixed.results.find(r=>r.id===bad.id).status,'blocked');assert.match(mixed.results[0].reason,/outside your access/);
assert.equal(mixed.results.find(r=>r.id===good.id).status,'saved');
// Retrying an unchanged mixed batch does not duplicate a successful message.
await save([bad,good]);
await as(null);await db.exec('reset role');let state=(await db.query('select data from workspace_states where organization_id=$1',[org])).rows[0].data;
assert(!state.quotes.some(x=>x.id==='q-denied'));assert.equal(state.messages.filter(x=>x.id==='m-good').length,1);
await as(ids[2]);
const valid={key:'quotes',id:'q-local',before:null,after:{id:'q-local',number:'Q-LOCAL',createdBy:mid,status:'Draft',amount:100}};
assert.equal((await save([valid])).results[0].status,'saved');
// A failed post-update workflow trigger is isolated too.
const forged={key:'quotes',id:'q-forged',before:null,after:{id:'q-forged',createdBy:mid,status:'Accepted',amount:100}};
const msg2={...good,id:'m2',after:{...good.after,id:'m2'}};
mixed=await save([forged,msg2]);assert.equal(mixed.results.find(x=>x.id==='q-forged').status,'blocked');assert.equal(mixed.results.find(x=>x.id==='m2').status,'saved');
// Conflict does not prevent a fresh message being saved.
const conflict={...valid,before:{...valid.after,amount:999},after:{...valid.after,amount:200}};
const msg3={...good,id:'m3',after:{...good.after,id:'m3'}};
mixed=await save([conflict,msg3]);assert.equal(mixed.results.find(x=>x.id===valid.id).status,'conflict');assert.equal(mixed.results.find(x=>x.id==='m3').status,'saved');
// Defer dependent child until parent is considered, even when child is first.
const child={...good,id:'child',after:{...good.after,id:'child',linkedQuote:'q-denied'}};
mixed=await save([child,bad]);assert.equal(mixed.results.find(x=>x.id==='child').code,'dependency');
// No record is silently escalated; restoring access allows the same draft later.
await as(null);await db.exec('reset role');await db.query("update record_access set scope='all' where user_id=$1 and module='finance'",[ids[2]]);await as(ids[2]);assert.equal((await save([bad])).results[0].status,'saved');
await assert.rejects(()=>save([msg3],'old-epoch'),/reset/);
await as(ids[5]);await assert.rejects(()=>save([good]),/active staff/);
await as(null,'anon');await assert.rejects(()=>save([good]),/permission denied/);
await as(ids[4]);await assert.rejects(()=>save([good]),/Workspace unavailable/);
await as(null);await db.exec('reset role');state=(await db.query('select data from workspace_states where organization_id=$1',[org])).rows[0].data;
assert.equal(state._resetEpoch,'preserved');assert(!state.messages.some(x=>x.id==='child'));assert(!state.quotes.some(x=>x.id==='q-forged'));assert.equal(state.quotes.find(x=>x.id==='q-local').amount,100);
console.log('PASS isolated sync: valid messages survive access and trigger failures; exact rejected IDs/reasons; idempotent retry; conflicts isolated; dependencies blocked; access recovery; reset/anon/shared/cross-org checks retained.');
await db.close();
