import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';
const root=process.env.CAGE_TEST_REPO||'sync-isolation-update/test-repo';
const production=fs.readFileSync(root+'/dist/production.js','utf8');
const code=production.slice(production.indexOf('  async function loadWorkspace()'),production.indexOf('  // Login reliability'));
const sync=fs.readFileSync(root+'/dist/reliable-sync.js','utf8');
function setup(){
 const data={_resetEpoch:'epoch',quotes:[{id:'q1',number:'Q-1',amount:100}],messages:[]};const map=new Map(),events=[],notices=[],timers=[];
 const x={structuredClone,JSON,crypto,Blob,URL,AbortSignal,CustomEvent:class{constructor(type,args){this.type=type;this.detail=args?.detail;}},console,
 profile:{id:'maya',role:'member'},sessionGeneration:1,cloudBase:structuredClone(data),pendingState:null,workspaceVersion:1,remoteSnapshot:null,syncConflicts:[],savingNow:false,applyingRemote:false,workspacePoll:null,saveTimer:null,saveChain:Promise.resolve(),
 draftKey:()=> 'cage-unsynced-'+x.profile?.id,localStorage:{getItem:k=>map.get(k)||null,setItem:(k,v)=>{if(x.failStorage&&k.endsWith(':blocked'))throw Error('Storage full');map.set(k,v)},removeItem:k=>map.delete(k)},
 navigator:{onLine:true},document:{hidden:false,createElement:()=>({click(){}})},
 setTimeout:f=>{timers.push(f);return timers.length;},clearTimeout(){},setInterval:f=>{x.poll=f;return 1},clearInterval(){},configured:()=>true,
 showBanner:(...s)=>notices.push(s),hideBanner(){},loadModuleAccess:async()=>{},applyPermissions(){},
 app:{replaceState:s=>x.rendered=structuredClone(s)},remote:{version:2,data:structuredClone(data)}};
 x.window={addEventListener(){},dispatchEvent:e=>events.push(e),setTimeout:x.setTimeout,clearTimeout:x.clearTimeout};
 x.handler=async(name,args)=>name==='get_my_workspace'?{data:structuredClone(x.remote)}:{data:{results:args.changes.map(c=>({key:c.key,id:c.id,status:'saved'}))}};
 x.client={rpc:(name,args)=>{const promise=x.handler(name,args);promise.abortSignal=()=>promise;return promise;},auth:{refreshSession:async()=>{}}};
 vm.createContext(x);vm.runInContext(sync,x);vm.runInContext(code,x);return {x,map,events,notices,data};
}
const bad={key:'quotes',id:'denied',before:null,after:{id:'denied',number:'Q-DENIED',owner:'other'}};
const good={key:'messages',id:'outgoing',before:null,after:{id:'outgoing',text:'Hello'}};
{
 const {x,map,data}=setup();x.pendingState=x.window.CAGE_SYNC.apply(data,[bad,good]);map.set(x.draftKey(),JSON.stringify({base:data,next:x.pendingState}));
 x.remote.data.messages=[good.after,{id:'incoming',text:'New message'}];
 x.handler=async(name,args)=>name==='get_my_workspace'?{data:x.remote}:{data:{results:args.changes.map(c=>({key:c.key,id:c.id,status:c.id==='denied'?'blocked':'saved',reason:'Assignment is outside your access'}))}};
 await x.flushSave();assert.equal(x.pendingState,null);assert.equal(x.blockedDrafts().length,1);assert.equal(x.blockedDrafts()[0].change.after.number,'Q-DENIED');assert(x.rendered.messages.some(m=>m.id==='incoming'));assert(!x.rendered.quotes.some(q=>q.id==='denied'));assert(!map.has(x.draftKey()));
 // Permission restored: manually retry the stored original change.
 x.handler=async(name,args)=>{if(name==='get_my_workspace')return {data:x.remote};x.remote.data.quotes.push(bad.after);return {data:{results:args.changes.map(c=>({key:c.key,id:c.id,status:'saved'}))}};};
 await x.retryBlockedDraft(x.blockedDrafts()[0].id);assert.equal(x.blockedDrafts().length,0);assert.equal(x.pendingState,null);
}
{
 const {x,data}=setup();const dirty={key:'quotes',id:'q1',before:data.quotes[0],after:{...data.quotes[0],amount:200}};
 x.pendingState=x.window.CAGE_SYNC.apply(data,[dirty]);x.remote.data.quotes[0].amount=300;x.remote.data.messages=[{id:'incoming'}];
 x.receiveWorkspace(x.remote);assert.equal(x.rendered.quotes[0].amount,200);assert.equal(x.cloudBase.quotes[0].amount,100);assert.equal(x.rendered.messages[0].id,'incoming');
 // Poll actually runs despite a dirty record; network save failure keeps draft.
 let polls=0;x.handler=async(name)=>{if(name==='get_my_workspace'){polls++;return {data:x.remote};}throw Error('Offline');};x.navigator.onLine=false;x.subscribe();await x.poll();assert.equal(polls,1);assert(x.pendingState);
}
{
 const {x,map,data}=setup();x.pendingState=x.window.CAGE_SYNC.apply(data,[bad]);map.set(x.draftKey(),JSON.stringify({base:data,next:x.pendingState}));const original=map.get(x.draftKey());x.failStorage=true;
 x.handler=async()=>({data:{results:[{key:bad.key,id:bad.id,status:'blocked',reason:'Assignment is outside your access'}]}});
 await x.flushSave();assert(x.pendingState);assert.equal(map.get(x.draftKey()),original);assert(!map.has(x.draftKey()+':blocked'));
}
{
 const {x,data}=setup();const good={key:"quotes",id:"q-new",before:null,after:{id:"q-new",text:"Hello"}};let release;x.pendingState=x.window.CAGE_SYNC.apply(data,[bad,good]);x.handler=(name)=> name==='get_my_workspace'?Promise.resolve({data:x.remote}):new Promise(r=>release=r);
 const saving=x.flushSave();x.scheduleSave(x.window.CAGE_SYNC.apply(x.pendingState,[{...good,after:{...good.after,text:'Newer edit'}},{...bad,after:{...bad.after,number:'Q-NEWER'}}]));
 x.remote.data.quotes.push(good.after);release({data:{results:[{key:bad.key,id:bad.id,status:'blocked',reason:'Assignment is outside your access'},{key:good.key,id:good.id,status:'saved'}]}});await saving;
 assert.equal(x.blockedDrafts()[0].change.after.number,'Q-NEWER');assert.equal(x.pendingState.quotes.find(q=>q.id==="q-new").text,'Newer edit');assert.equal(x.cloudBase.quotes.find(q=>q.id==="q-new").text,'Hello');
}
{
 const {x,data,map}=setup();const old={base:data,next:x.window.CAGE_SYNC.apply(data,[bad])};map.set(x.draftKey(),JSON.stringify(old));x.receiveWorkspace(x.remote);assert.equal(map.get(x.draftKey()),JSON.stringify(old));
 x.handler=async(name,args)=>name==='get_my_workspace'?{data:x.remote}:{data:{results:args.changes.map(c=>({key:c.key,id:c.id,status:'blocked',reason:'Assignment is outside your access'}))}};
 await x.restoreDraft();assert.equal(x.pendingState,null);assert.equal(x.blockedDrafts().length,1);
 // Another user's recovery list is never shown or replayed.
 x.profile={id:'ian',role:'member'};assert.equal(x.blockedDrafts().length,0);
}
{
 const {x,data,map}=setup();x.pendingState=x.window.CAGE_SYNC.apply(data,[bad]);let release;x.handler=()=>new Promise(r=>release=r);const saving=x.flushSave();x.profile={id:'ian',role:'member'};x.sessionGeneration++;
 release({data:{results:[{key:bad.key,id:bad.id,status:'blocked',reason:'Denied'}]}});await saving;assert(!map.has('cage-unsynced-ian:blocked'));assert(!map.has('cage-unsynced-maya:blocked'));
}
{
 const {x,data,map}=setup();x.pendingState=x.window.CAGE_SYNC.apply(data,[bad]);x.remote.data._resetEpoch='new-epoch';x.receiveWorkspace(x.remote);assert.equal(x.pendingState,null);assert([...map.keys()].some(k=>k.includes(':before-reset:')));assert(!x.rendered.quotes.some(q=>q.id==='denied'));
}
console.log('PASS client: blocked recovery, incoming updates while dirty, unrelated successful save, manual retry, storage-failure preservation, in-flight edits, legacy draft recovery, account-switch isolation, reset quarantine.');
