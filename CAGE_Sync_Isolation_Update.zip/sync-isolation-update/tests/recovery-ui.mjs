import fs from 'node:fs';import assert from 'node:assert/strict';import {chromium} from 'playwright';
const repo=process.env.CAGE_TEST_REPO||'sync-isolation-update/test-repo';
const b=await chromium.launch({executablePath:process.env.CAGE_TEST_BROWSER||'/tmp/cage-chromium',args:['--no-sandbox']});
try{
 const p=await b.newPage({viewport:{width:1200,height:900}});const errors=[];p.on('pageerror',e=>errors.push(e.message));await p.setContent('<body><main><h1>CAGE Operations Hub</h1><p>Work chat remains available</p></main></body>');
 for(const name of ['styles.css','workflows.css'])await p.addStyleTag({content:fs.readFileSync(repo+'/dist/'+name,'utf8')});
 await p.evaluate(()=>{
 window.entries=[{id:'recovery1',kind:'blocked',reason:'Assignment is outside your access <script>bad</script>',change:{key:'quotes',id:'q-denied',after:{number:'Q-26001'}}}];window.downloads=0;window.retries=0;
 window.CAGE_BACKEND={syncState:()=>({pending:false,blocked:entries.length,localSettings:0}),reviewSync:()=>[],blockedDrafts:()=>entries,recordLabel:c=>'Quote: '+c.after.number,retryBlockedDraft:async()=>{retries++;entries=[];},downloadBlockedDrafts:()=>downloads++};
 window.$=id=>document.getElementById(id);window.api=()=>CAGE_BACKEND;window.esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 });
 const src=fs.readFileSync(repo+'/dist/workflows.js','utf8');const modal=src.slice(src.indexOf('function modal('),src.indexOf("document.addEventListener('click'"));await p.addScriptTag({content:modal+src.slice(src.indexOf("const sync=document.createElement('button')"),src.indexOf("window.addEventListener('cage:conflicts'"))+"syncStatus();"});
 await p.locator('.ops-sync').click();assert.match(await p.locator('#ops-unsynced').innerText(),/Q-26001/);assert.match(await p.locator('#ops-unsynced').innerText(),/Contact your administrator/);assert.equal(await p.locator('#ops-unsynced script').count(),0);
 await p.screenshot({path:'sync-isolation-update/tests/recovery-desktop.png'});
 await p.setViewportSize({width:390,height:844});await p.addStyleTag({content:fs.readFileSync(repo+'/dist/mobile.css','utf8')});await p.screenshot({path:'sync-isolation-update/tests/recovery-mobile.png'});
 await p.locator('#ops-download-blocked').click();assert.equal(await p.evaluate(()=>downloads),1);
 await p.locator('[data-retry-blocked]').click();assert.equal(await p.evaluate(()=>retries),1);assert.equal(await p.locator('#ops-unsynced').evaluate(d=>d.open),false);assert.equal(await p.locator('.ops-sync').innerText(),'All changes synced');assert.deepEqual(errors,[]);
 console.log('PASS recovery UI: exact record/reason, admin guidance, escaped text, export, individual retry, resolved count and dialog close.');
}finally{await b.close();}
