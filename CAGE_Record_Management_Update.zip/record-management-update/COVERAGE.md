# Records available in Manage records

Workspace records:

Requests, Projects, Tasks, Contacts, CRM opportunities, Legacy calendar events, Invoices, Quotations, Expenses, Task board lists, Leave requests, Knowledge, Work chat messages, Chat groups, Missions, Assets, Compliance, Approvals, Commercial records, Opportunity matches.

Database records:

Custom categories, Task plans, Daily priorities, Courses, Cohorts, Learners, Training sessions, Attendance, Assessments, Certificates, Practical logs, Learner documents, Training materials, Cohort messages, Application calls, Applications, Application files, STEM applications, Job openings, Job applications, Interviews, Employee documents, Equipment kits, Equipment reservations, Invoice payments, Personal reminders, Calendar events, Notices, Notice attachments, Uploaded files.

Nested items:

Project milestones and task subtasks that have their own record IDs.

Permissions are checked against the current module, record visibility and existing owner/editor rules. Access to a module alone does not override private conversation or personal-record ownership. Dependent business records must be removed or reassigned first. Stored files shared by other records are retained until those references are removed.
