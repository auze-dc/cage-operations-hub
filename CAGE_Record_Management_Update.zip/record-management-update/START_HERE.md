# CAGE — Record deletion and organised finance lists

Install this after the Project Reliability Update. This package adds deletion controls; it does not delete any live record when installed. runtime-config.js and secrets are not included.

## What staff will see

- A Manage records button in the top bar: choose a record type, search, then Delete.
- Delete beside Open for registered project uploads, and beside the existing actions for quotations/invoices.
- Confirmation with the name and unique reference, which helps distinguish duplicate uploads.
- Server checks for current create/edit permission and access to that particular record. Existing ownership restrictions remain; staff can delete their own private messages.
- If another business record depends on the item, a message identifies the linked record type. Remove or reassign the linked records first. Deletion does not silently cascade through other work. Generated reminders/delivery jobs for a deleted parent are archived in the audit log and removed.
- An audit snapshot remains. A deleted record cannot be recreated by an older browser draft.
- Finance has search, client, issue-year and status filters, newest-first order, and 20 documents per page. The existing open/overdue/paid invoice filter still applies too.
- The large client-response summary is removed. Use Client response / Delivery history for the individual document to read the response.

## 1. Get the ZIP into Codespaces

Download CAGE_Record_Management_Update.zip and drag it into the Codespaces Explorer under cage-operations-hub.

If you instead uploaded it on GitHub's main branch, retrieve just the ZIP from your existing Codespaces terminal:

```bash
cd /workspaces/cage-operations-hub
git fetch origin
git show origin/main:CAGE_Record_Management_Update.zip > CAGE_Record_Management_Update.zip
```

Then install on a new branch:

```bash
git switch -c record-management-update
unzip CAGE_Record_Management_Update.zip
python3 record-management-update/install.py
npm run check
node --check dist/record-management.js
```

The installer checks every affected file before writing and creates a backup outside the repository. If it prints STOP, share the exact output. Do not force replacement; that means your current version differs from the tested baseline.

## 2. Run the database migration once

In Supabase SQL Editor for the existing CAGE project, run the entire file:

supabase/migrations/20260925140000_record_management.sql

The SQL creates permission-checked deletion functions, audit receipts, dependency guards and deletion policies. It preserves existing read scopes. It does not delete existing business records. It runs in a transaction. If any error appears, stop and share that error. Do not publish the frontend until this succeeds.

## 3. Deploy the deletion function

```bash
npx supabase functions deploy delete-record --project-ref lrvcpiobxqtmcntwhaat --use-api --no-verify-jwt
```

The function explicitly verifies the caller with Supabase Auth before any deletion. User credentials are used for the database operation; the service role is used only to clean up files named in a server-created deletion receipt. The --use-api option avoids the local bundling/network problem encountered previously. No new secrets are required beyond the existing Supabase environment.

## 4. Publish the frontend

```bash
python3 record-management-update/stage.py
git diff --cached --stat
git commit -m "Add record deletion and organised finance lists"
git push -u origin record-management-update
```

Open a pull request to main, review and merge, then wait for the Cloudflare Pages deployment to succeed. Reload the Hub after publication. Do not clear browser data or staff drafts.

## 5. Test before removing real records

1. Create a disposable draft quotation. Cancel Delete once and confirm it remains; then confirm Delete. Refresh and confirm it stays removed.
2. Upload a disposable project file. Delete that specific file and refresh the project. For repeated filenames, Open the file first and check the unique reference in the confirmation.
3. Create and delete an empty test cohort. A cohort with learners, sessions or other dependent records should identify those dependencies and remain intact.
4. Repeat with an ordinary authorised staff account. A view-only user must not be able to delete.
5. Test client/year/status/search filters and Previous/Next in Finance. Open a document's response history.

## Files and cleanup

Database deletion and physical file removal use separate services. If cleanup fails, the record remains deleted and the UI says cleanup needs a retry. Open Manage records → File cleanup and retry. A file used by another database or workspace record is retained; remove that reference before retrying. Existing downloaded copies and previously issued short-lived download links cannot be recalled.

The audit log retains the deleted record's metadata/snapshot, not a backup of the removed file bytes. There is no automatic Undo button. Download any file you want to keep before deleting it.

Some modules cache their lists: reopen the module or refresh if a deleted record is still visible there. Manage records always fetches current database records when opened/refreshed. Existing unsaved forms are not cleared.

## Scope

See COVERAGE.md for the record types. Staff accounts, access rules, runtime settings, system jobs and audit history are not ordinary business records and are excluded from this deletion screen. Core built-in categories remain protected; custom shared categories can be deleted when no saved record uses them.

## Rollback

Before staff use deletion, restore affected frontend files from the installer backup through a reviewed deployment if needed. Leave audit receipts intact. After staff have deleted records, rolling back frontend code does not restore those records or file bytes. Use your data backups and the retained audit snapshots for any reviewed recovery.
