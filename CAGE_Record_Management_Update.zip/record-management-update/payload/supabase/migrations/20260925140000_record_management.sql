begin;
create table public.record_deletion_log (
 id uuid primary key default gen_random_uuid(), organization_id uuid not null, actor_id uuid not null,
 kind text not null, record_id text not null, snapshot jsonb not null, deleted_at timestamptz not null default now(),
 storage_bucket text, storage_path text, storage_removed_at timestamptz
);
alter table public.record_deletion_log enable row level security;
grant select on public.record_deletion_log to authenticated;
grant all on public.record_deletion_log to service_role;
create policy deletion_owner on public.record_deletion_log for select to authenticated using(organization_id=current_organization_id() and actor_id=auth.uid());
create function public.manageable_record_tables() returns text[] language sql immutable as $$ select array['hub_work_categories','task_plans','daily_priorities','training_courses','training_cohorts','learners','training_sessions','learner_attendance','training_assessments','training_certificates','training_practical_logs','training_documents','training_materials','cohort_messages','academy_intakes','academy_applications','academy_application_files','stem_applications','job_openings','job_applications','interviews','employee_documents','equipment_kits','equipment_reservations','invoice_payments','personal_reminders','hub_events','hub_notices','hub_notice_files','attachments']::text[] $$;

create policy category_record_read on hub_work_categories for select to authenticated using(organization_id=current_organization_id() and exists(select 1 from profiles where id=auth.uid() and active and role<>'shared'));

-- Derive delete access from existing authenticated create/update AND read scopes.
-- Restrictive policies remain restrictive. No service-role permissions are copied.
do $body$
declare tab text; r record; expr text; select_allow text; select_limit text; write_allow text; write_limit text; mod text;
begin
 foreach tab in array manageable_record_tables() loop
 select_allow='false';select_limit='true';write_allow='false';write_limit='true';
 for r in select * from pg_policies where schemaname='public' and tablename=tab and (roles && array['authenticated','public']::name[]) loop
  if r.cmd in ('SELECT','ALL') then
   expr=coalesce(r.qual,'true');
   if r.permissive='PERMISSIVE' then select_allow=select_allow||' OR ('||expr||')';else select_limit=select_limit||' AND ('||expr||')';end if;
  end if;
  if r.cmd='UPDATE' and r.permissive='PERMISSIVE' then write_allow=write_allow||' OR ('||coalesce(r.qual,'true')||')';end if;
  if r.cmd in ('INSERT','ALL') then
   expr=case when r.cmd='ALL' and r.permissive='RESTRICTIVE' then coalesce(r.qual,'true') else coalesce(r.with_check,r.qual,'true') end;
   if r.permissive='PERMISSIVE' then write_allow=write_allow||' OR ('||expr||')';else write_limit=write_limit||' AND ('||expr||')';end if;
  end if;
 end loop;
 mod=case tab
 when 'hub_work_categories' then 'categories'
 when 'task_plans' then 'tasks'
 when 'daily_priorities' then 'tasks'
 when 'training_courses' then 'training'
 when 'training_cohorts' then 'training'
 when 'learners' then 'training'
 when 'training_sessions' then 'training'
 when 'learner_attendance' then 'training'
 when 'training_assessments' then 'training'
 when 'training_certificates' then 'training'
 when 'training_practical_logs' then 'training'
 when 'training_documents' then 'training'
 when 'training_materials' then 'training'
 when 'cohort_messages' then 'training'
 when 'academy_intakes' then 'training'
 when 'academy_applications' then 'training'
 when 'academy_application_files' then 'training'
 when 'stem_applications' then 'training'
 when 'job_openings' then 'hr'
 when 'job_applications' then 'hr'
 when 'interviews' then 'hr'
 when 'employee_documents' then 'hr'
 when 'equipment_kits' then 'assets'
 when 'equipment_reservations' then 'assets'
 when 'invoice_payments' then 'finance'
 when 'personal_reminders' then 'mywork'
 when 'hub_events' then 'calendar'
 when 'hub_notices' then 'notices'
 when 'hub_notice_files' then 'notices'
 when 'attachments' then 'evidence'
 end;
 -- RPC-created records have equivalent explicit edit scopes.
 if tab='hub_work_categories' then write_allow='created_by=auth.uid() OR is_admin()';
 elsif tab in ('academy_intakes','academy_applications','academy_application_files','stem_applications') then
  write_allow='organization_id=current_organization_id() AND can_manage_stem()';
 elsif tab='hub_events' then write_allow='hub_event_edit(id)';
 elsif tab='hub_notices' then write_allow='hub_notice_edit(id)';
 elsif tab='hub_notice_files' then write_allow='hub_notice_edit(notice_id)';
 elsif tab='invoice_payments' then write_allow='organization_id=current_organization_id() AND can_work_record(''invoices'',invoice_id)';
 elsif tab='equipment_reservations' then write_allow='organization_id=current_organization_id() AND (user_id=auth.uid() OR can_work_record(''projects'',project_id))';
 elsif tab='attachments' then
  write_allow='organization_id=current_organization_id() AND linked_file_visible(record_type,record_id)';
  mod=null;
 end if;
 write_allow=write_allow||' OR (is_admin())';
 expr='('||select_allow||') AND ('||select_limit||') AND ('||write_allow||') AND ('||write_limit||')';
 if tab='hub_work_categories' then null;
 elsif tab='personal_reminders' then expr=expr||' AND user_id=auth.uid()';
 elsif tab='attachments' then expr=expr||' AND module_level(case record_type when ''project'' then ''projects'' when ''chat'' then ''chat'' when ''expense'' then ''finance'' when ''hr'' then ''hr'' when ''employees'' then ''hr'' when ''recruitment'' then ''hr'' else ''evidence'' end)=''edit''';
 else expr=expr||format(' AND module_level(%L)=''edit''',mod);end if;
 execute format('create policy record_delete_allow on public.%I for delete to authenticated using (%s)',tab,expr);
 execute format('create policy record_delete_guard on public.%I as restrictive for delete to authenticated using (%s)',tab,expr);
 execute format('grant select, delete on public.%I to authenticated',tab);
 end loop;
end $body$;

create function public.record_delete_before() returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
declare oldj jsonb=to_jsonb(old); ref record; linked boolean; predicate text; request uuid; bucket text; path text; org uuid;
begin
 org=coalesce((oldj->>'organization_id')::uuid,current_organization_id());
 -- Refuse cascading deletion of other business records, including invisible children.
 for ref in select c.conrelid::regclass as rel,c.conkey,c.confkey,c.confrelid,c.conrelid from pg_constraint c where c.contype='f' and c.confrelid=tg_relid loop
  select string_agg(format('t.%I::text = $1->>%L',a.attname,b.attname),' AND ') into predicate from unnest(ref.conkey,ref.confkey) k(a,b) join pg_attribute a on a.attrelid=ref.conrelid and a.attnum=k.a join pg_attribute b on b.attrelid=ref.confrelid and b.attnum=k.b;
  if ref.rel::text in ('hub_notice_reads','hub_event_guests','hub_event_exceptions','chat_receipts','cohort_deliveries','academy_enrolment_deliveries','enrollment_email_outbox','academy_payment_reminders','hub_delivery_jobs') then
   execute format('insert into audit_log(organization_id,actor_id,action,entity_type,entity_id,old_data) select $2,auth.uid(),''delete_parent_metadata'',%L,coalesce(to_jsonb(t)->>''id'',$1->>''id''),to_jsonb(t) from %s t where %s',ref.rel::text,ref.rel,predicate) using oldj,org;
   execute format('delete from %s t where %s',ref.rel,predicate) using oldj;
   continue;
  end if;
  execute format('select exists(select 1 from %s t where %s)',ref.rel,predicate) into linked using oldj;
  if linked then raise exception 'Remove or reassign linked records in % before deleting this record.',ref.rel;end if;
 end loop;
 request=coalesce(nullif(current_setting('cage.deletion_request',true),'')::uuid,gen_random_uuid());
 if tg_table_name='attachments' then bucket='cage-files';path=oldj->>'storage_path';
 elsif tg_table_name='employee_documents' then bucket='cage-files';path=oldj->>'storage_path';
 elsif tg_table_name='academy_application_files' then bucket='academy-applications';path=oldj->>'path';
 elsif tg_table_name='hub_notice_files' then bucket='hub-notices';path=oldj->>'path';
 end if;
 if tg_table_name='hub_work_categories' and exists(select 1 from workspace_states w,jsonb_array_elements(coalesce(w.data->case oldj->>'module' when 'crm' then 'deals' else oldj->>'module' end,'[]')) r where w.organization_id=org and (r->>'category'=oldj->>'name' or r->>'type'=oldj->>'name')) then raise exception 'This category is in use. Reassign its records first.';end if;
 -- Storage cleanup is processed through the Storage API, never by deleting storage.objects.
 insert into record_deletion_log(id,organization_id,actor_id,kind,record_id,snapshot,storage_bucket,storage_path)
 values(request,org,auth.uid(),tg_table_name,coalesce(oldj->>'id',(oldj->>'session_id')||':'||(oldj->>'learner_id'),(oldj->>'user_id')||':'||coalesce(oldj->>'task_id',oldj->>'day')),oldj,bucket,path);
 if tg_table_name='attachments' and oldj->>'record_type'='project' then
  update workspace_states w set data=jsonb_set(w.data,'{projects}',coalesce((select jsonb_agg(case when p->>'id'=oldj->>'record_id' then jsonb_set(p,'{files}',coalesce((select jsonb_agg(f) from jsonb_array_elements(coalesce(p->'files','[]')) f where f->>'path' is distinct from path),'[]')) else p end) from jsonb_array_elements(coalesce(w.data->'projects','[]')) p),'[]')),version=version+1,updated_by=auth.uid() where organization_id=org;
 end if;
 if tg_table_name='invoice_payments' then
  update workspace_states w set data=jsonb_set(w.data,'{invoices}',coalesce((select jsonb_agg(case when i->>'id'=oldj->>'invoice_id' then i||jsonb_build_object('paidAmount',greatest(0,coalesce((i->>'paidAmount')::numeric,0)-(oldj->>'amount')::numeric),'status',case when greatest(0,coalesce((i->>'paidAmount')::numeric,0)-(oldj->>'amount')::numeric)>=coalesce((i->>'amount')::numeric,0) then 'Paid' else 'Sent' end) else i end) from jsonb_array_elements(coalesce(w.data->'invoices','[]')) i),'[]')),version=version+1,updated_by=auth.uid() where organization_id=org;
 end if;
 return old;
end $$;
revoke all on function public.record_delete_before() from public;
do $$declare t text;begin foreach t in array manageable_record_tables() loop execute format('create trigger record_delete_audit before delete on public.%I for each row execute function record_delete_before()',t);end loop;end $$;

create function public.delete_database_record(kind text, rid text, expected jsonb) returns uuid language plpgsql security invoker set search_path=public,pg_temp as $$
declare oldj jsonb; request uuid=gen_random_uuid();
begin
 if auth.uid() is null or not(kind=any(manageable_record_tables())) then raise exception 'Unknown record type';end if;
 perform set_config('cage.deletion_request',request::text,true);
 execute format('delete from public.%I t where (to_jsonb(t)->>''id'' is null or to_jsonb(t)->>''id''=$1) and to_jsonb(t)=$2 returning to_jsonb(t)',kind) into oldj using rid,expected;
 if oldj is null then raise exception 'Record changed or delete access denied. Refresh and try again.';end if;
 return request;
end $$;
revoke all on function public.delete_database_record(text,text,jsonb) from public;
grant execute on function public.delete_database_record(text,text,jsonb) to authenticated;

create function public.delete_workspace_record(kind text,rid text,expected jsonb) returns uuid language plpgsql security definer set search_path=public,pg_temp as $$
declare w workspace_states%rowtype; item jsonb; other jsonb; pair record; field record; request uuid=gen_random_uuid();
begin
 if auth.uid() is null or kind not in ('requests','projects','tasks','contacts','deals','events','invoices','quotes','expenses','boardLists','leaveRequests','knowledge','messages','chatGroups','missions','assets','compliance','approvals','commercialRecords','opportunityMatches') then raise exception 'Unknown record type';end if;
 if module_level(state_module(kind))<>'edit' then raise exception 'Create/edit access is required';end if;
 select * into w from workspace_states where organization_id=current_organization_id() for update;
 select r into item from jsonb_array_elements(coalesce(w.data->kind,'[]')) r where r->>'id'=rid;
 if item is null or not record_visible(kind,item,w.data) then raise exception 'Record is outside your access';end if;
 if kind='messages' and item->>'sender' is distinct from staff_member_id(auth.uid()) then raise exception 'Only the sender can delete a chat message';end if;
 if item is distinct from expected then raise exception 'Record changed. Refresh and review it before deleting.';end if;
 -- Exact record identifiers, including nested links and arrays.
 for pair in select key,value from jsonb_each(w.data) where jsonb_typeof(value)='array' loop
 for other in select value from jsonb_array_elements(pair.value) where jsonb_typeof(value)='object' loop
  if pair.key=kind and other->>'id'=rid then continue;end if;
  if jsonb_path_exists(other,'$.** ? (@ == $ref)',jsonb_build_object('ref',rid)) or other->>'thread' in ('project:'||rid,'deal:'||rid,'commercial:'||rid) then raise exception 'Remove or reassign linked % records first.',pair.key;end if;
 end loop;end loop;
 if exists(select 1 from attachments where organization_id=w.organization_id and record_id=rid) then raise exception 'Delete attached files first using Manage records.';end if;
 if kind='invoices' and (exists(select 1 from invoice_payments where invoice_id=rid and organization_id=w.organization_id) or exists(select 1 from learners where invoice_id=rid and organization_id=w.organization_id)) then raise exception 'Remove or reassign linked payments and learners first.';end if;
 if kind='tasks' and (exists(select 1 from task_plans t join profiles p on p.id=t.user_id where p.organization_id=w.organization_id and t.task_id=rid) or exists(select 1 from daily_priorities t join profiles p on p.id=t.user_id where p.organization_id=w.organization_id and rid=any(t.task_ids))) then raise exception 'Remove linked task plans and daily priorities first.';end if;
 if kind='assets' and (exists(select 1 from equipment_reservations where organization_id=w.organization_id and rid=any(asset_ids)) or exists(select 1 from equipment_kits where organization_id=w.organization_id and rid=any(asset_ids))) then raise exception 'Remove this asset from kits and reservations first.';end if;
 if kind='projects' and (exists(select 1 from training_cohorts where project_id=rid and organization_id=w.organization_id) or exists(select 1 from equipment_reservations where project_id=rid and organization_id=w.organization_id)) then raise exception 'Remove or reassign linked cohorts and equipment reservations first.';end if;
 insert into record_deletion_log(id,organization_id,actor_id,kind,record_id,snapshot) values(request,w.organization_id,auth.uid(),kind,rid,item);
 update workspace_states set data=jsonb_set(w.data,array[kind],coalesce((select jsonb_agg(r) from jsonb_array_elements(w.data->kind) r where r->>'id'<>rid),'[]')),version=version+1,updated_by=auth.uid() where organization_id=w.organization_id;
 return request;
end $$;
revoke all on function public.delete_workspace_record(text,text,jsonb) from public;
grant execute on function public.delete_workspace_record(text,text,jsonb) to authenticated;
create function public.prevent_deleted_record_return() returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
declare d record;begin
 for d in select kind,record_id,snapshot from record_deletion_log where organization_id=new.organization_id loop
 if d.kind in ('projectMilestones','taskSubtasks') and exists(select 1 from jsonb_array_elements(coalesce(new.data->case d.kind when 'projectMilestones' then 'projects' else 'tasks' end,'[]')) p,jsonb_array_elements(coalesce(p->case d.kind when 'projectMilestones' then 'milestones' else 'subtasks' end,'[]')) c where p->>'id'=d.snapshot->>'parentId' and c->>'id'=d.snapshot->'child'->>'id') then raise exception 'This item was deleted. Refresh before saving the old form.';end if;
 if jsonb_typeof(new.data->d.kind)='array' and exists(select 1 from jsonb_array_elements(new.data->d.kind) r where r->>'id'=d.record_id) and not exists(select 1 from jsonb_array_elements(coalesce(old.data->d.kind,'[]')) r where r->>'id'=d.record_id) then raise exception 'This record was deleted. It cannot be restored by an older browser draft.';end if;
 end loop;return new;end $$;
revoke all on function public.prevent_deleted_record_return() from public;
create trigger prevent_deleted_record_return before update on workspace_states for each row execute function prevent_deleted_record_return();

-- Allow deletion of the sender's own private message only through the audited RPC.
do $patch$declare definition text;begin
 select pg_get_functiondef('public.validate_private_staff_chat()'::regprocedure) into definition;
 if position('raise exception ''Private chat messages cannot be deleted''' in definition)=0 then raise exception 'Private chat validator differs; review migration before installing';end if;
 definition=replace(definition,'raise exception ''Private chat messages cannot be deleted'';',
 'if not exists(select 1 from public.record_deletion_log d where d.organization_id=new.organization_id and d.actor_id=auth.uid() and d.kind=''messages'' and d.record_id=old_msg->>''id'' and old_msg->>''sender''=mid) then raise exception ''Only your own messages can be deleted through Manage records'';end if;');
 execute definition;
end $patch$;

create function public.prevent_deleted_database_record_return() returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
begin
 if exists(select 1 from record_deletion_log where kind=tg_table_name and record_id=to_jsonb(new)->>'id') then raise exception 'This record was deleted. Create a new record instead of resaving the old form.';end if;
 return new;end $$;
revoke all on function public.prevent_deleted_database_record_return() from public;
do $$declare t text;begin foreach t in array manageable_record_tables() loop
 if exists(select 1 from pg_attribute where attrelid=('public.'||t)::regclass and attname='id' and not attisdropped) then execute format('create trigger prevent_deleted_database_record_return before insert on public.%I for each row execute function prevent_deleted_database_record_return()',t);end if;
 end loop;end $$;
create function public.delete_nested_record(kind text,rid text,expected jsonb) returns uuid language plpgsql security definer set search_path=public,pg_temp as $$
declare w workspace_states%rowtype; parent jsonb; child jsonb; parent_kind text; child_key text; request uuid=gen_random_uuid(); parent_id text=expected->>'parentId';
begin
 if kind='projectMilestones' then parent_kind='projects';child_key='milestones';elsif kind='taskSubtasks' then parent_kind='tasks';child_key='subtasks';else raise exception 'Unknown record type';end if;
 if auth.uid() is null or module_level(state_module(parent_kind))<>'edit' then raise exception 'Create/edit access required';end if;
 select * into w from workspace_states where organization_id=current_organization_id() for update;
 select r into parent from jsonb_array_elements(coalesce(w.data->parent_kind,'[]')) r where r->>'id'=parent_id;
 if parent is null or not record_visible(parent_kind,parent,w.data) then raise exception 'Record outside your access';end if;
 select r into child from jsonb_array_elements(coalesce(parent->child_key,'[]')) r where r->>'id'=expected->'child'->>'id';
 if child is null or child is distinct from expected->'child' or rid is distinct from parent_id||'/'||(child->>'id') then raise exception 'Record changed. Refresh and try again.';end if;
 insert into record_deletion_log(id,organization_id,actor_id,kind,record_id,snapshot) values(request,w.organization_id,auth.uid(),kind,rid,expected);
 parent=jsonb_set(parent,array[child_key],coalesce((select jsonb_agg(r) from jsonb_array_elements(parent->child_key) r where r->>'id'<>child->>'id'),'[]'));
 update workspace_states set data=jsonb_set(data,array[parent_kind],(select jsonb_agg(case when r->>'id'=parent_id then parent else r end) from jsonb_array_elements(data->parent_kind) r)),version=version+1,updated_by=auth.uid() where organization_id=w.organization_id;
 return request;
end $$;
revoke all on function public.delete_nested_record(text,text,jsonb) from public;
grant execute on function public.delete_nested_record(text,text,jsonb) to authenticated;

notify pgrst,'reload schema';
commit;
