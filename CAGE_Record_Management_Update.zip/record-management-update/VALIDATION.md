# Validation — 25 September 2026

Passed locally:

- Existing production checks and isolated-sync regression suite: rejected draft recovery, successful independent saves, edits during saves, browser-storage failures, legacy draft recovery, account isolation and reset handling.
- Derived notice notification jobs are archived and removed when their parent is deleted, avoiding blocked deletion from system-generated foreign keys.
- Local PostgreSQL migration installation with the existing schema, categories and project file policies.
- Deleting empty cohorts/courses; refusing linked-course deletion; project attachment deletion and persistent file-cleanup receipt; linked-invoice guard; view-only and cross-organisation denial; private-message deletion by its sender; nested milestone deletion; deleted workspace and database IDs cannot be reinserted by stale drafts.
- Browser controls: 20-row pagination, client/year/search filtering, record search, cancel preserves the record, confirmation invokes deletion, and project-file delete buttons.
- Full frontend page integration: new scripts load without JavaScript errors and the client-response summary is absent.
- Deletion function handler with mocked services: authentication rejection, receipt access rejection, path validation, shared database/workspace references, storage failure and retry.
- Installer: baseline compatibility, repeated installation and refusal to overwrite independently changed files.

Limits:

These checks used the supplied source baseline, a local PostgreSQL engine and mocked service responses. They do not claim a live Supabase/Cloudflare deployment or a test of every possible historical record shape. A live disposable-file delete and ordinary-staff permission check are required after deployment. Linked records are deliberately not removed automatically. File cleanup uses Supabase Storage APIs and is retryable; retained audit snapshots are not file-byte backups.
