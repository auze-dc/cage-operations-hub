# CAGE project reliability update

This update targets disappearing project chat, project document uploads, and unexpected returns to login after temporary profile timeouts. It preserves the previous quotation/invoice editing and PDF stamp update.

## 1. Install in Codespaces

Upload CAGE_Project_Reliability_Update.zip into /workspaces/cage-operations-hub, then run:

```bash
cd /workspaces/cage-operations-hub
git switch -c project-sync-reliability
unzip CAGE_Project_Reliability_Update.zip
python3 reliability-update/install.py
npm run check
```

The installer checks every original file before changing anything. If it says STOP, share that output: your source differs from the tested baseline. Do not force replacement. Existing changes and credentials must be preserved. The installer backs up the affected files outside the repository. It does not run SQL or deploy anything.

## 2. Apply the one database migration

In the Supabase SQL Editor for your existing CAGE project (lrvcpiobxqtmcntwhaat), open and run the entire contents of:

supabase/migrations/20260925110000_project_file_access.sql

This changes project uploads to use Projects permission and enforces project assignment and organisation boundaries. Other file categories retain their policies. The SQL runs in a transaction and stops if the expected policies differ. If it errors, share the exact error before proceeding. Run once; a second run deliberately stops when the mapping already exists.

Do not deploy the frontend if this migration fails.

## 3. Publish the frontend through your existing GitHub / Cloudflare workflow

```bash
python3 reliability-update/stage.py
git diff --cached --stat
git commit -m "Fix project uploads, message save status and session retries"
git push -u origin project-sync-reliability
```

Open a pull request to main, review and merge it, then wait for your existing Cloudflare Pages deployment to succeed. This package needs no Edge Function deployment. runtime-config.js and credentials are not included or staged by the helper.

## 4. Verify in the live workspace

After publication, reload the page. Do not clear browser storage or reset the workspace.

1. Send a distinctive message in a project. It should move from Waiting to sync to a server-confirmed status. Refresh and reopen that same thread; the message should remain.
2. Upload a PDF under a project’s Documents tab. Refresh, reopen the project, and open the PDF. Try a regular non-admin project editor as well.
3. Confirm a viewer cannot upload and an unrelated staff member cannot access the project’s files.
4. If a background connection check times out, the existing workspace should remain open with a retry notice. Genuine logout or inactive-account status still closes access.

If a message was rejected previously, use the existing sync recovery / Needs attention panel. It now displays the message text so it can be recovered. Pending and blocked drafts are preserved. Previously lost messages cannot be reconstructed if neither the server nor the browser retained them.

If a problem remains, capture the project name, approximate local time, exact error, and failed browser Network request status/response (without tokens or cookies). That will let us distinguish a live policy/configuration failure from a client issue.

## Rollback

The installer prints the backup directory. Restore the affected frontend files from that backup through your normal reviewed deployment process if needed. The corrected project permission mapping can remain while the frontend is rolled back; do not remove access policies as a troubleshooting shortcut.
