# Findings and verification — 25 September 2026

## Confirmed in the available source

- A failed background staff-profile check led to the login gate even when an existing session had been verified. Temporary connection failures now retain that session and retry. Initial sign-in still requires verification; inactive accounts and permanent access errors fail closed.
- Background session refresh incremented the same generation used to discard stale saves. Same-user refresh now preserves the generation; account changes and logout still invalidate old work.
- Chat rendered locally before server acknowledgement. It now labels pending, rejected and unconfirmed records, starts the save immediately, uses unique IDs, and retains composer text when local queuing fails. Recovery cards display preserved message text.
- Historical project messages could be omitted when the project gained a request/deal thread. Visible project/request relationships now resolve those older project messages without rewriting stored history.
- Project storage and attachment checks fell through to Evidence permission. The migration maps them to Projects and adds project-specific scope restrictions.
- An upload could mutate a project object that a concurrent workspace refresh had replaced. Project documents now load from the persisted attachments registry and merge existing legacy references. A forced refresh waits for an in-flight list request before fetching again.

## Passed local checks

- Production repository checks.
- Existing isolated-sync suite: rejected-record recovery, incoming changes while dirty, independent successful saves, retries, browser-storage failure preservation, edits during a save, legacy drafts, account changes and reset quarantine.
- Browser session tests: sign-in callback behavior, concurrent loading, admin profile verification, failure/retry without forced signout, late responses after logout, inactive-account rejection; background failure retains the workspace and subsequent inactive status closes it.
- Project file tests: upload during list refresh, cache rebuild from the registry, attachment-metadata rejection cleanup, view-only upload denial and account cache separation.
- Project message thread mapping and private-group preservation.
- PostgreSQL policy tests: Projects editor upload/read with Evidence disabled; viewer read-only; unassigned project, other organisation and no-access denial.

## Scope and limits

These checks used the available source baseline, mocked network responses for client tests and a local PostgreSQL test database for policies. They are not a live platform-wide audit. Live Supabase logs, deployed configuration, Cloudflare deployment and the specific missing message have not been inspected. Full live send/refresh and PDF upload/open checks are required after deployment. Existing quotation editing and PDF rendering files are not replaced by this patch.
