# Elder — free, built-in CAGE guidance

Replaces the Einstein panel with Elder. Includes local Driver.js 1.3.6 under the included MIT license, searchable instructions and spotlight walkthroughs. No OpenAI requests, AI chat or external help service. Existing hosting costs remain. No SQL migration or new key needed.

Walkthroughs open the relevant module and highlight visible controls, then show the steps. They never click Save, Send, Delete or upload anything. Complete or close an open form before starting. Permissions are checked, unavailable controls are skipped, and written steps remain available. Tours do not execute the whole workflow or automatically fill forms. Guides must be updated when the Hub changes.

## Install
Download CAGE_Elder_Guided_Help_Update.zip and upload it to the Codespaces repository ROOT (alongside dist, not inside .github).

```bash
cd /workspaces/cage-operations-hub
git switch -c elder-guided-help
unzip CAGE_Elder_Guided_Help_Update.zip
python3 elder-update/install.py --check
python3 elder-update/install.py
npm run check
```
If the branch exists, use git switch elder-guided-help. If source differs, stop and share the output; the installer protects unexpected edits. This update expects the Einstein package already installed. Existing runtime-config.js and secrets are untouched. Original edited files are backed up outside the repository.

## Stop paid requests from old tabs
Deploy the replacement endpoint FIRST:

```bash
npx supabase functions deploy einstein --use-api --no-verify-jwt
```
The name remains einstein only to retire the old endpoint. Its new code immediately returns a retirement message and never contacts OpenAI. This prevents old frontend tabs from continuing paid requests through this function. Requests already in flight may finish. If login is needed, run npx supabase login and retry.

## Publish Elder

```bash
python3 elder-update/stage.py
git diff --cached --stat
```
Review the list (9 update files). Keep unrelated files and runtime-config.js out of the commit. Then:

```bash
git commit -m "Replace Einstein AI chat with Elder guided help"
git push -u origin elder-guided-help
```
GitHub → Pull requests → New pull request → base main, compare elder-guided-help. Review and merge. Wait for Cloudflare Pages PRODUCTION deployment to succeed, then Cmd+Shift+R in the Hub.

## Verify
- Elder · Help appears; Einstein is gone.
- Search invoice, project or task, select a guide, then Walk me through.
- Next/Back/Done move through highlighted controls and instructions without changing records.
- Show me around explains visible modules. On a small screen open the navigation menu for the module tour, or use written guides.
- Logging out hides Elder and ends the tour.
- The retired einstein endpoint makes zero OpenAI requests. No billing setup needed for Elder.

Existing Einstein usage counters can remain; Elder does not use them. The unused old guide files can remain too. No company data is deleted. Optional: remove OPENAI_API_KEY from Supabase only if no other function uses it.
