from pathlib import Path
from datetime import datetime,timezone
import re,shutil
root=Path.cwd();pkg=Path(__file__).resolve().parent
p=root/'dist/production.js';s=p.read_text()
if 'Login reliability 2026-09-24' in s:raise SystemExit('Login fix already installed. No files changed.')
a='  async function establishSession(session) {';b='  passwordSetupForm.addEventListener("submit", async event => {'
if s.count(a)!=1 or s.count(b)!=1:raise SystemExit('STOP: login code differs. No files changed; share your current production.js for review.')
s=s[:s.index(a)]+(pkg/'session-block.js').read_text()+s[s.index(b):]
# Fence background polling so a response from an old login cannot repaint a new session.
a='      if (!profile || document.hidden || pendingState) return;'
if s.count(a)!=1:raise SystemExit('STOP: polling code differs. No files changed.')
s=s.replace(a,a+'\n      const pollUser=profile.id,pollGeneration=sessionGeneration;',1)
a='        const result = await client.rpc("get_my_workspace");'
if s.count(a)!=1:raise SystemExit('STOP: polling request differs. No files changed.')
s=s.replace(a,'        const result = await client.rpc("get_my_workspace").abortSignal(AbortSignal.timeout(15000));\n        if(pollUser!==profile?.id||pollGeneration!==sessionGeneration)return;',1)
a='    const result = await client.from("module_access").select("module,access").eq("user_id",profile.id);'
if s.count(a)!=1:raise SystemExit('STOP: permission polling differs. No files changed.')
s=s.replace(a,'    const accessUser=profile?.id,accessGeneration=sessionGeneration;\n    if(!accessUser)return;\n    const result = await client.from("module_access").select("module,access").eq("user_id",accessUser).abortSignal(AbortSignal.timeout(15000));\n    if(accessUser!==profile?.id||accessGeneration!==sessionGeneration)return;',1)
h=(root/'dist/index.html').read_text();h,n=re.subn(r'(src="\./production\.js\?v=)[^"\s]+',r'\g<1>login-20260924-1',h)
if n!=1:raise SystemExit('STOP: script tag differs. No files changed.')
h=h.replace('<span id="current-user-role">Team member</span>','<span id="current-user-role">Verifying access…</span>')
backup=root.parent/('cage-before-login-fix-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f'));(backup/'dist').mkdir(parents=True)
for rel in ['dist/production.js','dist/index.html']:shutil.copy2(root/rel,backup/rel)
p.write_text(s);(root/'dist/index.html').write_text(h)
print('Login fix installed. Original files:',backup)
