# CAGE login reliability fix

Your supplied account check confirms that alexander@cagemw.com is active, has role admin, and its Auth ID matches its profile ID in the correct organisation. Do not promote, recreate or reset this account.

This patch fixes identified frontend failure paths. It has been tested locally, not installed or verified against your live login. It does not prove every possible network/configuration issue is resolved.

## What changes

- Database loading starts outside Supabase's auth-event callback, avoiding a documented hanging-call risk.
- Repeated sign-in events share one load; stale session responses cannot finish a logged-out session.
- The Hub opens only after the actual active staff profile, recognised role, permissions and workspace load successfully.
- Transient loading failures no longer call signOut. A **Retry opening workspace** button retries the saved session.
- Network operations have loading deadlines; failed sign-in attempts restore the Sign in button.
- Errors identify whether the profile, permissions or workspace failed to load.
- The static Team member placeholder becomes Verifying access.
- Background permission/workspace polling ignores responses from an obsolete session.
- Unsynced local drafts are not deleted; no account permissions are changed.

Supabase reference: https://supabase.com/docs/guides/troubleshooting/why-is-my-supabase-api-call-not-returning-PGzXw0

## 1. Prepare Codespaces

Upload **CAGE_Login_Reliability_Fix.zip** into the repository root using Codespaces Explorer.

Run:

```bash
cd /workspaces/cage-operations-hub
git status --short
```

If tracked files are modified, commit/save your current work before switching branches. Do not discard it. If the categories update is already merged, use current main:

```bash
git switch main
git pull --ff-only
git switch -c login-reliability
```

If categories are not yet merged, complete that reviewed merge first, or deliberately create this branch from the branch containing those changes and review all its commits together.

```bash
unzip CAGE_Login_Reliability_Fix.zip
python3 login-fix/install.py
npm run check
git diff --check
```

The installer changes ONLY `dist/production.js` and `dist/index.html`. It preserves the category/document/location wrapper methods elsewhere in production.js. It checks expected code before writing; if it says STOP, share the message. Do not bypass it.

The original two files are saved in a timestamped `cage-before-login-fix-...` folder beside the repository. Download that folder for rollback. Runtime config and secrets are not touched. Re-running the installer intentionally stops.

## 2. Publish

**No SQL and no Edge Function commands are needed.**

```bash
git add dist/production.js dist/index.html
git commit -m "Fix login session loading and transient access failures"
git push -u origin login-reliability
```

On GitHub create a PR from **login-reliability → main**, inspect the changes, and merge after checks pass. Wait for the deployment workflow to succeed. Keep existing deployment secrets unchanged.

## 3. Check actual login

1. Keep any tab with unsynced work open. Do not clear browser/site storage.
2. Open a separate private browser window, go to https://hub.cagemw.com and sign in as Alexander.
3. Confirm Administrator is displayed and Finance and Settings open. Refresh and confirm the restored session behaves the same way.
4. If a temporary loading failure occurs, use Retry opening workspace. If it fails again, capture the exact message; it identifies which read failed. Do not repeatedly reset your password.
5. After the fresh-window test succeeds, save/sync work in existing tabs and refresh those tabs to load the fix.
6. Check an ordinary member retains their intended access. The patch never grants admin based on email text.

A green deployment is not proof of successful live login. If the issue remains, share the displayed error and the first relevant browser Console error, excluding passwords, access tokens and request headers.

## Rollback

Revert this fix's merge commit in a reviewed GitHub PR and redeploy. Alternatively restore only the two files from the installer's backup on a review branch. Do not restore old database data or discard unrelated code changes.

## Local results

Passed Chromium tests with a mocked Auth/database client: no API calls inside auth callback; one profile load for duplicate sign-in paths; admin role loaded correctly; transient failure and retry without signout; thrown sign-in request restores button; delayed profile reply cannot undo signout; inactive account stays blocked.

Passed a full patched production.js test against the actual index.html, with mocked backend: existing admin session opens the Hub and Finance/Settings return edit access. JavaScript syntax and existing repository production checks passed. No real credentials, emails, live mutations or password resets were used.

The included developer tests require Playwright and Chromium. They use local fixture paths documented in their source and are not installation steps.
