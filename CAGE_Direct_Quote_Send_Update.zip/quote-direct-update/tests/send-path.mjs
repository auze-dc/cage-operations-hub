import path from 'node:path';import {pathToFileURL} from 'node:url';
const repo=path.resolve(process.env.CAGE_TEST_REPO||'.')+'/';
import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';
const s=fs.readFileSync(repo+'dist/production.js','utf8');const code=s.slice(s.indexOf('  async function sendDocument(payload)'),s.indexOf('  async function opportunityData()'));
for(const type of ['invoice','quote'])for(const level of ['edit','view','none']){
 const calls=[],storage=new Map();const context={window:{CAGE_DELIVERY:{fields:()=>({})}},profile:{id:'u',active:true,role:'member'},moduleLevel:()=>level,clearTimeout,saveTimer:null,saveChain:Promise.resolve(),pendingState:null,workspaceVersion:0,loadWorkspace:async()=>calls.push('load'),localStorage:{getItem:k=>storage.get(k),setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},crypto,client:{rpc:async(name,p)=>{calls.push(name);return {data:{version:1,record:p.doc_record}}},functions:{invoke:async(name)=>{calls.push(name);return {data:{ok:true}}}}}};vm.createContext(context);vm.runInContext(code,context);
 const send=()=>context.sendDocument({type,record:{id:'new-invoice',amount:100},recipient:'client@example.invalid',subject:'Invoice',message:'Hello'});
 if(level==='none'){await assert.rejects(send,/Access/);assert.equal(calls.length,0);}else{await send();assert.equal(calls[0],level==='edit'?'prepare_document_delivery':`prepare_staff_${type}_send`);assert(calls.includes('send-document-v2'));assert.equal(calls.at(-1),'load');}
}
console.log('PASS invoice and quote sender selects existing editable-create path and new read-only send path; no-access blocked before requests.');
