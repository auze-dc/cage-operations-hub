# Validation

Passed locally against the supplied schema and repository plus the previous staff-launch patch:
- Repository production checks.
- PGlite database migration: invoice regression, draft quote send preparation, Finance View canonical document checks, member creation of request-linked draft quotes, amount spoof rejection, other organisation/shared/anonymous rejection, service-only provider-confirmed completion and idempotent audit.
- Staff cannot forge an initial Accepted status; existing client response protection triggers retained.
- Mocked Edge handler: draft quote sends, view access, no access denial, shared/inactive rejection, recipient validation, private client-response invitations, provider retry idempotency and partial delivery failure recovery.
- Browser form tests: invoice and draft quote sending with view access, no client workspace write on resend, request-linked quote create-and-send without creating approval records, visible send checkbox and no-manager-approval wording, client response display.
- Production sender routing: editable creation path vs send-only preparation for both document types.

Tests use synthetic data and mocked providers. No live emails, real staff accounts or production SQL were used. Live deployment and staff-account verification remain installation steps.

Tests are in tests/. Set CAGE_TEST_REPO to the installed repository, CAGE_TEST_SCHEMA to a schema dump for the database test, and CAGE_TEST_BROWSER to a Chromium executable if needed. Dependencies: @electric-sql/pglite and playwright. Use Node 24. Tests do not connect to production.
