# Staff quote and invoice sending without manager approval

This is a follow-up to CAGE_Staff_Launch_Update.zip. It preserves that update, the login fixes, categories, client responses, branding and location controls.

Staff with Finance Edit can create and send quotes and invoices directly. Finance View can send existing documents they can access but cannot edit amounts or create documents. No Access and record restrictions remain. Client acceptance/rejection remains separate. Draft means unfinished, not waiting for internal approval. New quotes no longer generate manager approval requests. Existing approval records are preserved as history, and existing draft quotes can be sent without deciding those requests.

The previous unsynced changes are not deleted or automatically repaired by this update. Keep all local drafts. If sync still fails, capture its exact red error message.

## 1. Install code in Codespaces

Finish saving/committing your previous code update first. Use the checkout containing the staff launch update, not an older checkout. Keep your current production backup. Upload CAGE_Direct_Quote_Send_Update.zip into the repository's top level.

Run these commands one at a time:

```bash
cd /workspaces/cage-operations-hub
git status --short
git switch -c staff-direct-quote-send
unzip CAGE_Direct_Quote_Send_Update.zip
python3 quote-direct-update/install.py
npm run check
git diff --check
```

The installer verifies all seven files before writing and backs up changed originals outside the repository. If it says STOP, send that message; do not force replacement. It does not run SQL or deploy anything. Untracked update folders may appear in git status; do not stage those folders.

## 2. Install ONE new SQL file

Open it in the editor:

```bash
code supabase/migrations/20260924160000_staff_quote_send.sql
```

Copy the entire file. In Supabase project CAGE Operations Hub (lrvcpiobxqtmcntwhaat), open SQL Editor → New query. Paste and run once as database owner. Expect Success. No rows returned.

The migration changes only document approval checks and adds quote send-only preparation and provider-confirmed completion. It preserves ownership, module access, record scope, client response protections and other manager approvals. It does not delete or reset business records. It checks existing function definitions and runs in one transaction. If it fails, stop and share the error. Do not rerun old migrations, use db reset or db push. A repeat deliberately fails rather than silently replacing an unexpected schema.

## 3. Deploy the updated sender

After SQL succeeds:

```bash
npx supabase functions deploy send-document-v2 --project-ref lrvcpiobxqtmcntwhaat --use-api
```

If it requests login, run `npx supabase login` and retry. Wait for Deployed Functions. Keep JWT verification enabled and preserve all secrets.

## 4. Publish the frontend

```bash
python3 quote-direct-update/stage.py
git --no-pager diff --cached --stat
git commit -m "Allow staff to send quotes without manager approval"
git push -u origin staff-direct-quote-send
```

On GitHub, create a pull request with base main and compare staff-direct-quote-send. Ensure the previous staff-launch update is included or already merged. Wait for checks, review, merge and wait for the website deployment to succeed.

## 5. Verify

Save unfinished work, close old Hub tabs and open the updated Hub. Do not clear browser data or discard unsynced drafts.

Using a staff account with Finance Edit, create a draft quote and click Send, using only an email you control. Also test Send immediately after saving and a request-linked quote. No internal manager approval should be requested. The client receives the PDF and the selected client approver receives the private response link. After provider acceptance, the quote shows Sent. Verify a client response is visible. Test an invoice too. Provider acceptance is not a guarantee of inbox delivery.

Old manager approval records stay in history; they no longer gate the sending of draft quotes. No live messages were sent during local testing.
